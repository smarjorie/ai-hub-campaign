import { useState, useEffect, useCallback } from 'react'
import {
  campaigns as mockCampaigns, genTimeline, genFunnel, getAccountSummary,
  demographics as mockDemographics, geoData as mockGeo, trafficSources as mockTrafficSources, insights as mockInsights,
} from './mockData'

// ── Storage keys ────────────────────────────────────────────────────────────
const KEYS = {
  metaToken:       'traffiq_meta_token',
  metaAccount:     'traffiq_meta_account',
  metaMcp:         'traffiq_meta_mcp',          // 'connected' | ''
  googleDevToken:  'traffiq_google_dev_token',
  googleOauth:     'traffiq_google_oauth',
  googleCustomer:  'traffiq_google_customer',
}

function ls(key: string) { return typeof window !== 'undefined' ? localStorage.getItem(key) || '' : '' }
function lsSet(key: string, val: string) { if (typeof window !== 'undefined') localStorage.setItem(key, val) }
function lsDel(key: string) { if (typeof window !== 'undefined') localStorage.removeItem(key) }

export const storage = {
  getMeta:     ()  => ({ token: ls(KEYS.metaToken), accountId: ls(KEYS.metaAccount), mcpEnabled: ls(KEYS.metaMcp) === 'true' }),
  setMeta:     (token: string, accountId: string) => { lsSet(KEYS.metaToken, token); lsSet(KEYS.metaAccount, accountId) },
  clearMeta:   ()  => { lsDel(KEYS.metaToken); lsDel(KEYS.metaAccount) },
  setMetaMcp:  (v: boolean) => lsSet(KEYS.metaMcp, String(v)),
  getGoogle:   ()  => ({ devToken: ls(KEYS.googleDevToken), oauthToken: ls(KEYS.googleOauth), customerId: ls(KEYS.googleCustomer) }),
  setGoogle:   (devToken: string, oauthToken: string, customerId: string) => {
    lsSet(KEYS.googleDevToken, devToken); lsSet(KEYS.googleOauth, oauthToken); lsSet(KEYS.googleCustomer, customerId)
  },
  clearGoogle: () => { lsDel(KEYS.googleDevToken); lsDel(KEYS.googleOauth); lsDel(KEYS.googleCustomer) },
}

// ── Fetch helpers ────────────────────────────────────────────────────────────
async function metaFetch(path: string, token: string) {
  const r = await fetch(path, { headers: { 'x-meta-token': token } })
  const d = await r.json()
  if (!r.ok) throw new Error(d.error || 'Erro Meta API')
  return d
}

async function googleFetch(path: string, creds: { devToken: string; oauthToken: string; customerId: string }) {
  const r = await fetch(path, {
    headers: {
      'x-google-dev-token':    creds.devToken,
      'x-google-oauth-token':  creds.oauthToken,
      'x-google-customer-id':  creds.customerId,
    },
  })
  const d = await r.json()
  if (!r.ok) throw new Error(d.error || 'Erro Google API')
  return d
}

// ── Types ────────────────────────────────────────────────────────────────────
export type DataSource = 'real' | 'mock' | 'loading' | 'error'

export interface Connections {
  meta:    { status: DataSource; token: string; accountId: string; accountName: string; userName: string; mcpEnabled: boolean; accounts: any[] }
  google:  { status: DataSource; devToken: string; oauthToken: string; customerId: string; customerName: string }
}

export interface DashState {
  connections:  Connections
  campaigns:    any[]
  timeline:     any[]
  funnel:       any[]
  demographics: { gender: any[]; age: any[] }
  geoData:      any[]
  trafficSources: any[]
  insights:     any[]
  summary:      any
  globalSource: DataSource   // 'real' se qualquer plataforma conectada, 'mock' caso contrário
  errors:       { meta?: string; google?: string }
}

// ── Metric helpers ────────────────────────────────────────────────────────────
function buildSummary(campaigns: any[]) {
  if (!campaigns.length) return getAccountSummary()
  const s = campaigns.reduce((acc: any, c: any) => ({
    spend: acc.spend + c.spend, revenue: acc.revenue + c.revenue,
    clicks: acc.clicks + c.clicks, impressions: acc.impressions + c.impressions,
    reach: acc.reach + c.reach, salesDb: acc.salesDb + c.salesDb, salesMeta: acc.salesMeta + c.salesMeta,
  }), { spend:0, revenue:0, clicks:0, impressions:0, reach:0, salesDb:0, salesMeta:0 })
  return {
    ...s,
    cpm:       s.impressions > 0 ? parseFloat(((s.spend / s.impressions) * 1000).toFixed(2)) : 0,
    ctr:       s.impressions > 0 ? parseFloat(((s.clicks / s.impressions) * 100).toFixed(4)) : 0,
    roas:      s.spend > 0 ? parseFloat((s.revenue / s.spend).toFixed(2)) : 0,
    frequency: s.reach > 0 ? parseFloat((s.impressions / s.reach).toFixed(2)) : 0,
    activeCampaigns: campaigns.filter((c: any) => c.status === 'ACTIVE').length,
    totalCampaigns: campaigns.length,
  }
}

function buildFunnel(campaigns: any[]) {
  const t = campaigns.reduce((acc: any, c: any) => ({
    clicks: acc.clicks + c.clicks, pageViews: acc.pageViews + (c.pageViews||0),
    addToCart: acc.addToCart + (c.addToCart||0), checkouts: acc.checkouts + (c.checkouts||0),
    sales: acc.sales + c.salesDb,
  }), { clicks:0, pageViews:0, addToCart:0, checkouts:0, sales:0 })
  const cl = t.clicks, pv = t.pageViews || Math.round(cl*0.89)
  const at = t.addToCart || Math.round(pv*0.14), ch = t.checkouts || Math.round(at*0.35)
  const co = t.sales
  return [
    { label:'Cliques',     value:cl, pct:100 },
    { label:'Page Views',  value:pv, pct: cl>0 ? parseFloat(((pv/cl)*100).toFixed(2)) : 0 },
    { label:'Add to Cart', value:at, pct: pv>0 ? parseFloat(((at/pv)*100).toFixed(2)) : 0 },
    { label:'Checkouts',   value:ch, pct: at>0 ? parseFloat(((ch/at)*100).toFixed(2)) : 0 },
    { label:'Compras',     value:co, pct: ch>0 ? parseFloat(((co/ch)*100).toFixed(2)) : 0 },
  ]
}

function mergeTimelines(meta: any[], google: any[]): any[] {
  // Merge by date, soma métricas das plataformas
  const map: Record<string, any> = {}
  ;[...meta, ...google].forEach(d => {
    if (!map[d.date]) map[d.date] = { ...d }
    else {
      map[d.date].spend    += d.spend
      map[d.date].revenue  += d.revenue
      map[d.date].clicks   += d.clicks
      map[d.date].impressions += d.impressions
      map[d.date].conversions += d.conversions
      map[d.date].roas = map[d.date].spend > 0
        ? parseFloat((map[d.date].revenue / map[d.date].spend).toFixed(2)) : 0
    }
  })
  return Object.values(map).sort((a,b) => a.date.localeCompare(b.date))
}

// ── Default state ─────────────────────────────────────────────────────────────
const defaultConnections: Connections = {
  meta:   { status:'mock', token:'', accountId:'', accountName:'', userName:'', mcpEnabled:false, accounts:[] },
  google: { status:'mock', devToken:'', oauthToken:'', customerId:'', customerName:'' },
}

// Lazy factory — called only on client mount, avoids SSR/hydration mismatch
function makeInitial(): DashState {
  return {
    connections:    defaultConnections,
    campaigns:      mockCampaigns,
    timeline:       genTimeline(30),
    funnel:         genFunnel(mockCampaigns),
    demographics:   mockDemographics,
    geoData:        mockGeo,
    trafficSources: mockTrafficSources,
    insights:       mockInsights,
    summary:        getAccountSummary(),
    globalSource:   'mock',
    errors:         {},
  }
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export function useMetaData(period = 'last_30d') {
  const [state, setState] = useState<DashState>(makeInitial)

  // ── Validate + list Meta accounts ──────────────────────────────────────────
  const validateMetaToken = useCallback(async (token: string) => {
    try {
      const d = await metaFetch(`/api/meta/validate`, token)
      const accounts = d.accounts || []
      const userName = d.user?.name || ''
      setState(s => ({ ...s, connections: { ...s.connections, meta: { ...s.connections.meta, accounts, userName } } }))
      return { valid: true, accounts, userName, error: undefined }
    } catch (e: any) {
      return { valid: false, accounts: [], userName: '', error: e.message }
    }
  }, [])

  // ── Load Meta data ──────────────────────────────────────────────────────────
  const loadMeta = useCallback(async (token: string, accountId: string, datePreset = period) => {
    setState(s => ({
      ...s,
      connections: { ...s.connections, meta: { ...s.connections.meta, status:'loading', token, accountId } },
    }))
    try {
      const [campRes, timelineRes, demoRes] = await Promise.all([
        metaFetch(`/api/meta/campaigns?account_id=${accountId}&date_preset=${datePreset}`, token),
        metaFetch(`/api/meta/timeline?account_id=${accountId}&date_preset=${datePreset}`, token),
        metaFetch(`/api/meta/demographics?account_id=${accountId}&date_preset=${datePreset}`, token),
      ])
      const metaCamps  = campRes.campaigns || []
      const metaTimeline = timelineRes.data || []

      setState(s => {
        // Merge with any existing Google campaigns
        const googleCamps = s.campaigns.filter((c:any) => c.platform === 'google')
        const allCamps = [...metaCamps, ...googleCamps]
        const googleTimeline = s.connections.google.status === 'real'
          ? s.timeline.filter((_:any, i:number) => i === -1) // placeholder — keep Google's if already loaded
          : []
        const mergedTimeline = googleTimeline.length ? mergeTimelines(metaTimeline, googleTimeline) : metaTimeline
        const demographics = { gender: demoRes.gender || mockDemographics.gender, age: demoRes.age || mockDemographics.age }
        const geoData = demoRes.regions?.length ? demoRes.regions : mockGeo
        return {
          ...s,
          campaigns:    allCamps,
          timeline:     mergedTimeline,
          funnel:       buildFunnel(allCamps),
          summary:      buildSummary(allCamps),
          demographics,
          geoData,
          globalSource: 'real',
          errors: { ...s.errors, meta: undefined },
          connections: {
            ...s.connections,
            meta: { status:'real', token, accountId, accountName: s.connections.meta.accounts.find((a:any)=>a.id===accountId)?.name || accountId, userName: s.connections.meta.userName, mcpEnabled: s.connections.meta.mcpEnabled, accounts: s.connections.meta.accounts },
          },
        }
      })
    } catch (e: any) {
      setState(s => ({
        ...s,
        errors: { ...s.errors, meta: e.message },
        connections: { ...s.connections, meta: { ...s.connections.meta, status:'error' } },
      }))
    }
  }, [period])

  // ── Validate Google ─────────────────────────────────────────────────────────
  const validateGoogleCreds = useCallback(async (devToken: string, oauthToken: string, customerId: string) => {
    try {
      const d = await googleFetch(`/api/google/validate`, { devToken, oauthToken, customerId })
      return { valid: true, customerName: d.customer?.name || '', error: undefined }
    } catch (e: any) {
      return { valid: false, customerName: '', error: e.message }
    }
  }, [])

  // ── Load Google data ────────────────────────────────────────────────────────
  const loadGoogle = useCallback(async (devToken: string, oauthToken: string, customerId: string, dateRange = 'LAST_30_DAYS') => {
    setState(s => ({
      ...s,
      connections: { ...s.connections, google: { ...s.connections.google, status:'loading', devToken, oauthToken, customerId } },
    }))
    try {
      const [campRes, timelineRes] = await Promise.all([
        googleFetch(`/api/google/campaigns?date_range=${dateRange}`, { devToken, oauthToken, customerId }),
        googleFetch(`/api/google/timeline?date_range=${dateRange}`,  { devToken, oauthToken, customerId }),
      ])
      const googleCamps    = campRes.campaigns || []
      const googleTimeline = timelineRes.data  || []

      setState(s => {
        const metaCamps = s.campaigns.filter((c:any) => c.platform !== 'google')
        const allCamps  = [...metaCamps, ...googleCamps]
        const metaTimeline = s.connections.meta.status === 'real' ? s.timeline : []
        const mergedTimeline = metaTimeline.length ? mergeTimelines(metaTimeline, googleTimeline) : googleTimeline
        return {
          ...s,
          campaigns: allCamps,
          timeline:  mergedTimeline,
          funnel:    buildFunnel(allCamps),
          summary:   buildSummary(allCamps),
          globalSource: 'real',
          errors: { ...s.errors, google: undefined },
          connections: {
            ...s.connections,
            google: { status:'real', devToken, oauthToken, customerId, customerName: s.connections.google.customerName },
          },
        }
      })
    } catch (e: any) {
      setState(s => ({
        ...s,
        errors: { ...s.errors, google: e.message },
        connections: { ...s.connections, google: { ...s.connections.google, status:'error' } },
      }))
    }
  }, [period])

  // ── Public connect / disconnect ─────────────────────────────────────────────
  const connectMeta = useCallback(async (token: string, accountId: string) => {
    storage.setMeta(token, accountId)
    // When switching accounts with same token, preserve existing accounts list
    await loadMeta(token, accountId)
  }, [loadMeta])

  // Switch account without re-validating token — uses existing accounts list
  const switchMetaAccount = useCallback(async (accountId: string) => {
    const { token } = storage.getMeta()
    if (!token) return
    storage.setMeta(token, accountId)
    await loadMeta(token, accountId)
  }, [loadMeta])

  const disconnectMeta = useCallback(() => {
    storage.clearMeta()
    setState(s => {
      const googleCamps = s.campaigns.filter((c:any) => c.platform !== 'meta')
      const hasGoogle   = s.connections.google.status === 'real'
      return {
        ...s,
        campaigns:    hasGoogle ? googleCamps : mockCampaigns,
        timeline:     hasGoogle ? s.timeline  : genTimeline(30),
        funnel:       hasGoogle ? buildFunnel(googleCamps) : genFunnel(mockCampaigns),
        summary:      hasGoogle ? buildSummary(googleCamps) : getAccountSummary(),
        demographics: mockDemographics,
        geoData:      mockGeo,
        globalSource: hasGoogle ? 'real' : 'mock',
        connections:  { ...s.connections, meta: { status:'mock', token:'', accountId:'', accountName:'', userName:'', mcpEnabled:false, accounts:[] } },
      }
    })
  }, [])

  const connectGoogle = useCallback(async (devToken: string, oauthToken: string, customerId: string) => {
    storage.setGoogle(devToken, oauthToken, customerId)
    await loadGoogle(devToken, oauthToken, customerId)
  }, [loadGoogle])

  const disconnectGoogle = useCallback(() => {
    storage.clearGoogle()
    setState(s => {
      const metaCamps = s.campaigns.filter((c:any) => c.platform !== 'google')
      const hasMeta   = s.connections.meta.status === 'real'
      return {
        ...s,
        campaigns: hasMeta ? metaCamps : mockCampaigns,
        timeline:  hasMeta ? s.timeline : genTimeline(30),
        funnel:    hasMeta ? buildFunnel(metaCamps) : genFunnel(mockCampaigns),
        summary:   hasMeta ? buildSummary(metaCamps) : getAccountSummary(),
        globalSource: hasMeta ? 'real' : 'mock',
        connections: { ...s.connections, google: { status:'mock', devToken:'', oauthToken:'', customerId:'', customerName:'' } },
      }
    })
  }, [])

  const setMetaMcp = useCallback((enabled: boolean) => {
    storage.setMetaMcp(enabled)
    setState(s => ({ ...s, connections: { ...s.connections, meta: { ...s.connections.meta, mcpEnabled: enabled } } }))
  }, [])

  const reload = useCallback(() => {
    const meta   = storage.getMeta()
    const google = storage.getGoogle()
    if (meta.token && meta.accountId) loadMeta(meta.token, meta.accountId, period)
    if (google.devToken && google.oauthToken && google.customerId) loadGoogle(google.devToken, google.oauthToken, google.customerId)
  }, [period, loadMeta, loadGoogle])

  // Auto-restore on mount — re-validate token to get accounts list for switcher
  useEffect(() => {
    const meta   = storage.getMeta()
    const google = storage.getGoogle()
    if (meta.token && meta.accountId) {
      // First validate to populate accounts list, then load data
      metaFetch('/api/meta/validate', meta.token)
        .then(d => {
          const accounts = d.accounts || []
          const userName = d.user?.name || ''
          setState(s => ({ ...s, connections: { ...s.connections, meta: { ...s.connections.meta, accounts, userName } } }))
        })
        .catch(() => {})
        .finally(() => loadMeta(meta.token, meta.accountId, period))
    }
    if (google.devToken && google.oauthToken && google.customerId)
      loadGoogle(google.devToken, google.oauthToken, google.customerId)
    if (meta.mcpEnabled)
      setState(s => ({ ...s, connections: { ...s.connections, meta: { ...s.connections.meta, mcpEnabled: true } } }))
  }, [])

  return {
    ...state,
    connectMeta, disconnectMeta, validateMetaToken, switchMetaAccount,
    connectGoogle, disconnectGoogle, validateGoogleCreds,
    setMetaMcp,
    reload,
  }
}

// ── Helpers exported for account switcher ─────────────────────────────────
export const GOOGLE_DATE_MAP: Record<string, string> = {
  'today':        'TODAY',
  'yesterday':    'YESTERDAY',
  'last_7d':      'LAST_7_DAYS',
  'last_30d':     'LAST_30_DAYS',
  'this_month':   'THIS_MONTH',
  'last_month':   'LAST_MONTH',
}
