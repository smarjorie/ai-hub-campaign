// lib/agent.ts
// Loop de agente: Claude + ferramentas de leitura do Traffiq.
// Acoes que alteram contas NUNCA sao executadas aqui: o modelo chama propose_action
// e a interface pede confirmacao antes de chamar /api/agent/execute.

import { READ_TOOLS, WRITE_TOOLS, type ToolCtx } from './mcp/tools'

export interface ChatTurn { role: 'user' | 'assistant'; content: string }
export interface Proposal {
  id: string
  tool: string
  args: Record<string, any>
  title: string
  reason: string
}
export interface AgentResult { reply: string; proposals: Proposal[]; toolsUsed: string[] }

const API = 'https://api.anthropic.com/v1/messages'
const MAX_ROUNDS = 8
const MAX_TOOL_CHARS = 60_000

const SYSTEM = (today: string) => `Você é o agente de marketing do Traffiq, um painel de tráfego pago (Meta Ads e Google Ads) com CRM de WhatsApp.
Hoje é ${today}. Responda sempre em português do Brasil, de forma direta e curta.

Como trabalhar:
- Use as ferramentas de leitura para buscar dados reais antes de afirmar qualquer número. Não invente métricas.
- Comece pelo nível de campanha; desça para conjunto/anúncio só se a pergunta exigir.
- Se uma ferramenta falhar por falta de conexão, diga qual integração conectar em Integrações e pare.
- Para QUALQUER mudança na conta (pausar, ativar, mudar orçamento), NÃO diga que executou. Chame propose_action uma vez por mudança, com o id real do objeto, e explique no texto o que propôs. O usuário confirma na interface.
- Formato: parágrafos curtos e listas com "- ". Use **negrito** só para números-chave. Sem tabelas, sem títulos com #.
- Valores monetários na moeda da conta, formato brasileiro (R$ 1.234,56).`

const PROPOSE_TOOL = {
  name: 'propose_action',
  description:
    'Propõe uma alteração na conta de anúncios para o usuário confirmar. Não executa nada. ' +
    'Use para pausar/ativar (meta_set_status) ou mudar orçamento diário (meta_set_daily_budget).',
  input_schema: {
    type: 'object',
    properties: {
      tool: { type: 'string', enum: WRITE_TOOLS().map(t => t.name) },
      args: { type: 'object', description: 'Argumentos exatos da ferramenta (object_id + status, ou object_id + daily_budget).' },
      title: { type: 'string', description: 'Resumo curto, ex.: "Pausar campanha Black Friday - Remarketing".' },
      reason: { type: 'string', description: 'Por que, com os números que justificam.' },
    },
    required: ['tool', 'args', 'title', 'reason'],
  },
}

async function callClaude(body: any) {
  const key = process.env.ANTHROPIC_API_KEY
  if (!key) throw new Error('ANTHROPIC_API_KEY não configurada no servidor.')
  const r = await fetch(API, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(body),
  })
  const d = await r.json()
  if (!r.ok) throw new Error(d?.error?.message || `Anthropic API respondeu ${r.status}`)
  return d
}

export async function runAgent(turns: ChatTurn[], ctx: ToolCtx): Promise<AgentResult> {
  const read = READ_TOOLS()
  const tools = [
    ...read.map(t => ({ name: t.name, description: t.description, input_schema: t.inputSchema })),
    PROPOSE_TOOL,
  ]
  const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
  const messages: any[] = turns.map(t => ({ role: t.role, content: t.content }))
  const proposals: Proposal[] = []
  const toolsUsed: string[] = []
  let reply = ''

  for (let round = 0; round < MAX_ROUNDS; round++) {
    const res = await callClaude({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5',
      max_tokens: 2000,
      system: SYSTEM(today),
      tools,
      messages,
    })
    const blocks: any[] = res.content || []
    const text = blocks.filter(b => b.type === 'text').map(b => b.text).join('\n').trim()
    if (text) reply = text
    messages.push({ role: 'assistant', content: blocks })

    const calls = blocks.filter(b => b.type === 'tool_use')
    if (res.stop_reason !== 'tool_use' || !calls.length) break

    const results = await Promise.all(calls.map(async (c: any) => {
      if (c.name === 'propose_action') {
        const allowed = WRITE_TOOLS().some(t => t.name === c.input?.tool)
        if (allowed) {
          proposals.push({ id: c.id, tool: c.input.tool, args: c.input.args || {}, title: c.input.title, reason: c.input.reason })
          return { type: 'tool_result', tool_use_id: c.id, content: 'Proposta registrada. Aguardando confirmação do usuário na interface.' }
        }
        return { type: 'tool_result', tool_use_id: c.id, is_error: true, content: 'Ferramenta de escrita desconhecida.' }
      }
      const tool = read.find(t => t.name === c.name)
      if (!tool) return { type: 'tool_result', tool_use_id: c.id, is_error: true, content: `Ferramenta desconhecida: ${c.name}` }
      toolsUsed.push(c.name)
      try {
        const out = JSON.stringify(await tool.run(c.input || {}, ctx))
        return { type: 'tool_result', tool_use_id: c.id, content: out.length > MAX_TOOL_CHARS ? out.slice(0, MAX_TOOL_CHARS) + '...[truncado]' : out }
      } catch (e: any) {
        return { type: 'tool_result', tool_use_id: c.id, is_error: true, content: `Erro: ${e.message}` }
      }
    }))
    messages.push({ role: 'user', content: results })
  }

  return { reply: reply || 'Não consegui concluir a análise. Tente reformular o pedido.', proposals, toolsUsed: Array.from(new Set(toolsUsed)) }
}
