export type IntegrationStatus = 'connected' | 'disconnected' | 'error' | 'pending'

export interface Integration {
  id: string
  name: string
  platform: string
  type: 'mcp' | 'api' | 'oauth'
  status: IntegrationStatus
  accountId?: string
  accountName?: string
  lastSync?: string
  scopes?: string[]
  tokenPreview?: string
}

const STORAGE_KEY = 'traffiq_integrations'

const defaults: Integration[] = [
  { id: 'meta-mcp',    name: 'Meta Ads (MCP)',    platform: 'meta',    type: 'mcp',   status: 'disconnected' },
  { id: 'meta-api',    name: 'Meta Ads (API)',     platform: 'meta',    type: 'api',   status: 'disconnected' },
  { id: 'google-oauth',name: 'Google Ads (OAuth)', platform: 'google',  type: 'oauth', status: 'disconnected' },
  { id: 'google-api',  name: 'Google Ads (API)',   platform: 'google',  type: 'api',   status: 'disconnected' },
  { id: 'ga4',         name: 'Google Analytics 4', platform: 'ga',      type: 'oauth', status: 'disconnected' },
  { id: 'tiktok',      name: 'TikTok Ads',         platform: 'tiktok',  type: 'oauth', status: 'disconnected' },
  { id: 'whatsapp-bsp',name: 'WhatsApp (BSP)',      platform: 'whatsapp',type: 'api',   status: 'disconnected' },
]

export function getIntegrations(): Integration[] {
  if (typeof window === 'undefined') return defaults
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    return stored ? JSON.parse(stored) : defaults
  } catch { return defaults }
}

export function saveIntegrations(integrations: Integration[]) {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(integrations))
}

export function updateIntegration(id: string, data: Partial<Integration>) {
  const list = getIntegrations()
  const updated = list.map(i => i.id === id ? { ...i, ...data } : i)
  saveIntegrations(updated)
  return updated
}
