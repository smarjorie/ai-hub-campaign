// Supabase client — install @supabase/supabase-js and uncomment when ready
// import { createClient } from '@supabase/supabase-js'
// const url = process.env.NEXT_PUBLIC_SUPABASE_URL
// const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
// export const supabase = url && key ? createClient(url, key) : null

export const supabase: any = null

/*
SQL para criar a tabela:

CREATE TABLE sales (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  sale_id TEXT NOT NULL UNIQUE,
  value NUMERIC(10,2) NOT NULL,
  campaign_id TEXT NOT NULL,
  adset_id TEXT NOT NULL,
  ad_id TEXT NOT NULL,
  platform TEXT DEFAULT 'meta',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow insert" ON sales FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow read" ON sales FOR SELECT USING (true);
*/
