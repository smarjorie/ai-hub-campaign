// ── BSP / WhatsApp CRM Mock Data ─────────────────────────────────────────────
// Inspirado nos prints: funil de vendas por etapa, performance por canal/tracking

export interface BspFunnelStep {
  label:    string
  value:    number
  pct:      number   // % em relação ao passo anterior
  absolute: number   // % do total (sessões iniciadas)
}

export interface BspChannel {
  tracking:      string
  source:        string
  engajamento:   number  // %
  elegibilidade: number  // %
  convElegivel:  number  // % conversão de elegíveis
  ticketMedio:   number
  taxaMensal:    number  // %
  disparos:      number
  sessoes:       number
  conversoes:    number
}

export interface BspPeriodSummary {
  disparos:      number
  sessoes:       number
  valorTotal:    number
  ticketMedio:   number
  elegibilidade: number  // %
  conversao:     number  // % do total de sessões
  usuariosUnicos:number
}

// ── Funil de vendas ───────────────────────────────────────────────────────────
export function genBspFunnel(): BspFunnelStep[] {
  const steps = [
    { label: 'Sessão iniciada',       value: 271191, pct: 100,  absolute: 100  },
    { label: 'CPF informado',         value: 188902, pct: 69.7, absolute: 69.7 },
    { label: 'E-mail informado',      value: 158966, pct: 84.2, absolute: 58.6 },
    { label: 'Consulta autorizada',   value: 142496, pct: 89.6, absolute: 52.5 },
    { label: 'Sucesso Consulta',      value: 141855, pct: 99.5, absolute: 52.3 },
    { label: 'Oferta realizada',      value:  20398, pct: 14.4, absolute:  7.5 },
    { label: 'Oferta aceita',         value:  10066, pct: 49.3, absolute:  3.7 },
    { label: 'CEP coletado',          value:   9535, pct: 94.7, absolute:  3.5 },
    { label: 'Endereço informado',    value:   9508, pct: 99.7, absolute:  3.5 },
    { label: 'Banco informado',       value:   9203, pct: 96.8, absolute:  3.4 },
    { label: 'Banco validado',        value:   9150, pct: 99.4, absolute:  3.4 },
    { label: 'Proposta criada',       value:   6725, pct: 73.5, absolute:  2.5 },
    { label: 'Biometria solicitada',  value:   6713, pct: 99.8, absolute:  2.5 },
    { label: 'Biometria aprovada',    value:   5040, pct: 75.1, absolute:  1.9 },
    { label: 'Proposta aprovada',     value:   4686, pct: 93,   absolute:  1.7 },
  ]
  return steps
}

// ── Canais / tracking ─────────────────────────────────────────────────────────
export const bspChannels: BspChannel[] = [
  { tracking:'Lolao CTPS',                              source:'CTPS',         engajamento:54.1, elegibilidade:82.3, convElegivel:74.2, ticketMedio:5841, taxaMensal:3.69, disparos:48200,  sessoes:26082, conversoes:1240 },
  { tracking:'SimulouNaoFinalizou',                     source:'Disparo Ativo',engajamento:14.9, elegibilidade: 3.2, convElegivel:28.9, ticketMedio:5688, taxaMensal:4.03, disparos:142000, sessoes:21158, conversoes: 612 },
  { tracking:'CarrinhoAbandonado',                      source:'Disparo Ativo',engajamento:27.9, elegibilidade:34.9, convElegivel:20.8, ticketMedio:5096, taxaMensal:3.88, disparos:89400,  sessoes:24942, conversoes: 819 },
  { tracking:'SimulouNaoFinalizouBlip',                 source:'Disparo Ativo',engajamento:58.4, elegibilidade:65.3, convElegivel: 2.2, ticketMedio:6226, taxaMensal:3.87, disparos:38100,  sessoes:22250, conversoes: 489 },
  { tracking:'SimulouNaoFinalizou_Inativos',            source:'Disparo Ativo',engajamento:24.6, elegibilidade:35.0, convElegivel: 5.7, ticketMedio:4417, taxaMensal:4.10, disparos:56800,  sessoes:13961, conversoes: 794 },
  { tracking:'SimulouNaoFinalizou_NuncaAtivos',         source:'Disparo Ativo',engajamento:11.4, elegibilidade:36.8, convElegivel:12.8, ticketMedio:4312, taxaMensal:4.06, disparos:72300,  sessoes:8242,  conversoes: 419 },
  { tracking:'Propensao_Ativos_Inativos_NaoEngajaram',  source:'Disparo Ativo',engajamento:21.4, elegibilidade: 1.9, convElegivel: 7.9, ticketMedio:4903, taxaMensal:4.06, disparos:61200,  sessoes:13096, conversoes: 532 },
  { tracking:'organico',                                source:'Orgânico',     engajamento:0,    elegibilidade: 2.5, convElegivel:17.3, ticketMedio:9508, taxaMensal:3.45, disparos:0,      sessoes:0,     conversoes: 421 },
  { tracking:'DesengajadosCRM_Inativos',                source:'Disparo Ativo',engajamento:14.8, elegibilidade: 1.7, convElegivel: 8.1, ticketMedio:7460, taxaMensal:3.88, disparos:48900,  sessoes:7245,  conversoes: 188 },
  { tracking:'SimulouNaoFinalizou_Inativos_NuncaAtivos',source:'Disparo Ativo',engajamento:23.2, elegibilidade:52.3, convElegivel:10.9, ticketMedio:3385, taxaMensal:4.04, disparos:34100,  sessoes:7913,  conversoes: 276 },
  { tracking:'DesengajadosCRM_Inativos_NuncaAtivos',    source:'Disparo Ativo',engajamento:15.4, elegibilidade: 1.9, convElegivel: 7.4, ticketMedio:4151, taxaMensal:3.57, disparos:29800,  sessoes:4593,  conversoes: 112 },
]

// ── Summary do período ────────────────────────────────────────────────────────
export const bspSummary: BspPeriodSummary = {
  disparos:       294030,
  sessoes:        271198,
  valorTotal:     21716959,
  ticketMedio:    5756,
  elegibilidade:  7.5,
  conversao:      1.4,
  usuariosUnicos: 271191,
}

// ── Timeline de disparos (últimos 30 dias) ────────────────────────────────────
export function genBspTimeline() {
  const data = []
  const now  = new Date()
  let seed   = 77
  function sr() { seed = (seed * 1664525 + 1013904223) & 0xFFFFFFFF; return ((seed >>> 0) / 0xFFFFFFFF) }

  for (let i = 29; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i)
    const label = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`
    const disparos   = Math.round(8000 + sr() * 6000)
    const sessoes    = Math.round(disparos * (0.55 + sr() * 0.3))
    const conversoes = Math.round(sessoes  * (0.008 + sr() * 0.008))
    const valor      = Math.round(conversoes * (4800 + sr() * 1800))
    data.push({ label, date: d.toISOString().split('T')[0], disparos, sessoes, conversoes, valor })
  }
  return data
}

// ── Dados demográficos BSP ────────────────────────────────────────────────────
export const bspDemographics = {
  gender: [
    { name: 'Feminino', value: 58.4 },
    { name: 'Masculino',value: 38.2 },
    { name: 'Não inf.', value:  3.4 },
  ],
  age: [
    { name: '18-29', value: 12.1 },
    { name: '30-39', value: 19.8 },
    { name: '40-49', value: 24.3 },
    { name: '50-59', value: 21.6 },
    { name: '60-69', value: 14.8 },
    { name: '70+',   value:  7.4 },
  ],
}

// ── Entry points ──────────────────────────────────────────────────────────────
export const bspEntryPoints = [
  { name: 'Link direto WhatsApp',    sessoes: 89420, conversoes: 1248, convRate: 1.40 },
  { name: 'Botão site / landing',    sessoes: 72810, conversoes:  912, convRate: 1.25 },
  { name: 'QR Code campanha',        sessoes: 48200, conversoes:  621, convRate: 1.29 },
  { name: 'Anúncio CTWA Meta',       sessoes: 38600, conversoes:  542, convRate: 1.40 },
  { name: 'Disparo ativo BSP',       sessoes: 22168, conversoes:  557, convRate: 2.51 },
]
