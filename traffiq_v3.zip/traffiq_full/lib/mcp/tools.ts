// lib/mcp/tools.ts
// Ferramentas expostas pelo servidor MCP do Traffiq (/api/mcp).
// As de leitura reaproveitam as rotas /api/meta/* e /api/google/* que ja existem,
// entao a logica (paginacao, action_types, CTWA) continua num lugar so.

const GRAPH = 'https://graph.facebook.com/v21.0'

export interface UserCreds {
  meta?: { token?: string; accountId?: string }
  google?: { devToken?: string; oauthToken?: string; customerId?: string }
}

export interface ToolCtx {
  origin: string      // ex.: https://traffiq.vercel.app, para chamar as rotas internas
  creds?: UserCreds   // credenciais que o usuario conectou no Traffiq (tem prioridade sobre o .env)
}

type Json = Record<string, any>

export interface ToolDef {
  name: string
  title: string
  description: string
  inputSchema: Json
  write?: boolean
  run: (args: Json, ctx: ToolCtx) => Promise<any>
}

// ---------- credenciais do servidor (variaveis de ambiente) ----------

function metaToken(ctx?: ToolCtx): string {
  const t = ctx?.creds?.meta?.token || process.env.META_ACCESS_TOKEN
  if (!t) throw new Error('META_ACCESS_TOKEN não configurado no servidor.')
  return t
}

function metaAccount(arg?: string, ctx?: ToolCtx): string {
  const id = arg || ctx?.creds?.meta?.accountId || process.env.META_AD_ACCOUNT_ID
  if (!id) throw new Error('Informe account_id ou configure META_AD_ACCOUNT_ID.')
  return id.startsWith('act_') ? id : 'act_' + id
}

// Access token do Google expira em 1h: gera um novo a partir do refresh token
let googleCache: { token: string; exp: number } | null = null
async function googleAccessToken(): Promise<string> {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REFRESH_TOKEN, GOOGLE_OAUTH_TOKEN } = process.env
  if (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET && GOOGLE_REFRESH_TOKEN) {
    if (googleCache && googleCache.exp > Date.now() + 60_000) return googleCache.token
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        refresh_token: GOOGLE_REFRESH_TOKEN,
        grant_type: 'refresh_token',
      }),
    })
    const d = await r.json()
    if (!r.ok || !d.access_token) throw new Error('Falha ao renovar token do Google: ' + (d.error_description || d.error || r.status))
    googleCache = { token: d.access_token, exp: Date.now() + (d.expires_in || 3600) * 1000 }
    return d.access_token
  }
  if (GOOGLE_OAUTH_TOKEN) return GOOGLE_OAUTH_TOKEN
  throw new Error('Configure GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET e GOOGLE_REFRESH_TOKEN no servidor.')
}

async function googleHeaders(ctx?: ToolCtx): Promise<Record<string, string>> {
  const g = ctx?.creds?.google
  if (g?.devToken && g?.oauthToken && g?.customerId) {
    return { 'x-google-dev-token': g.devToken, 'x-google-customer-id': g.customerId.replace(/-/g, ''), 'x-google-oauth-token': g.oauthToken }
  }
  const dev = process.env.GOOGLE_DEVELOPER_TOKEN
  const cust = process.env.GOOGLE_CUSTOMER_ID
  if (!dev || !cust) throw new Error('GOOGLE_DEVELOPER_TOKEN e GOOGLE_CUSTOMER_ID precisam estar configurados.')
  return {
    'x-google-dev-token': dev,
    'x-google-customer-id': cust.replace(/-/g, ''),
    'x-google-oauth-token': await googleAccessToken(),
  }
}

// ---------- chamada das rotas internas ----------

async function internal(ctx: ToolCtx, path: string, headers: Record<string, string>) {
  const r = await fetch(ctx.origin + path, { headers })
  const d = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(d.error || `Rota ${path.split('?')[0]} respondeu ${r.status}`)
  return d
}

// Remove a hierarquia pesada conforme o nivel pedido (evita estourar o contexto da IA)
function trim(campaigns: any[], level: string) {
  const pick = (o: any) => {
    const { adSets, ads, thumbnail, ...rest } = o
    return rest
  }
  if (level === 'ad') return campaigns
  if (level === 'adset') return campaigns.map(c => ({ ...pick(c), adSets: (c.adSets || []).map(pick) }))
  return campaigns.map(pick)
}

const DATE_PRESETS = ['today', 'yesterday', 'last_7d', 'last_14d', 'last_30d', 'this_month', 'last_month']
const GOOGLE_RANGES = ['TODAY', 'YESTERDAY', 'LAST_7_DAYS', 'LAST_14_DAYS', 'LAST_30_DAYS', 'THIS_MONTH', 'LAST_MONTH']

// ---------- ferramentas ----------

export const TOOLS: ToolDef[] = [
  {
    name: 'meta_list_accounts',
    title: 'Listar contas Meta Ads',
    description: 'Lista as contas de anúncios Meta acessíveis pelo token do servidor, com moeda e status.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async (_a, ctx) => {
      const d = await internal(ctx, '/api/meta/validate', { 'x-meta-token': metaToken(ctx) })
      return { user: d.user?.name, accounts: d.accounts, default_account: process.env.META_AD_ACCOUNT_ID || null }
    },
  },
  {
    name: 'meta_get_campaigns',
    title: 'Campanhas Meta Ads',
    description:
      'Métricas de campanhas Meta (gasto, receita, ROAS, CPM, CTR, compras, conversas de WhatsApp/CTWA). ' +
      'Use level="adset" ou "ad" só quando precisar descer na hierarquia, pois a resposta cresce muito.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string', description: 'act_XXXX. Padrão: META_AD_ACCOUNT_ID.' },
        date_preset: { type: 'string', enum: DATE_PRESETS, default: 'last_30d' },
        level: { type: 'string', enum: ['campaign', 'adset', 'ad'], default: 'campaign' },
        status: { type: 'string', enum: ['ACTIVE', 'PAUSED', 'ALL'], default: 'ALL' },
      },
      additionalProperties: false,
    },
    run: async (a, ctx) => {
      const acct = metaAccount(a.account_id, ctx)
      const d = await internal(ctx, `/api/meta/campaigns?account_id=${acct}&date_preset=${a.date_preset || 'last_30d'}`, { 'x-meta-token': metaToken(ctx) })
      let list: any[] = d.campaigns || []
      if (a.status && a.status !== 'ALL') list = list.filter(c => c.status === a.status)
      return { account_id: acct, date_preset: a.date_preset || 'last_30d', count: list.length, campaigns: trim(list, a.level || 'campaign') }
    },
  },
  {
    name: 'meta_get_timeline',
    title: 'Série diária Meta Ads',
    description: 'Gasto, receita, ROAS, cliques e CPM dia a dia da conta Meta.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        date_preset: { type: 'string', enum: DATE_PRESETS, default: 'last_30d' },
      },
      additionalProperties: false,
    },
    run: async (a, ctx) => {
      const acct = metaAccount(a.account_id, ctx)
      return internal(ctx, `/api/meta/timeline?account_id=${acct}&date_preset=${a.date_preset || 'last_30d'}`, { 'x-meta-token': metaToken(ctx) })
    },
  },
  {
    name: 'meta_get_demographics',
    title: 'Demografia Meta Ads',
    description: 'Distribuição de resultados por gênero, faixa etária e região.',
    inputSchema: {
      type: 'object',
      properties: {
        account_id: { type: 'string' },
        date_preset: { type: 'string', enum: DATE_PRESETS, default: 'last_30d' },
      },
      additionalProperties: false,
    },
    run: async (a, ctx) => {
      const acct = metaAccount(a.account_id, ctx)
      return internal(ctx, `/api/meta/demographics?account_id=${acct}&date_preset=${a.date_preset || 'last_30d'}`, { 'x-meta-token': metaToken(ctx) })
    },
  },
  {
    name: 'google_get_campaigns',
    title: 'Campanhas Google Ads',
    description: 'Métricas de campanhas Google Ads (custo, cliques, conversões, valor de conversão, orçamento).',
    inputSchema: {
      type: 'object',
      properties: { date_range: { type: 'string', enum: GOOGLE_RANGES, default: 'LAST_30_DAYS' } },
      additionalProperties: false,
    },
    run: async (a, ctx) => internal(ctx, `/api/google/campaigns?date_range=${a.date_range || 'LAST_30_DAYS'}`, await googleHeaders(ctx)),
  },
  {
    name: 'google_get_timeline',
    title: 'Série diária Google Ads',
    description: 'Custo, cliques e conversões dia a dia no Google Ads.',
    inputSchema: {
      type: 'object',
      properties: { date_range: { type: 'string', enum: GOOGLE_RANGES, default: 'LAST_30_DAYS' } },
      additionalProperties: false,
    },
    run: async (a, ctx) => internal(ctx, `/api/google/timeline?date_range=${a.date_range || 'LAST_30_DAYS'}`, await googleHeaders(ctx)),
  },

  // ---------- escrita (so aparecem com TRAFFIQ_MCP_ALLOW_WRITES=true) ----------
  {
    name: 'meta_set_status',
    title: 'Pausar ou ativar na Meta',
    description:
      'Altera o status de uma campanha, conjunto ou anúncio Meta. ALTERA A CONTA: confirme com o usuário ' +
      'mostrando nome, id e status atual antes de chamar.',
    write: true,
    inputSchema: {
      type: 'object',
      properties: {
        object_id: { type: 'string', description: 'ID da campanha, conjunto ou anúncio.' },
        status: { type: 'string', enum: ['ACTIVE', 'PAUSED'] },
      },
      required: ['object_id', 'status'],
      additionalProperties: false,
    },
    run: async (a, ctx) => {
      const r = await fetch(`${GRAPH}/${encodeURIComponent(a.object_id)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ status: a.status, access_token: metaToken(ctx) }),
      })
      const d: any = await r.json().catch(() => ({ error: { message: `A Meta respondeu ${r.status} sem dados. Tente de novo em instantes.` } }))
      if (d.error) throw new Error(d.error.message)
      return { object_id: a.object_id, status: a.status, success: d.success !== false }
    },
  },
  {
    name: 'meta_set_daily_budget',
    title: 'Ajustar orçamento diário na Meta',
    description:
      'Define o orçamento diário de uma campanha (CBO) ou conjunto (ABO), no valor da moeda da conta ' +
      '(ex.: 150.5 = R$ 150,50). ALTERA A CONTA: mostre o valor atual e o novo e confirme com o usuário antes.',
    write: true,
    inputSchema: {
      type: 'object',
      properties: {
        object_id: { type: 'string' },
        daily_budget: { type: 'number', exclusiveMinimum: 0 },
      },
      required: ['object_id', 'daily_budget'],
      additionalProperties: false,
    },
    run: async (a, ctx) => {
      const cents = Math.round(Number(a.daily_budget) * 100)
      const r = await fetch(`${GRAPH}/${encodeURIComponent(a.object_id)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ daily_budget: String(cents), access_token: metaToken(ctx) }),
      })
      const d: any = await r.json().catch(() => ({ error: { message: `A Meta respondeu ${r.status} sem dados. Tente de novo em instantes.` } }))
      if (d.error) throw new Error(d.error.message)
      return { object_id: a.object_id, daily_budget: a.daily_budget, success: d.success !== false }
    },
  },
]

export const READ_TOOLS = () => TOOLS.filter(t => !t.write)
export const WRITE_TOOLS = () => TOOLS.filter(t => t.write)

export function enabledTools(): ToolDef[] {
  const writes = process.env.TRAFFIQ_MCP_ALLOW_WRITES === 'true'
  return TOOLS.filter(t => !t.write || writes)
}
