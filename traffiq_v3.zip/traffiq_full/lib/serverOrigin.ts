import type { NextApiRequest } from 'next'

// URL que o servidor usa para chamar as proprias rotas /api/*
export function serverOrigin(req: NextApiRequest): string {
  if (process.env.TRAFFIQ_INTERNAL_URL) return process.env.TRAFFIQ_INTERNAL_URL.replace(/\/$/, '')
  const proto = (req.headers['x-forwarded-proto'] as string)?.split(',')[0] || 'http'
  return `${proto}://${req.headers['x-forwarded-host'] || req.headers.host}`
}
