export const fmt = {
  brl: (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
  brlK: (v: number) => v >= 1000 ? `R$ ${(v/1000).toFixed(1)}K` : `R$ ${v.toFixed(0)}`,
  num: (v: number) => v.toLocaleString('pt-BR'),
  numK: (v: number) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : v >= 1000 ? `${(v/1000).toFixed(1)}K` : String(v),
  pct: (v: number) => `${v.toFixed(2)}%`,
  roas: (v: number) => `${v.toFixed(2)}x`,
  roasColor: (v: number) => v >= 5 ? 'roas-high' : v >= 3 ? 'roas-medium' : 'roas-low',
  change: (v: number) => ({ text: `${v > 0 ? '+' : ''}${v.toFixed(1)}%`, cls: v >= 0 ? 'metric-up' : 'metric-down' }),
}
