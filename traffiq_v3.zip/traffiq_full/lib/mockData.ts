// ============================================================
//  TRAFFIQ — Mock Data (realistic Brazilian traffic manager)
// ============================================================

export type Platform = 'meta' | 'google' | 'tiktok'
export type Status   = 'ACTIVE' | 'PAUSED'

// Seeded pseudo-random — same values on server and client (fixes hydration mismatch)
let _seed = 42
function seededRandom(): number {
  _seed = (_seed * 1664525 + 1013904223) & 0xFFFFFFFF
  return ((_seed >>> 0) / 0xFFFFFFFF)
}
function resetSeed() { _seed = 42 }

export interface AdMetrics {
  spend: number; impressions: number; clicks: number; reach: number
  cpm: number; ctr: number; frequency: number
  salesMeta: number; salesDb: number; revenue: number
  profit: number; roas: number; cpa: { meta: number; db: number }
  addToCart?: number; checkouts?: number; pageViews?: number
}

export interface Ad extends AdMetrics {
  id: string; name: string; status: Status
  creativeUrl?: string; postUrl?: string; thumbnail?: string
}

export interface AdSet extends AdMetrics {
  id: string; name: string; status: Status; budget: number; budgetType: 'ABO'
  ads: Ad[]
}

export interface Campaign extends AdMetrics {
  id: string; name: string; status: Status; platform: Platform
  objective: string; budget: number; budgetType: 'CBO' | 'ABO'
  adSets: AdSet[]
}

export interface Client {
  id: string; name: string; logo?: string; industry: string
  campaigns: Campaign[]
}

// ------- helpers -------
const rnd = (min: number, max: number) => Math.round(seededRandom() * (max - min) + min)
const rndF = (min: number, max: number, d = 2) => parseFloat((seededRandom() * (max - min) + min).toFixed(d))

function mkMetrics(spend: number, roas: number, impressions: number): AdMetrics {
  const clicks     = Math.round(impressions * rndF(0.005, 0.025))
  const reach      = Math.round(impressions * rndF(0.6, 0.85))
  const frequency  = parseFloat((impressions / reach).toFixed(2))
  const cpm        = parseFloat(((spend / impressions) * 1000).toFixed(2))
  const ctr        = parseFloat(((clicks / impressions) * 100).toFixed(2))
  const pageViews  = Math.round(clicks * rndF(0.80, 0.96))
  const addToCart  = Math.round(pageViews * rndF(0.10, 0.22))
  const checkouts  = Math.round(addToCart * rndF(0.28, 0.45))
  const salesMeta  = Math.round(checkouts * rndF(0.28, 0.52))
  const salesDb    = Math.round(salesMeta * rndF(0.90, 1.15))
  const revenue    = parseFloat((spend * roas).toFixed(2))
  const profit     = parseFloat((revenue - spend).toFixed(2))
  const cpa        = { meta: parseFloat((spend / (salesMeta || 1)).toFixed(2)), db: parseFloat((spend / (salesDb || 1)).toFixed(2)) }
  return { spend, impressions, clicks, reach, frequency, cpm, ctr, pageViews, addToCart, checkouts, salesMeta, salesDb, revenue, profit, roas, cpa }
}

function sumMetrics(items: AdMetrics[]): AdMetrics {
  const s = items.reduce((acc, m) => ({
    spend: acc.spend + m.spend, impressions: acc.impressions + m.impressions,
    clicks: acc.clicks + m.clicks, reach: acc.reach + m.reach,
    frequency: 0, cpm: 0, ctr: 0,
    pageViews: (acc.pageViews||0) + (m.pageViews||0),
    addToCart: (acc.addToCart||0) + (m.addToCart||0),
    checkouts: (acc.checkouts||0) + (m.checkouts||0),
    salesMeta: acc.salesMeta + m.salesMeta, salesDb: acc.salesDb + m.salesDb,
    revenue: acc.revenue + m.revenue, profit: acc.profit + m.profit,
    roas: 0, cpa: { meta: 0, db: 0 },
  }), { spend:0,impressions:0,clicks:0,reach:0,frequency:0,cpm:0,ctr:0,pageViews:0,addToCart:0,checkouts:0,salesMeta:0,salesDb:0,revenue:0,profit:0,roas:0,cpa:{meta:0,db:0} })
  s.cpm = parseFloat(((s.spend / s.impressions) * 1000).toFixed(2))
  s.ctr = parseFloat(((s.clicks / s.impressions) * 100).toFixed(2))
  s.roas = parseFloat((s.revenue / s.spend).toFixed(2))
  s.frequency = parseFloat((s.impressions / s.reach).toFixed(2))
  s.cpa = { meta: parseFloat((s.spend / (s.salesMeta||1)).toFixed(2)), db: parseFloat((s.spend / (s.salesDb||1)).toFixed(2)) }
  return s
}

// ------- ADS -------
function mkAds(prefix: string, count: number, spendBase: number, roas: number): Ad[] {
  return Array.from({ length: count }, (_, i) => {
    const spend = rnd(spendBase * 0.6, spendBase * 1.4)
    const imp   = rnd(12000, 80000)
    return { id: `${prefix}-ad-${i+1}`, name: `Criativo ${i+1} — ${['Depoimento', 'Produto', 'VSL Curto', 'Oferta', 'Prova Social'][i % 5]}`, status: i < count-1 ? 'ACTIVE' : 'PAUSED', creativeUrl: '', postUrl: 'https://www.instagram.com/p/example/', thumbnail: '', ...mkMetrics(spend, roas + rndF(-0.5, 0.5), imp) }
  })
}

function mkAdSets(prefix: string, count: number, spendBase: number, roas: number): AdSet[] {
  return Array.from({ length: count }, (_, i) => {
    const ads  = mkAds(`${prefix}-as${i+1}`, rnd(2, 4), spendBase / count, roas)
    const base = sumMetrics(ads)
    const budget = rnd(150, 400)
    return { id: `${prefix}-as-${i+1}`, name: `Conjunto ${i+1} — ${['Interesse Amplo', 'LAL 1%', 'Remarketing 30d', 'LAL 3%', 'Interesse Nicho'][i % 5]}`, status: 'ACTIVE', budget, budgetType: 'ABO', ads, ...base }
  })
}

// ------- CAMPAIGNS -------
export const campaigns: Campaign[] = [
  // CAMPAIGN 1 — Main high ROAS
  (() => {
    const adSets = mkAdSets('c1', 3, 4000, 6.5)
    const base = sumMetrics(adSets)
    return { id: 'c1', name: 'PROS — Escala — Topo de Funil — Brasil', status: 'ACTIVE' as Status, platform: 'meta' as Platform, objective: 'OUTCOME_SALES', budget: 350, budgetType: 'CBO' as const, adSets, ...base }
  })(),
  // CAMPAIGN 2 — Remarketing
  (() => {
    const adSets = mkAdSets('c2', 2, 2000, 4.8)
    const base = sumMetrics(adSets)
    return { id: 'c2', name: 'RETARGETING — Visitantes 30d — Checkout Abandono', status: 'ACTIVE' as Status, platform: 'meta' as Platform, objective: 'OUTCOME_SALES', budget: 200, budgetType: 'CBO' as const, adSets, ...base }
  })(),
  // CAMPAIGN 3 — Paused / low ROAS
  (() => {
    const adSets = mkAdSets('c3', 2, 800, 2.1)
    const base = sumMetrics(adSets)
    return { id: 'c3', name: 'TESTE — Criativo Novo — Público Frio — SP', status: 'PAUSED' as Status, platform: 'meta' as Platform, objective: 'OUTCOME_TRAFFIC', budget: 100, budgetType: 'ABO' as const, adSets, ...base }
  })(),
  // CAMPAIGN 4 — Google
  (() => {
    const adSets = mkAdSets('c4', 2, 1500, 3.8)
    const base = sumMetrics(adSets)
    return { id: 'c4', name: 'META — Google Search — Palavras Compra — Marca', status: 'PAUSED' as Status, platform: 'meta' as Platform, objective: 'OUTCOME_SALES', budget: 180, budgetType: 'CBO' as const, adSets, ...base }
  })(),
  // CAMPAIGN 5 — TikTok
  (() => {
    const adSets = mkAdSets('c5', 2, 900, 3.2)
    const base = sumMetrics(adSets)
    return { id: 'c5', name: 'TikTok — UGC — Topo de Funil', status: 'PAUSED' as Status, platform: 'meta' as Platform, objective: 'OUTCOME_TRAFFIC', budget: 120, budgetType: 'CBO' as const, adSets, ...base }
  })(),
]

// ------- TIMELINE DATA (30 days) -------
export function genTimeline(days = 30) {
  const data = []
  const now = new Date()
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i)
    const label = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`
    const spend   = rnd(400, 1400)
    const roas    = rndF(2.5, 7.5)
    const revenue = Math.round(spend * roas)
    const clicks  = rnd(500, 3000)
    const impressions = rnd(20000, 90000)
    data.push({ label, date: d.toISOString().split('T')[0], spend, revenue, roas, clicks, impressions, conversions: Math.round(revenue / rnd(90, 300)) })
  }
  return data
}

// ------- FUNNEL -------
export function genFunnel(base = campaigns) {
  const total = sumMetrics(base)
  const cliques    = total.clicks
  const pageViews  = total.pageViews || Math.round(cliques * 0.89)
  const addToCart  = total.addToCart || Math.round(pageViews * 0.14)
  const checkouts  = total.checkouts || Math.round(addToCart * 0.35)
  const compras    = total.salesDb
  return [
    { label: 'Cliques',     value: cliques,   pct: 100 },
    { label: 'Page Views',  value: pageViews, pct: parseFloat(((pageViews/cliques)*100).toFixed(2)) },
    { label: 'Add to Cart', value: addToCart, pct: parseFloat(((addToCart/pageViews)*100).toFixed(2)) },
    { label: 'Checkouts',   value: checkouts, pct: parseFloat(((checkouts/addToCart)*100).toFixed(2)) },
    { label: 'Compras',     value: compras,   pct: parseFloat(((compras/checkouts)*100).toFixed(2)) },
  ]
}

// ------- DEMOGRAPHICS -------
export const demographics = {
  gender: [
    { name: 'male',    value: 87.7, reach: 142300 },
    { name: 'female',  value: 11.9, reach: 19320 },
    { name: 'unknown', value:  0.4, reach: 650 },
  ],
  age: [
    { name: '18-24', value: 16.2 },
    { name: '25-34', value: 36.1 },
    { name: '35-44', value: 26.7 },
    { name: '45-54', value: 14.3 },
    { name: '55-64', value: 4.9  },
    { name: '65+',   value: 1.8  },
  ],
}

// ------- GEO (Brazil states) -------
export const geoData = [
  { region: 'São Paulo (state)',      reach: 65100, spend: 3240, conversions: 312 },
  { region: 'Minas Gerais',           reach: 21990, spend: 1820, conversions: 98  },
  { region: 'Rio de Janeiro (state)', reach: 18239, spend: 1450, conversions: 84  },
  { region: 'Santa Catarina',         reach: 18041, spend: 980,  conversions: 71  },
  { region: 'Paraná',                 reach: 15814, spend: 890,  conversions: 63  },
  { region: 'Rio Grande do Sul',      reach: 13870, spend: 760,  conversions: 55  },
  { region: 'Bahia',                  reach: 10342, spend: 540,  conversions: 38  },
  { region: 'Goiás',                  reach:  8521, spend: 420,  conversions: 29  },
  { region: 'Ceará',                  reach:  7041, spend: 360,  conversions: 24  },
  { region: 'Pernambuco',             reach:  6005, spend: 290,  conversions: 19  },
]

// ------- TRAFFIC SOURCES -------
export const trafficSources = [
  { name: 'Facebook (fb)',  value: 52.1, color: '#1877F2' },
  { name: 'Instagram (ig)', value: 18.4, color: '#E1306C' },
  { name: 'Google',         value: 14.2, color: '#EA4335' },
  { name: 'Orgânico',       value:  8.5, color: '#16A34A' },
  { name: 'Direct',         value:  4.1, color: '#4B5563' },
  { name: 'TikTok',         value:  2.7, color: '#FF0050' },
]

// ------- HOURLY SALES -------
export function genHourlySales() {
  return Array.from({ length: 24 }, (_, h) => {
    const peak = h >= 19 && h <= 22
    const mid  = (h >= 12 && h <= 14) || (h >= 8 && h <= 10)
    const base = peak ? rnd(12,28) : mid ? rnd(6,14) : rnd(0,6)
    return { hour: `${String(h).padStart(2,'0')}h`, sales: base, revenue: base * rnd(85, 340) }
  })
}

// ------- ACCOUNT SUMMARY -------
export function getAccountSummary() {
  const all = sumMetrics(campaigns)
  return {
    ...all,
    activeCampaigns: campaigns.filter(c => c.status === 'ACTIVE').length,
    totalCampaigns:  campaigns.length,
    avgFrequency:    all.frequency,
    ctr:             all.ctr,
  }
}

// ------- INSIGHTS / OPTIMIZATION -------
export const insights = [
  { id: 'i1', type: 'opportunity', priority: 'high',   platform: 'meta',   title: 'Criativo c1-ad-1 com ROAS 8.2x — duplique o orçamento', description: 'Este criativo está com performance muito acima da média. Considere aumentar o orçamento do conjunto em 40%.', impact: '+R$ 2.400 receita estimada/mês', action: 'Aumentar orçamento' },
  { id: 'i2', type: 'warning',     priority: 'high',   platform: 'meta',   title: 'Frequência acima de 4x em Conjunto 2 da Campanha 1', description: 'Alta frequência indica saturação de audiência. Renove os criativos ou expanda o público para manter eficiência.', impact: 'Evitar desperdício de verba', action: 'Ver audiência' },
  { id: 'i3', type: 'opportunity', priority: 'medium', platform: 'google', title: 'Palavras de cauda longa com baixo CPC e alta conversão', description: '3 palavras-chave long-tail estão gerando conversões com CPC 60% menor. Aumente os lances.', impact: '+18 conversões estimadas/semana', action: 'Ver palavras-chave' },
  { id: 'i4', type: 'alert',       priority: 'high',   platform: 'meta',   title: 'Campanha 3 pausada com R$ 320 sem retorno', description: 'A campanha de teste foi pausada mas consumiu orçamento sem conversões. Revise antes de reativar.', impact: 'R$ 320 investidos com ROAS 2.1x', action: 'Analisar campanha' },
  { id: 'i5', type: 'opportunity', priority: 'medium', platform: 'meta',   title: 'Horário 19h-22h gera 60% das conversões — concentre verba', description: 'Programe o dayparting para concentrar budget nos horários de pico e reduzir gastos em horários ruins.', impact: '-15% CPV estimado', action: 'Configurar dayparting' },
  { id: 'i6', type: 'info',        priority: 'low',    platform: 'tiktok', title: 'TikTok com CTR 3.2% — acima da média do segmento', description: 'Seus UGC no TikTok têm CTR superior à média do mercado. Considere aumentar investimento nessa plataforma.', impact: 'Diversificação de canal', action: 'Ver criativos' },
]
