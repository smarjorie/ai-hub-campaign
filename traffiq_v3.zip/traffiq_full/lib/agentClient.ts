// lib/agentClient.ts - chamadas do navegador para o agente
import { storage } from './useMetaData'

export interface ChatTurn { role: 'user' | 'assistant'; content: string }
export interface Proposal { id: string; tool: string; args: Record<string, any>; title: string; reason: string }
export interface AgentReply { reply: string; proposals: Proposal[]; toolsUsed: string[] }

// Credenciais que o usuario conectou em Integracoes (localStorage), enviadas ao servidor por requisicao
function creds() {
  const m = storage.getMeta()
  const g = storage.getGoogle()
  return {
    meta: m.token ? { token: m.token, accountId: m.accountId } : undefined,
    google: g.devToken && g.oauthToken && g.customerId ? g : undefined,
  }
}

export async function askAgent(messages: ChatTurn[], signal?: AbortSignal): Promise<AgentReply> {
  const r = await fetch('/api/agent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, creds: creds() }),
    signal,
  })
  const d = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(d.error || `O agente respondeu ${r.status}.`)
  return d
}

export async function executeProposal(p: Proposal): Promise<{ ok: boolean; error?: string }> {
  const r = await fetch('/api/agent/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tool: p.tool, args: p.args, creds: creds() }),
  })
  const d = await r.json().catch(() => ({}))
  return r.ok ? { ok: true } : { ok: false, error: d.error || 'A plataforma recusou a alteração.' }
}

export function describeArgs(p: Proposal): string {
  const id = p.args.object_id ? `ID ${p.args.object_id}` : ''
  if (p.tool === 'meta_set_status') return `${id}, novo status: ${p.args.status === 'PAUSED' ? 'pausado' : 'ativo'}`
  if (p.tool === 'meta_set_daily_budget') {
    const v = Number(p.args.daily_budget || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
    return `${id}, novo orçamento diário: ${v}`
  }
  return id
}
