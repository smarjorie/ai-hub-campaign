// lib/connections.ts
// Integracoes customizadas (servidor MCP ou API propria). Meta e Google ficam no useMetaData.

import { useCallback, useEffect, useState } from 'react'

export interface CustomIntegration {
  id: string
  name: string
  type: 'mcp' | 'rest'
  url: string
  authHeader?: string
  authValue?: string
  createdAt: string
}

const KEY = 'traffiq_custom_integrations'

function read(): CustomIntegration[] {
  try { return JSON.parse(window.localStorage.getItem(KEY) || '[]') } catch { return [] }
}
function write(list: CustomIntegration[]) {
  try { window.localStorage.setItem(KEY, JSON.stringify(list)) } catch { /* storage indisponivel */ }
}

export function useCustomIntegrations() {
  const [list, setList] = useState<CustomIntegration[]>([])
  useEffect(() => { setList(read()) }, [])

  const add = useCallback((c: Omit<CustomIntegration, 'id' | 'createdAt'>) => {
    const next = [...read(), { ...c, id: 'cust_' + Date.now().toString(36), createdAt: new Date().toISOString() }]
    write(next); setList(next)
  }, [])

  const remove = useCallback((id: string) => {
    const next = read().filter(c => c.id !== id)
    write(next); setList(next)
  }, [])

  return { list, add, remove }
}
