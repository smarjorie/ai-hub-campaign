import { useEffect, useRef, useState } from 'react'
import clsx from 'clsx'
import { PanelLeft, ChevronDown } from 'lucide-react'
import { NAV_MAIN, NAV_FOOTER, type NavGroup, type ViewKey } from './nav'

interface Props {
  current: ViewKey
  onNavigate: (key: ViewKey) => void
  expanded: boolean
  onToggle: () => void
}

export default function NavRail({ current, onNavigate, expanded, onToggle }: Props) {
  const [openId, setOpenId] = useState<string | null>(null)
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const railRef = useRef<HTMLElement>(null)

  useEffect(() => {
    function onDoc(e: MouseEvent) { if (railRef.current && !railRef.current.contains(e.target as Node)) setOpenId(null) }
    function onKey(e: KeyboardEvent) { if (e.key === 'Escape') setOpenId(null) }
    document.addEventListener('mousedown', onDoc)
    document.addEventListener('keydown', onKey)
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey) }
  }, [])

  // no modo expandido, o grupo da tela atual fica aberto
  useEffect(() => {
    if (!expanded) return
    const g = NAV_MAIN.find(g => g.children?.some(c => c.key === current))
    if (g) setOpenId(g.id)
  }, [expanded, current])

  const go = (key: ViewKey) => { onNavigate(key); if (!expanded) setOpenId(null) }
  const hoverOpen = (id: string) => { if (expanded) return; if (closeTimer.current) clearTimeout(closeTimer.current); setOpenId(id) }
  const hoverClose = () => { if (expanded) return; closeTimer.current = setTimeout(() => setOpenId(null), 160) }

  const isActive = (g: NavGroup) => g.key === current || !!g.children?.some(c => c.key === current)

  const btnCls = (active: boolean, open: boolean) => clsx(
    'flex items-center rounded-xl transition-colors outline-none focus-visible:ring-2 focus-visible:ring-accent/40',
    expanded ? 'h-10 w-full gap-3 px-3' : 'h-11 w-11 justify-center',
    active || open ? 'bg-[#F0F1F4]' : 'hover:bg-[#F0F1F4]',
  )

  const renderGroup = (g: NavGroup) => {
    const Icon = g.icon
    const active = isActive(g)
    const open = openId === g.id
    const icon = (
      <Icon size={20} strokeWidth={1.75} aria-hidden
        className={clsx('shrink-0', g.accent ? 'text-accent' : active ? 'text-ink' : 'text-muted')} />
    )

    if (g.key) {
      return (
        <li key={g.id} className="relative" onMouseEnter={() => hoverOpen(g.id)} onMouseLeave={hoverClose}>
          <button type="button" className={btnCls(active, false)} onClick={() => go(g.key!)}
            aria-current={active ? 'page' : undefined} aria-label={g.label}>
            {icon}
            {expanded && <span className={clsx('text-[14px]', active ? 'font-semibold text-ink' : 'text-muted-2')}>{g.label}</span>}
          </button>
          {!expanded && open && (
            <div role="tooltip" className="pointer-events-none absolute left-[56px] top-1/2 z-50 -translate-y-1/2 whitespace-nowrap rounded-lg bg-ink px-2.5 py-1.5 text-[12px] font-medium text-white shadow-lg">
              {g.label}
            </div>
          )}
        </li>
      )
    }

    return (
      <li key={g.id} className="relative" onMouseEnter={() => hoverOpen(g.id)} onMouseLeave={hoverClose}>
        <button type="button" className={btnCls(active, open)} aria-expanded={open} aria-label={g.label}
          onClick={() => setOpenId(expanded && open ? null : g.id)}>
          {icon}
          {expanded && (
            <>
              <span className={clsx('flex-1 text-left text-[14px]', active ? 'font-semibold text-ink' : 'text-muted-2')}>{g.label}</span>
              <ChevronDown size={15} aria-hidden className={clsx('text-muted transition-transform', open && 'rotate-180')} />
            </>
          )}
        </button>

        {!expanded && open && (
          <div className="absolute left-[56px] top-0 z-50 w-[232px] overflow-hidden rounded-2xl border border-border bg-white shadow-[0_12px_32px_-8px_rgba(17,24,39,0.18),0_2px_6px_rgba(17,24,39,0.06)]">
            <p className="border-b border-border px-4 py-3 text-[14px] font-semibold text-ink">{g.label}</p>
            <ul className="p-1.5">{g.children!.map(c => leaf(c))}</ul>
          </div>
        )}
        {expanded && open && (
          <ul className="mb-1 ml-[22px] mt-0.5 border-l border-border pl-2">{g.children!.map(c => leaf(c))}</ul>
        )}
      </li>
    )
  }

  const leaf = (c: { key: ViewKey; label: string }) => (
    <li key={c.key}>
      <button type="button" onClick={() => go(c.key)} aria-current={c.key === current ? 'page' : undefined}
        className={clsx(
          'block w-full rounded-lg px-3 py-2 text-left text-[14px] transition-colors outline-none focus-visible:ring-2 focus-visible:ring-accent/40',
          c.key === current ? 'bg-[#F0F1F4] font-medium text-ink' : 'text-muted-2 hover:bg-[#F0F1F4] hover:text-ink',
        )}>
        {c.label}
      </button>
    </li>
  )

  return (
    <nav ref={railRef} aria-label="Navegação principal"
      className={clsx(
        'fixed inset-y-0 left-0 z-40 flex flex-col border-r border-border bg-white transition-[width] duration-200',
        expanded ? 'w-[232px] px-3' : 'w-[68px] items-center',
      )}>
      <div className={clsx('flex h-16 items-center', expanded ? 'gap-2.5 px-1' : 'justify-center')}>
        <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-ink text-[13px] font-bold text-white">Tq</span>
        {expanded && <span className="text-[15px] font-semibold tracking-tight text-ink">Traffiq</span>}
      </div>
      <ul className={clsx('mt-2 flex flex-col gap-1.5', expanded && 'w-full')}>{NAV_MAIN.map(renderGroup)}</ul>
      <div className={clsx('mt-auto flex flex-col gap-1.5 border-t border-border py-3', expanded ? 'w-full' : 'items-center')}>
        <ul className={clsx('flex flex-col gap-1.5', expanded && 'w-full')}>{NAV_FOOTER.map(renderGroup)}</ul>
        <button type="button" onClick={onToggle} aria-label={expanded ? 'Recolher menu' : 'Expandir menu'}
          className={clsx(
            'flex items-center rounded-xl text-muted transition-colors hover:bg-[#F0F1F4] outline-none focus-visible:ring-2 focus-visible:ring-accent/40',
            expanded ? 'h-10 w-full gap-3 px-3' : 'h-11 w-11 justify-center',
          )}>
          <PanelLeft size={20} strokeWidth={1.75} aria-hidden />
          {expanded && <span className="text-[14px]">Recolher</span>}
        </button>
      </div>
    </nav>
  )
}
