import {
  Sparkles, LayoutGrid, MessageCircle, Megaphone, Zap, Plug, type LucideIcon,
} from 'lucide-react'

// Cada tela do app tem uma chave. index.tsx traduz a chave em modo (ads/bsp/hybrid) + pagina.
export type ViewKey =
  | 'assistant' | 'overview' | 'analytics' | 'bsp' | 'hybrid'
  | 'campaigns' | 'creatives' | 'report' | 'automations' | 'insights' | 'integrations'

export interface NavLeaf { key: ViewKey; label: string }
export interface NavGroup {
  id: string
  label: string
  icon: LucideIcon
  key?: ViewKey          // item direto
  children?: NavLeaf[]   // item com flyout
  accent?: boolean
}

export const NAV_MAIN: NavGroup[] = [
  { id: 'assistant', label: 'Assistente', icon: Sparkles, key: 'assistant', accent: true },
  {
    id: 'painel', label: 'Painel', icon: LayoutGrid,
    children: [
      { key: 'overview', label: 'Visão geral' },
      { key: 'analytics', label: 'Performance analítica' },
    ],
  },
  {
    id: 'conversas', label: 'Conversas', icon: MessageCircle,
    children: [
      { key: 'bsp', label: 'WhatsApp CRM' },
      { key: 'hybrid', label: 'Visão híbrida' },
    ],
  },
  {
    id: 'marketing', label: 'Marketing', icon: Megaphone,
    children: [
      { key: 'campaigns', label: 'Campanhas' },
      { key: 'creatives', label: 'Criativos' },
      { key: 'report', label: 'Enviar relatório' },
    ],
  },
  {
    id: 'automacoes', label: 'Automações', icon: Zap,
    children: [
      { key: 'automations', label: 'Todas as automações' },
      { key: 'insights', label: 'Insights' },
    ],
  },
]

export const NAV_FOOTER: NavGroup[] = [
  { id: 'integracoes', label: 'Integrações', icon: Plug, key: 'integrations' },
]

// Para o breadcrumb do topo
export function locate(key: ViewKey): { group: string; label: string } {
  for (const g of [...NAV_MAIN, ...NAV_FOOTER]) {
    if (g.key === key) return { group: g.label, label: g.label }
    const leaf = g.children?.find(c => c.key === key)
    if (leaf) return { group: g.label, label: leaf.label }
  }
  return { group: '', label: '' }
}
