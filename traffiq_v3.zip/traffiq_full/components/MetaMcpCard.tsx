import { useState } from 'react'
import { Plug, ExternalLink, CheckCircle2, Info } from 'lucide-react'

interface Props {
  enabled: boolean
  onToggle: (v: boolean) => void
}

export default function MetaMcpCard({ enabled, onToggle }: Props) {
  const [showInfo, setShowInfo] = useState(false)

  return (
    <div className="card p-5">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
          style={{ background:'rgba(24,119,242,0.12)', color:'#1877F2', border:'1px solid rgba(24,119,242,0.2)' }}>∞</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="font-semibold text-ink">Meta Ads — MCP Connector</span>
            <span className="badge" style={{ background:'rgba(30,107,255,0.1)', color:'#1E6BFF', border:'1px solid rgba(30,107,255,0.15)', fontSize:10 }}>MCP</span>
            {enabled
              ? <span className="badge-green"><span className="status-active mr-1"/>Ativo</span>
              : <span className="badge" style={{ background:'rgba(90,96,128,0.12)', color:'#6B7280', border:'1px solid rgba(90,96,128,0.15)' }}>Inativo</span>}
          </div>
          <p className="text-xs mb-3" style={{ color:'#6B7280' }}>
            Conecte via MCP para uso na conversa do Claude (criar campanhas, pausar anúncios, consultar insights diretamente no chat).
          </p>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Toggle */}
            <label className="toggle-wrap cursor-pointer">
              <input type="checkbox" className="toggle-input" checked={enabled} onChange={e => onToggle(e.target.checked)} />
              <span className="toggle-slider" />
            </label>
            <span className="text-sm" style={{ color: enabled ? '#16A34A' : '#6B7280' }}>
              {enabled ? 'MCP ativo nesta sessão' : 'Ativar MCP'}
            </span>

            <button onClick={() => setShowInfo(!showInfo)} className="btn-ghost py-1 px-2 text-xs flex items-center gap-1">
              <Info size={12}/> Como funciona
            </button>

            <a href="https://mcp.facebook.com/ads" target="_blank" rel="noreferrer"
              className="text-xs flex items-center gap-1 transition-colors" style={{ color:'#6B7280' }}
              onMouseEnter={e=>(e.currentTarget.style.color='#1877F2')}
              onMouseLeave={e=>(e.currentTarget.style.color='#6B7280')}>
              <ExternalLink size={11}/> mcp.facebook.com/ads
            </a>
          </div>

          {showInfo && (
            <div className="mt-3 p-3 rounded-xl text-xs flex flex-col gap-1.5"
              style={{ background:'rgba(30,107,255,0.06)', border:'1px solid rgba(30,107,255,0.12)' }}>
              <div className="font-semibold text-ink mb-1">Como ativar o Meta MCP:</div>
              <div style={{ color:'#4B5563' }}>1. No Claude.ai → Settings → Integrações → Meta → Conectar</div>
              <div style={{ color:'#4B5563' }}>2. Autorize o acesso à sua conta Meta Ads</div>
              <div style={{ color:'#4B5563' }}>3. Volte aqui e ative o toggle acima</div>
              <div style={{ color:'#4B5563' }}>4. Com o MCP ativo, você pode pedir ao Claude para pausar campanhas, criar anúncios e consultar métricas diretamente no chat.</div>
              <div className="mt-1 flex items-center gap-1.5" style={{ color:'#1E6BFF' }}>
                <CheckCircle2 size={11}/> O MCP opera em paralelo com a API direta — ambos podem estar ativos.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
