import { useEffect, useMemo, useState } from 'react'
import clsx from 'clsx'
import { Plus, Play, Loader2, Trash2, ShieldCheck, Clock, ChevronDown } from 'lucide-react'
import Markdown from '@/components/assistant/Markdown'
import { Modal, Field } from '@/components/integrations/ui'
import { askAgent } from '@/lib/agentClient'

type Freq = 'daily' | 'weekly' | 'manual'

interface Automation {
  id: string
  name: string
  prompt: string
  freq: Freq
  platforms: ('meta' | 'google')[]
  createdAt: string
  lastRunAt?: string
  lastResult?: string
  lastError?: string
}

interface Template {
  id: string
  group: 'Monitoramento' | 'Relatórios' | 'Alertas'
  name: string
  desc: string
  freq: Freq
  platforms: ('meta' | 'google')[]
  prompt: string
  readOnly?: boolean
}

const TEMPLATES: Template[] = [
  {
    id: 'health', group: 'Monitoramento', name: 'Saúde das contas',
    desc: 'Procura campanhas sem entrega, gasto sem resultado e contas desconectadas.',
    freq: 'daily', platforms: ['meta', 'google'], readOnly: true,
    prompt: 'Faça uma auditoria de saúde das contas conectadas: campanhas ativas sem entrega, gasto sem nenhum resultado nos últimos 3 dias e qualquer erro de acesso. Liste só o que precisa de ação, do mais urgente ao menos.',
  },
  {
    id: 'daily', group: 'Relatórios', name: 'Resumo diário',
    desc: 'Gasto de ontem, o que foi bem, riscos e as 3 ações do dia.',
    freq: 'daily', platforms: ['meta', 'google'],
    prompt: 'Resuma o dia de ontem: investimento total, resultados, custo por resultado por plataforma, o que foi bem, os riscos e as 3 ações mais importantes para hoje.',
  },
  {
    id: 'weekly', group: 'Relatórios', name: 'Relatório semanal',
    desc: 'Desempenho por canal e o que de fato mudou, pronto para o cliente.',
    freq: 'weekly', platforms: ['meta', 'google'],
    prompt: 'Gere o relatório da última semana comparado à semana anterior: investimento, conversões, CPA e ROAS por canal, as 3 maiores mudanças e o motivo provável, e 3 próximos passos. Linguagem para enviar ao cliente.',
  },
  {
    id: 'cpa', group: 'Alertas', name: 'CPA acima da meta',
    desc: 'Aponta campanhas e conjuntos que passaram do CPA alvo e propõe pausas.',
    freq: 'daily', platforms: ['meta'],
    prompt: 'Liste as campanhas e conjuntos da Meta com CPA acima de R$ 50 nos últimos 3 dias e gasto maior que R$ 100. Para os piores casos, proponha pausar (não execute).',
  },
  {
    id: 'fatigue', group: 'Alertas', name: 'Fadiga de criativo',
    desc: 'Frequência subindo e CTR caindo nos últimos 7 dias.',
    freq: 'weekly', platforms: ['meta'],
    prompt: 'Encontre anúncios da Meta com sinais de fadiga nos últimos 7 dias: frequência acima de 3 e CTR em queda. Sugira quais trocar primeiro.',
  },
]

const KEY = 'traffiq_automations'
const FREQ_LABEL: Record<Freq, string> = { daily: 'Todo dia', weekly: 'Toda semana', manual: 'Manual' }
const FREQ_MS: Record<Freq, number> = { daily: 864e5, weekly: 6048e5, manual: Infinity }

function load(): Automation[] { try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] } }
function save(list: Automation[]) { try { localStorage.setItem(KEY, JSON.stringify(list)) } catch { /* ignore */ } }

function isDue(a: Automation): boolean {
  if (a.freq === 'manual') return false
  if (!a.lastRunAt) return true
  return Date.now() - new Date(a.lastRunAt).getTime() >= FREQ_MS[a.freq]
}

function fmtWhen(iso?: string) {
  if (!iso) return 'Nunca executada'
  return 'Última execução ' + new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
}

export default function Automations({ metaConnected, googleConnected }: { metaConnected: boolean; googleConnected: boolean }) {
  const [list, setList] = useState<Automation[]>([])
  const [draft, setDraft] = useState<Omit<Automation, 'id' | 'createdAt'> | null>(null)
  const [running, setRunning] = useState<string | null>(null)
  const [open, setOpen] = useState<string | null>(null)

  useEffect(() => { setList(load()) }, [])
  const update = (next: Automation[]) => { setList(next); save(next) }
  const due = useMemo(() => list.filter(isDue), [list])
  const connected = { meta: metaConnected, google: googleConnected }

  function applyTemplate(t: Template) {
    setDraft({ name: t.name, prompt: t.prompt, freq: t.freq, platforms: t.platforms })
  }

  function createDraft() {
    if (!draft || !draft.name.trim() || !draft.prompt.trim()) return
    update([{ ...draft, id: 'auto_' + Date.now().toString(36), createdAt: new Date().toISOString() }, ...list])
    setDraft(null)
  }

  async function run(a: Automation) {
    setRunning(a.id); setOpen(a.id)
    try {
      const r = await askAgent([{ role: 'user', content: a.prompt }])
      const extra = r.proposals.length
        ? '\n\nAlterações sugeridas (confirme no Assistente para aplicar):\n' + r.proposals.map(p => `- ${p.title}: ${p.reason}`).join('\n')
        : ''
      update(load().map(x => x.id === a.id ? { ...x, lastRunAt: new Date().toISOString(), lastResult: r.reply + extra, lastError: undefined } : x))
    } catch (e: any) {
      update(load().map(x => x.id === a.id ? { ...x, lastRunAt: new Date().toISOString(), lastError: e.message } : x))
    } finally {
      setRunning(null)
    }
  }

  const groups = Array.from(new Set(TEMPLATES.map(t => t.group)))

  return (
    <div className="mx-auto max-w-[1080px]">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-semibold tracking-[-0.02em] text-ink">Automações</h1>
          <p className="mt-1.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
            Tarefas recorrentes que o agente executa por você. As automações só leem as contas: qualquer alteração sugerida volta para sua confirmação.
          </p>
        </div>
        <button type="button" className="btn-primary" onClick={() => setDraft({ name: '', prompt: '', freq: 'daily', platforms: ['meta'] })}>
          <Plus size={16} /> Criar automação
        </button>
      </header>

      {/* Suas automacoes */}
      {list.length > 0 && (
        <section className="mb-12" aria-labelledby="mine">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 id="mine" className="text-[15px] font-semibold text-ink">Suas automações</h2>
            {due.length > 0 && <p className="text-[13px] text-[#B45309]">{due.length} {due.length === 1 ? 'pendente' : 'pendentes'} desde a última execução</p>}
          </div>
          <ul className="divide-y divide-border overflow-hidden rounded-2xl border border-border bg-white">
            {list.map(a => {
              const expanded = open === a.id
              const blocked = a.platforms.every(p => !connected[p])
              return (
                <li key={a.id}>
                  <div className="flex flex-wrap items-center gap-4 px-5 py-4">
                    <button type="button" onClick={() => setOpen(expanded ? null : a.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left" aria-expanded={expanded}>
                      <ChevronDown size={16} className={clsx('shrink-0 text-muted transition-transform', expanded && 'rotate-180')} />
                      <span className="min-w-0">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-[15px] font-medium text-ink">{a.name}</span>
                          {isDue(a) && <span className="badge-yellow">Pendente</span>}
                        </span>
                        <span className="mt-0.5 flex items-center gap-1.5 text-[13px] text-muted">
                          <Clock size={12} /> {FREQ_LABEL[a.freq]}, {fmtWhen(a.lastRunAt).toLowerCase()}
                        </span>
                      </span>
                    </button>
                    <div className="flex items-center gap-1.5">
                      <button type="button" className="btn-secondary py-1.5 text-[13px]" disabled={!!running || blocked} onClick={() => run(a)}
                        title={blocked ? 'Conecte a plataforma em Integrações' : undefined}>
                        {running === a.id ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
                        {running === a.id ? 'Executando...' : 'Executar agora'}
                      </button>
                      <button type="button" aria-label={`Excluir ${a.name}`} className="rounded-lg p-2 text-muted hover:bg-[#FDECEC] hover:text-danger"
                        onClick={() => update(list.filter(x => x.id !== a.id))}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  {expanded && (
                    <div className="border-t border-border bg-surface-2 px-5 py-4 pl-12">
                      {running === a.id && <p className="inline-flex items-center gap-2 text-[14px] text-muted-2"><Loader2 size={14} className="animate-spin" /> Consultando suas contas...</p>}
                      {running !== a.id && a.lastError && <p role="alert" className="text-[14px] text-[#B91C1C]">{a.lastError}</p>}
                      {running !== a.id && !a.lastError && a.lastResult && <Markdown text={a.lastResult} />}
                      {running !== a.id && !a.lastResult && !a.lastError && <p className="text-[14px] text-muted-2">Execute uma vez para ver o resultado aqui.</p>}
                      <details className="mt-4 text-[13px] text-muted">
                        <summary className="cursor-pointer">Instrução da automação</summary>
                        <p className="mt-2 whitespace-pre-wrap text-muted-2">{a.prompt}</p>
                      </details>
                    </div>
                  )}
                </li>
              )
            })}
          </ul>
        </section>
      )}

      {/* Recomendadas */}
      <section aria-labelledby="rec">
        <h2 id="rec" className="text-[15px] font-semibold text-ink">Recomendadas</h2>
        <p className="mb-5 mt-1 text-[14px] text-muted-2">Comece por uma tarefa pronta. A instrução e a frequência vêm preenchidas e dá para ajustar tudo antes de salvar.</p>
        {groups.map(g => (
          <div key={g} className="mb-7">
            <h3 className="mb-3 text-[13px] font-medium text-muted">{g}</h3>
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {TEMPLATES.filter(t => t.group === g).map(t => (
                <article key={t.id} className="flex flex-col rounded-2xl border border-border bg-white p-5">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-[15px] font-semibold text-ink">{t.name}</h4>
                    {t.readOnly && <span className="badge-blue shrink-0"><ShieldCheck size={12} /> Só leitura</span>}
                  </div>
                  <p className="mt-1.5 flex-1 text-[14px] leading-relaxed text-muted-2">{t.desc}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="flex items-center gap-2 text-[13px] text-muted">
                      {t.platforms.map(p => (
                        <span key={p} className="grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold text-white" style={{ background: p === 'meta' ? '#1877F2' : '#1A73E8' }}>
                          {p === 'meta' ? 'M' : 'G'}
                        </span>
                      ))}
                      {FREQ_LABEL[t.freq]}
                    </span>
                    <button type="button" className="btn-secondary py-1.5 text-[13px]" onClick={() => applyTemplate(t)}>Usar</button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        ))}
      </section>

      <Modal
        open={!!draft}
        onClose={() => setDraft(null)}
        title={draft?.name ? `Automação: ${draft.name}` : 'Nova automação'}
        subtitle="O agente segue esta instrução a cada execução, com os dados das contas conectadas."
        footer={<>
          <button type="button" className="btn-ghost" onClick={() => setDraft(null)}>Cancelar</button>
          <button type="button" className="btn-primary" disabled={!draft?.name.trim() || !draft?.prompt.trim()} onClick={createDraft}>Salvar automação</button>
        </>}
      >
        {draft && (
          <div className="space-y-4">
            <Field label="Nome" value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} />
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink">Instrução</span>
              <textarea rows={5} value={draft.prompt} onChange={e => setDraft({ ...draft, prompt: e.target.value })} className="input-field resize-y leading-relaxed" />
            </label>
            <div>
              <span className="mb-1.5 block text-[13px] font-medium text-ink">Frequência</span>
              <div className="inline-flex rounded-lg bg-bg p-1" role="radiogroup">
                {(Object.keys(FREQ_LABEL) as Freq[]).map(f => (
                  <button key={f} type="button" role="radio" aria-checked={draft.freq === f} onClick={() => setDraft({ ...draft, freq: f })}
                    className={clsx('rounded-md px-3 py-1.5 text-[13px] font-medium', draft.freq === f ? 'bg-white text-ink shadow-sm' : 'text-muted-2 hover:text-ink')}>
                    {FREQ_LABEL[f]}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[12px] leading-relaxed text-muted">
                Por enquanto a execução é disparada por você: quando passar o prazo, a automação aparece como pendente.
              </p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
