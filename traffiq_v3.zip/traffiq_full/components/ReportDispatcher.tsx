import { useState, useMemo, useEffect } from 'react'
import {
  Send, Phone, Eye, EyeOff, ChevronDown, CheckCircle2,
  Copy, ExternalLink, User, MessageSquare, BarChart2,
  DollarSign, ShoppingCart, TrendingUp, Users, Zap,
  Edit3, Check, X, Settings, AlertCircle, Wifi, WifiOff, RefreshCw,
} from 'lucide-react'
import { fmt } from '@/lib/format'

// ── Types ─────────────────────────────────────────────────────────────────────
interface Campaign {
  id: string; name: string; platform: string; status: string
  spend: number; revenue: number; roas: number; impressions: number
  clicks: number; ctr: number; cpm: number; salesDb: number
  addToCart?: number; checkouts?: number; pageViews?: number
  cpa?: { db: number }
}
interface Summary {
  spend: number; revenue: number; roas: number; clicks: number
  impressions: number; cpm: number; salesDb: number; ctr: number
}
interface Props {
  campaigns:   Campaign[]
  summary:     Summary
  period:      string
  accountName?: string
}

// ── BSP storage ───────────────────────────────────────────────────────────────
const BSP_KEY = 'traffiq_bsp_config'
interface BspConfig {
  provider:       string
  token:          string
  endpoint:       string
  phoneNumberId:  string
}
function loadBsp(): BspConfig {
  try { return JSON.parse(localStorage.getItem(BSP_KEY) || 'null') || { provider:'meta_cloud', token:'', endpoint:'', phoneNumberId:'' } }
  catch { return { provider:'meta_cloud', token:'', endpoint:'', phoneNumberId:'' } }
}
function saveBsp(c: BspConfig) { localStorage.setItem(BSP_KEY, JSON.stringify(c)) }

// ── Metric config ─────────────────────────────────────────────────────────────
const METRICS = [
  { key: 'impressions', label: 'Impressões',     emoji: '👁️',  icon: Eye,          fmt: (v: number) => fmt.numK(v) },
  { key: 'clicks',      label: 'Cliques',        emoji: '🖱️',  icon: BarChart2,    fmt: (v: number) => fmt.numK(v) },
  { key: 'spend',       label: 'Investimento',   emoji: '💰',  icon: DollarSign,   fmt: (v: number) => fmt.brl(v)  },
  { key: 'revenue',     label: 'Receita',        emoji: '💵',  icon: TrendingUp,   fmt: (v: number) => fmt.brl(v)  },
  { key: 'roas',        label: 'ROAS',           emoji: '📈',  icon: Zap,          fmt: (v: number) => fmt.roas(v) },
  { key: 'salesDb',     label: 'Compras / Leads',emoji: '🎯',  icon: ShoppingCart, fmt: (v: number) => fmt.num(v)  },
  { key: 'cpa.db',      label: 'Custo por Lead', emoji: '💲',  icon: Users,        fmt: (v: number) => fmt.brl(v)  },
  { key: 'ctr',         label: 'CTR',            emoji: '📊',  icon: BarChart2,    fmt: (v: number) => fmt.pct(v)  },
  { key: 'cpm',         label: 'CPM',            emoji: '💲',  icon: DollarSign,   fmt: (v: number) => fmt.brl(v)  },
]

const PROVIDERS = [
  { id: 'meta_cloud', label: 'Meta Cloud API',  hint: 'graph.facebook.com' },
  { id: 'zenvia',     label: 'Zenvia',           hint: 'api.zenvia.com' },
  { id: 'twilio',     label: 'Twilio',           hint: 'Token como "SID:AuthToken"' },
  { id: 'custom',     label: 'Endpoint próprio', hint: 'POST Bearer token' },
]

const OBJECTIVES = [
  'E-commerce (vendas)', 'Geração de Leads', 'Mensagens (WhatsApp)',
  'Tráfego para site', 'Reconhecimento de marca', 'Outro',
]

function getVal(obj: any, path: string): number {
  return path.split('.').reduce((o: any, k: string) => o?.[k], obj) ?? 0
}

// ── Message builder ───────────────────────────────────────────────────────────
function buildMsg(opts: {
  clientName: string; period: string; accountName: string
  selectedMetrics: string[]; summary: Summary
  topCampaigns: Campaign[]; note: string; objective: string
}): string {
  const { clientName, period, accountName, selectedMetrics, summary, topCampaigns, note, objective } = opts
  const lines: string[] = []

  lines.push(`Olá${clientName ? ` *${clientName}*` : ''}! 👋`)
  lines.push('')
  lines.push(`Aqui está o resumo das suas campanhas de *${period}*:`)
  lines.push('')
  lines.push(`*📋 Conta:* ${accountName}`)
  if (objective) lines.push(`*🎯 Objetivo:* ${objective}`)
  lines.push('')
  lines.push('*📊 MÉTRICAS DO PERÍODO*')
  lines.push('─────────────────────')
  selectedMetrics.forEach(key => {
    const m = METRICS.find(o => o.key === key)
    if (!m) return
    lines.push(`${m.emoji} *${m.label}:* ${m.fmt(getVal(summary, key))}`)
  })

  if (topCampaigns.length > 0) {
    lines.push('')
    lines.push('*🏆 TOP CAMPANHAS*')
    lines.push('─────────────────────')
    topCampaigns.slice(0, 3).forEach((c, i) => {
      const e = c.roas >= 5 ? '🟢' : c.roas >= 3 ? '🟡' : '🔴'
      lines.push(`${i + 1}. ${c.name.slice(0, 35)}${c.name.length > 35 ? '…' : ''}`)
      lines.push(`   ${e} ROAS ${fmt.roas(c.roas)} · ${fmt.brl(c.spend)} investido`)
    })
  }

  if (note.trim()) {
    lines.push('')
    lines.push('*💬 OBSERVAÇÃO DO GESTOR*')
    lines.push('─────────────────────')
    lines.push(note)
  }

  lines.push('')
  lines.push('_Relatório gerado pelo Traffiq Dashboard_ 🚀')
  return lines.join('\n')
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function ReportDispatcher({ campaigns, summary, period, accountName }: Props) {
  // Form state
  const [clientName,  setClientName]  = useState('')
  const [phone,       setPhone]       = useState('')
  const [showPhone,   setShowPhone]   = useState(false)
  const [note,        setNote]        = useState('')
  const [objective,   setObjective]   = useState(OBJECTIVES[0])
  const [selected,    setSelected]    = useState<string[]>(['impressions','clicks','spend','salesDb','cpa.db'])
  const [includeCamps,setIncludeCamps]= useState(true)

  // BSP config
  const [showBsp,     setShowBsp]     = useState(false)
  const [bsp,         setBsp]         = useState<BspConfig>({ provider:'meta_cloud', token:'', endpoint:'', phoneNumberId:'' })
  const [showToken,   setShowToken]   = useState(false)

  // Send state
  const [sending,     setSending]     = useState(false)
  const [sendResult,  setSendResult]  = useState<{ ok: boolean; msg: string } | null>(null)
  const [copied,      setCopied]      = useState(false)

  useEffect(() => { setBsp(loadBsp()) }, [])

  const topCampaigns = useMemo(() =>
    [...campaigns].sort((a, b) => b.spend - a.spend), [campaigns])

  const message = useMemo(() => buildMsg({
    clientName, period, accountName: accountName || 'Conta de Anúncios',
    selectedMetrics: selected, summary,
    topCampaigns: includeCamps ? topCampaigns : [],
    note, objective,
  }), [clientName, period, accountName, selected, summary, topCampaigns, includeCamps, note, objective])

  const cleanPhone  = phone.replace(/\D/g, '')
  const bspReady    = !!(bsp.token && (bsp.endpoint || bsp.provider === 'meta_cloud') && bsp.phoneNumberId)
  const canSendDirect = bspReady && !!cleanPhone

  // ── BSP endpoint auto-fill ─────────────────────────────────────────────────
  function handleProviderChange(p: string) {
    const endpoints: Record<string, string> = {
      meta_cloud: 'graph.facebook.com',
      zenvia:     'zenvia',
      twilio:     'twilio',
      custom:     '',
    }
    setBsp(prev => ({ ...prev, provider: p, endpoint: endpoints[p] }))
  }

  function saveBspAndClose() {
    saveBsp(bsp)
    setShowBsp(false)
  }

  // ── Direct send via BSP API ────────────────────────────────────────────────
  async function handleDirectSend() {
    if (!canSendDirect) return
    setSending(true)
    setSendResult(null)
    try {
      const r = await fetch('/api/whatsapp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to:              cleanPhone,
          message,
          bsp_token:       bsp.token,
          bsp_endpoint:    bsp.endpoint,
          phone_number_id: bsp.phoneNumberId,
        }),
      })
      const data = await r.json()
      if (data.ok) {
        setSendResult({ ok: true, msg: `Enviado! ID: ${data.message_id || '—'}` })
      } else {
        setSendResult({ ok: false, msg: data.error || 'Erro desconhecido' })
      }
    } catch (e: any) {
      setSendResult({ ok: false, msg: e.message })
    } finally {
      setSending(false)
    }
  }

  // ── Fallback: open WA Web ──────────────────────────────────────────────────
  function handleWaWeb() {
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`, '_blank')
  }

  function handleCopy() {
    navigator.clipboard.writeText(message)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">

      {/* ══ LEFT ═════════════════════════════════════════════════════════════ */}
      <div className="flex flex-col gap-4">

        {/* BSP status bar */}
        <div className="card p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: bspReady ? 'rgba(22,163,74,0.1)' : 'rgba(217,119,6,0.1)' }}>
              {bspReady
                ? <Wifi size={14} style={{ color: '#16A34A' }} />
                : <WifiOff size={14} style={{ color: '#D97706' }} />}
            </div>
            <div>
              <div className="text-sm font-semibold text-ink">
                {bspReady ? 'BSP configurado — envio direto ativo' : 'BSP não configurado'}
              </div>
              <div className="text-xs" style={{ color: '#6B7280' }}>
                {bspReady
                  ? `Provedor: ${PROVIDERS.find(p => p.id === bsp.provider)?.label}`
                  : 'Configure para enviar sem abrir o WhatsApp'}
              </div>
            </div>
          </div>
          <button onClick={() => setShowBsp(!showBsp)}
            className="btn-ghost py-1.5 px-3 text-xs flex items-center gap-1.5 flex-shrink-0">
            <Settings size={12} /> {showBsp ? 'Fechar' : 'Configurar'}
          </button>
        </div>

        {/* BSP config panel */}
        {showBsp && (
          <div className="card p-5 flex flex-col gap-3 animate-fade-up"
            style={{ border: '1px solid rgba(30,107,255,0.2)' }}>
            <div className="text-sm font-semibold text-ink mb-1">Configuração do BSP</div>

            {/* Provider */}
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Provedor</label>
              <div className="grid grid-cols-2 gap-2">
                {PROVIDERS.map(p => (
                  <button key={p.id} onClick={() => handleProviderChange(p.id)}
                    className="text-left px-3 py-2 rounded-xl text-xs transition-all"
                    style={{
                      background: bsp.provider === p.id ? 'rgba(30,107,255,0.15)' : '#F7F8FA',
                      border: `1px solid ${bsp.provider === p.id ? 'rgba(30,107,255,0.3)' : '#E6E8EC'}`,
                      color: bsp.provider === p.id ? '#111827' : '#6B7280',
                    }}>
                    <div className="font-semibold">{p.label}</div>
                    <div className="opacity-60 text-xs mt-0.5">{p.hint}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Token */}
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>
                {bsp.provider === 'twilio' ? 'AccountSID:AuthToken' : 'Access Token / API Key'}
              </label>
              <div className="relative">
                <input type={showToken ? 'text' : 'password'}
                  className="input-field pr-10 font-mono text-sm"
                  placeholder="Cole seu token aqui..."
                  value={bsp.token}
                  onChange={e => setBsp(p => ({ ...p, token: e.target.value }))} />
                <button onClick={() => setShowToken(!showToken)}
                  className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#6B7280' }}>
                  {showToken ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
              </div>
            </div>

            {/* Phone Number ID */}
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>
                {bsp.provider === 'twilio' ? 'Número Twilio (ex: 14155238886)' : 'Phone Number ID (ID do número no BSP)'}
              </label>
              <input className="input-field font-mono text-sm"
                placeholder={bsp.provider === 'meta_cloud' ? '123456789012345' : bsp.provider === 'twilio' ? '14155238886' : 'ID do número'}
                value={bsp.phoneNumberId}
                onChange={e => setBsp(p => ({ ...p, phoneNumberId: e.target.value }))} />
            </div>

            {/* Custom endpoint */}
            {bsp.provider === 'custom' && (
              <div>
                <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Endpoint (URL completa)</label>
                <input className="input-field font-mono text-sm"
                  placeholder="https://api.seubsp.com/v1/messages"
                  value={bsp.endpoint}
                  onChange={e => setBsp(p => ({ ...p, endpoint: e.target.value }))} />
              </div>
            )}

            <button onClick={saveBspAndClose} className="btn-primary w-fit mt-1">
              <Check size={13} /> Salvar configuração
            </button>
          </div>
        )}

        {/* Cliente */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <User size={14} style={{ color: '#1E6BFF' }} />
            <span className="section-title text-sm">Destinatário</span>
          </div>
          <div className="flex flex-col gap-3">
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Nome do cliente</label>
              <input className="input-field" placeholder="Ex: João Silva"
                value={clientName} onChange={e => setClientName(e.target.value)} />
            </div>
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>
                WhatsApp com DDI (ex: 5511999990000)
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Phone size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#6B7280' }} />
                  <input
                    type={showPhone ? 'text' : 'password'}
                    className="input-field pl-9 pr-10 font-mono"
                    placeholder="5511999990000"
                    value={phone}
                    onChange={e => { setPhone(e.target.value); setSendResult(null) }}
                  />
                  <button onClick={() => setShowPhone(!showPhone)}
                    className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#6B7280' }}>
                    {showPhone ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                </div>
              </div>
            </div>
            <div>
              <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Objetivo da campanha</label>
              <div className="relative">
                <select className="input-field appearance-none pr-8 cursor-pointer"
                  value={objective} onChange={e => setObjective(e.target.value)}
                  style={{ background: '#F7F8FA' }}>
                  {OBJECTIVES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
                <ChevronDown size={13} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#6B7280' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Métricas */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <BarChart2 size={14} style={{ color: '#1E6BFF' }} />
            <span className="section-title text-sm">Métricas incluídas</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {METRICS.map(m => {
              const on   = selected.includes(m.key)
              const Icon = m.icon
              return (
                <button key={m.key} onClick={() => setSelected(p => on ? p.filter(k => k !== m.key) : [...p, m.key])}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-all text-left"
                  style={{
                    background: on ? 'rgba(30,107,255,0.12)' : '#F7F8FA',
                    border: `1px solid ${on ? 'rgba(30,107,255,0.3)' : '#E6E8EC'}`,
                    color: on ? '#111827' : '#6B7280',
                  }}>
                  <span>{m.emoji}</span>
                  <span className="font-medium truncate flex-1">{m.label}</span>
                  {on && <Check size={11} style={{ color: '#1E6BFF', flexShrink: 0 }} />}
                </button>
              )
            })}
          </div>
        </div>

        {/* Top campanhas */}
        <div className="card p-4 flex items-center justify-between">
          <div>
            <div className="text-sm font-medium text-ink">Incluir top campanhas</div>
            <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>3 campanhas com maior investimento</div>
          </div>
          <label className="toggle-wrap cursor-pointer">
            <input type="checkbox" className="toggle-input" checked={includeCamps} onChange={e => setIncludeCamps(e.target.checked)} />
            <span className="toggle-slider" />
          </label>
        </div>

        {/* Observação */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <Edit3 size={14} style={{ color: '#1E6BFF' }} />
            <span className="section-title text-sm">Observação do gestor</span>
            <span className="badge-blue text-xs">opcional</span>
          </div>
          <textarea className="input-field resize-none" rows={3}
            placeholder="Ex: Testamos 2 criativos novos. O vídeo de depoimento teve CTR 3x maior. Vamos escalar na próxima semana."
            value={note} onChange={e => setNote(e.target.value.slice(0, 500))}
            style={{ lineHeight: '1.6' }} />
          <div className="text-xs mt-1 text-right" style={{ color: '#6B7280' }}>{note.length}/500</div>
        </div>
      </div>

      {/* ══ RIGHT ════════════════════════════════════════════════════════════ */}
      <div className="flex flex-col gap-4">

        {/* Preview */}
        <div className="card p-5 flex-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MessageSquare size={14} style={{ color: '#1DAA5B' }} />
              <span className="section-title text-sm">Pré-visualização</span>
            </div>
            <button onClick={handleCopy} className="btn-ghost py-1.5 px-3 text-xs flex items-center gap-1.5">
              {copied ? <><CheckCircle2 size={12} style={{ color: '#16A34A' }} /> Copiado!</> : <><Copy size={12} /> Copiar</>}
            </button>
          </div>

          <div className="rounded-2xl p-4 overflow-y-auto max-h-[460px]"
            style={{ background: '#F0FDF4', border: '1px solid rgba(37,211,102,0.12)' }}>
            <div className="rounded-xl p-3 max-w-[88%] ml-auto whitespace-pre-wrap"
              style={{ background: '#005C4B', color: '#E9FEEE', borderRadius: '12px 12px 2px 12px', fontSize: 13, lineHeight: 1.7 }}>
              {message.split('\n').map((line, i, arr) => (
                <span key={i}>
                  <span dangerouslySetInnerHTML={{
                    __html: line
                      .replace(/\*(.*?)\*/g, '<strong>$1</strong>')
                      .replace(/_(.*?)_/g, '<em style="opacity:0.75">$1</em>')
                      || '&nbsp;'
                  }} />
                  {i < arr.length - 1 && <br />}
                </span>
              ))}
            </div>
            <div className="text-right mt-1 text-xs" style={{ color: '#6B7280' }}>
              {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} ✓✓
            </div>
          </div>

          <div className="flex items-center justify-between mt-2">
            <span className="text-xs" style={{ color: '#6B7280' }}>{message.length} caracteres</span>
            <span className="text-xs" style={{ color: message.length > 4096 ? '#DC2626' : '#6B7280' }}>
              {message.length > 4096 ? '⚠️ Longo demais para API' : '✓ OK'}
            </span>
          </div>
        </div>

        {/* Send panel */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Send size={14} style={{ color: '#1DAA5B' }} />
            <span className="section-title text-sm">Enviar</span>
          </div>

          {/* Destination chip */}
          {cleanPhone ? (
            <div className="flex items-center gap-3 mb-4 p-3 rounded-xl"
              style={{ background: 'rgba(37,211,102,0.06)', border: '1px solid rgba(37,211,102,0.12)' }}>
              <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold"
                style={{ background: 'rgba(37,211,102,0.15)', color: '#1DAA5B' }}>
                {clientName ? clientName[0].toUpperCase() : '?'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-ink">{clientName || 'Cliente'}</div>
                <div className="text-xs font-mono" style={{ color: '#6B7280' }}>+{cleanPhone}</div>
              </div>
              <div className="status-active" />
            </div>
          ) : (
            <div className="flex items-center gap-2 mb-4 p-3 rounded-xl text-xs"
              style={{ background: 'rgba(217,119,6,0.06)', border: '1px solid rgba(217,119,6,0.15)', color: '#D97706' }}>
              <AlertCircle size={13} /> Informe o WhatsApp do cliente
            </div>
          )}

          {/* Result feedback */}
          {sendResult && (
            <div className="flex items-center gap-2 mb-3 p-3 rounded-xl text-xs"
              style={{
                background: sendResult.ok ? 'rgba(22,163,74,0.08)' : 'rgba(220,38,38,0.08)',
                border: `1px solid ${sendResult.ok ? 'rgba(22,163,74,0.2)' : 'rgba(220,38,38,0.2)'}`,
                color: sendResult.ok ? '#16A34A' : '#DC2626',
              }}>
              {sendResult.ok
                ? <><CheckCircle2 size={13} /> {sendResult.msg}</>
                : <><AlertCircle size={13} /> <span><strong>Erro:</strong> {sendResult.msg}</span></>}
            </div>
          )}

          <div className="flex flex-col gap-2">
            {/* PRIMARY: direct send if BSP ready */}
            <button
              onClick={handleDirectSend}
              disabled={!canSendDirect || sending}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all"
              style={{
                background: canSendDirect
                  ? sending ? 'rgba(37,211,102,0.2)' : 'linear-gradient(135deg,#1DAA5B,#128C7E)'
                  : '#E6E8EC',
                color: canSendDirect ? '#fff' : '#6B7280',
                cursor: canSendDirect ? 'pointer' : 'not-allowed',
                boxShadow: canSendDirect && !sending ? '0 4px 20px rgba(37,211,102,0.3)' : 'none',
              }}
              title={!bspReady ? 'Configure o BSP acima para envio direto' : !cleanPhone ? 'Informe o WhatsApp' : ''}
            >
              {sending
                ? <><RefreshCw size={15} className="animate-spin" /> Enviando...</>
                : <><Send size={15} /> Enviar agora {bspReady ? `(${PROVIDERS.find(p=>p.id===bsp.provider)?.label})` : ''}</>
              }
            </button>

            {/* SECONDARY: WhatsApp Web fallback */}
            <button
              onClick={handleWaWeb}
              disabled={!cleanPhone}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm transition-all"
              style={{
                background: '#F7F8FA',
                border: '1px solid #E6E8EC',
                color: cleanPhone ? '#4B5563' : '#9CA3AF',
                cursor: cleanPhone ? 'pointer' : 'not-allowed',
              }}
            >
              <ExternalLink size={13} /> Abrir no WhatsApp Web
            </button>

            <button onClick={handleCopy}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs btn-ghost">
              {copied ? <><CheckCircle2 size={12} style={{ color: '#16A34A' }} /> Copiado!</> : <><Copy size={12} /> Copiar texto</>}
            </button>
          </div>

          {!bspReady && (
            <p className="text-xs mt-3 text-center" style={{ color: '#6B7280' }}>
              Configure o BSP acima para ativar o <strong>envio direto</strong> sem abrir o WhatsApp.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
