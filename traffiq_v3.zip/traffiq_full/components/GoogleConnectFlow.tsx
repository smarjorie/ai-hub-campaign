import { useState } from 'react'
import { Eye, EyeOff, Check, X, RefreshCw, ExternalLink, AlertCircle, CheckCircle2, Wifi, WifiOff } from 'lucide-react'

interface Props {
  status:        string
  customerName:  string
  onConnect:     (devToken: string, oauthToken: string, customerId: string) => void
  onDisconnect:  () => void
  validateCreds: (devToken: string, oauthToken: string, customerId: string) => Promise<{ valid: boolean; customerName: string; error?: string }>
}

export default function GoogleConnectFlow({ status, customerName, onConnect, onDisconnect, validateCreds }: Props) {
  const [step, setStep]       = useState<'idle'|'input'|'validating'|'ready'|'connecting'>('idle')
  const [devToken,  setDev]   = useState('')
  const [oauth,     setOAuth] = useState('')
  const [custId,    setCust]  = useState('')
  const [showDev,   setShowDev]   = useState(false)
  const [showOAuth, setShowOAuth] = useState(false)
  const [valName,   setValName]   = useState('')
  const [error,     setError]     = useState('')

  const isConnected = status === 'real'
  const isLoading   = status === 'loading'

  async function handleValidate() {
    if (!devToken.trim() || !oauth.trim() || !custId.trim()) {
      setError('Preencha todos os campos'); return
    }
    setStep('validating'); setError('')
    const r = await validateCreds(devToken.trim(), oauth.trim(), custId.trim())
    if (!r.valid) { setError(r.error || 'Credenciais inválidas'); setStep('input'); return }
    setValName(r.customerName)
    setStep('ready')
  }

  async function handleConnect() {
    setStep('connecting')
    await onConnect(devToken.trim(), oauth.trim(), custId.trim())
    setStep('idle')
  }

  function handleDisconnect() {
    onDisconnect(); setStep('idle'); setDev(''); setOAuth(''); setCust(''); setError('')
  }

  if (isConnected || isLoading) return (
    <div className="card p-5">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
          style={{ background:'rgba(234,67,53,0.12)', color:'#EA4335', border:'1px solid rgba(234,67,53,0.2)' }}>G</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-ink">Google Ads</span>
            {isLoading
              ? <span className="badge-yellow"><RefreshCw size={10} className="animate-spin" /> Carregando...</span>
              : <span className="badge-green"><span className="status-active mr-1" />Conectado</span>}
          </div>
          {!isLoading && (
            <div className="flex items-center gap-3">
              <div className="text-xs" style={{ color:'#6B7280' }}>{customerName}</div>
              <button onClick={handleDisconnect} className="flex items-center gap-1 text-xs transition-colors"
                style={{ color:'#6B7280' }}
                onMouseEnter={e=>(e.currentTarget.style.color='#DC2626')}
                onMouseLeave={e=>(e.currentTarget.style.color='#6B7280')}>
                <WifiOff size={11} /> Desconectar
              </button>
            </div>
          )}
        </div>
        {isLoading && <RefreshCw size={18} className="animate-spin" style={{ color:'#EA4335' }} />}
      </div>
    </div>
  )

  return (
    <div className="card p-5 flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
          style={{ background:'rgba(234,67,53,0.1)', color:'#EA4335', border:'1px solid rgba(234,67,53,0.15)' }}>G</div>
        <div>
          <div className="font-semibold text-ink mb-0.5">Google Ads</div>
          <p className="text-xs" style={{ color:'#6B7280' }}>Conecte via Developer Token + OAuth para dados reais</p>
        </div>
      </div>

      {step === 'idle' && (
        <button className="btn-primary w-fit" style={{ background:'linear-gradient(135deg,#EA4335,#C5221F)' }}
          onClick={() => setStep('input')}>
          Conectar com Google Ads
        </button>
      )}

      {(step === 'input' || step === 'validating') && (
        <div className="flex flex-col gap-3">
          {/* Developer Token */}
          <div>
            <label className="text-xs mb-1.5 block font-medium" style={{ color:'#4B5563' }}>Developer Token</label>
            <div className="relative">
              <input type={showDev ? 'text' : 'password'} placeholder="ABcDef123..."
                value={devToken} onChange={e=>{setDev(e.target.value);setError('')}}
                className="input-field pr-10 font-mono text-sm" />
              <button onClick={()=>setShowDev(!showDev)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{color:'#6B7280'}}>
                {showDev ? <EyeOff size={14}/> : <Eye size={14}/>}
              </button>
            </div>
          </div>

          {/* OAuth Token */}
          <div>
            <label className="text-xs mb-1.5 block font-medium" style={{ color:'#4B5563' }}>OAuth Access Token</label>
            <div className="relative">
              <input type={showOAuth ? 'text' : 'password'} placeholder="ya29.A0ARrdaM..."
                value={oauth} onChange={e=>{setOAuth(e.target.value);setError('')}}
                className="input-field pr-10 font-mono text-sm" />
              <button onClick={()=>setShowOAuth(!showOAuth)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{color:'#6B7280'}}>
                {showOAuth ? <EyeOff size={14}/> : <Eye size={14}/>}
              </button>
            </div>
          </div>

          {/* Customer ID */}
          <div>
            <label className="text-xs mb-1.5 block font-medium" style={{ color:'#4B5563' }}>Customer ID</label>
            <input type="text" placeholder="123-456-7890"
              value={custId} onChange={e=>{setCust(e.target.value);setError('')}}
              className="input-field font-mono text-sm" />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-xs" style={{ color:'#DC2626' }}>
              <AlertCircle size={13}/> {error}
            </div>
          )}

          <div className="flex items-center gap-2">
            <button onClick={handleValidate} disabled={step==='validating'} className="btn-primary"
              style={{ background:'linear-gradient(135deg,#EA4335,#C5221F)' }}>
              {step==='validating'
                ? <><RefreshCw size={13} className="animate-spin"/> Validando...</>
                : <><Check size={13}/> Validar Credenciais</>}
            </button>
            <button onClick={()=>{setStep('idle');setError('')}} className="btn-ghost"><X size={14}/></button>
          </div>

          <a href="https://developers.google.com/google-ads/api/docs/first-call/dev-token" target="_blank" rel="noreferrer"
            className="text-xs flex items-center gap-1.5 w-fit transition-colors" style={{ color:'#6B7280' }}
            onMouseEnter={e=>(e.currentTarget.style.color='#EA4335')}
            onMouseLeave={e=>(e.currentTarget.style.color='#6B7280')}>
            <ExternalLink size={11}/> Como obter o Developer Token do Google Ads
          </a>
        </div>
      )}

      {(step === 'ready' || step === 'connecting') && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2 text-xs py-2 px-3 rounded-xl"
            style={{ background:'rgba(22,163,74,0.08)', border:'1px solid rgba(22,163,74,0.15)' }}>
            <CheckCircle2 size={13} style={{ color:'#16A34A' }}/>
            <span style={{ color:'#16A34A' }}>Credenciais válidas</span>
            <span style={{ color:'#6B7280' }}>·</span>
            <span style={{ color:'#4B5563' }}>{valName}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleConnect} disabled={step==='connecting'} className="btn-primary"
              style={{ background:'linear-gradient(135deg,#EA4335,#C5221F)' }}>
              {step==='connecting'
                ? <><RefreshCw size={13} className="animate-spin"/> Conectando...</>
                : <><Wifi size={13}/> Conectar e Carregar Dados</>}
            </button>
            <button onClick={()=>setStep('input')} className="btn-ghost text-sm">Voltar</button>
          </div>
        </div>
      )}
    </div>
  )
}
