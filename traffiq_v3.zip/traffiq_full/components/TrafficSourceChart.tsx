import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { trafficSources } from '@/lib/mockData'

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-2.5">
      <div className="text-sm font-semibold text-ink">{payload[0].payload.name}</div>
      <div className="text-xs mt-0.5" style={{ color: '#4B5563' }}>{payload[0].value}% do tráfego</div>
    </div>
  )
}

export default function TrafficSourceChart() {
  return (
    <div>
      <div className="section-title mb-4">Origem dos Acessos</div>
      <div className="flex items-center gap-6">
        <ResponsiveContainer width={140} height={140}>
          <PieChart>
            <Pie data={trafficSources} dataKey="value" cx="50%" cy="50%" innerRadius={38} outerRadius={62} strokeWidth={0}>
              {trafficSources.map((s, i) => <Cell key={i} fill={s.color} />)}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="flex flex-col gap-1.5 flex-1">
          {trafficSources.map((s) => (
            <div key={s.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ background: s.color }} />
                <span className="text-xs" style={{ color: '#4B5563' }}>{s.name}</span>
              </div>
              <span className="text-xs font-semibold text-ink">{s.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
