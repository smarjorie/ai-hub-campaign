import { useEffect, useRef, useState } from 'react'
import clsx from 'clsx'
import {
  ArrowUp, Square, Wallet, Activity, Image as ImageIcon, FileText, Plus, Check, X, Loader2, AlertCircle,
} from 'lucide-react'
import Markdown from './Markdown'
import { askAgent, executeProposal, describeArgs, type ChatTurn, type Proposal } from '@/lib/agentClient'

interface Props {
  userName?: string
  metaConnected: boolean
  googleConnected: boolean
  onGoIntegrations: () => void
  onDataChanged: () => void
}

type Msg =
  | { role: 'user'; content: string }
  | { role: 'assistant'; content: string; proposals: Proposal[]; toolsUsed: string[] }
  | { role: 'error'; content: string }

type PState = { status: 'idle' | 'running' | 'done' | 'failed' | 'dismissed'; error?: string }

const TOOL_LABEL: Record<string, string> = {
  meta_list_accounts: 'contas Meta',
  meta_get_campaigns: 'campanhas Meta',
  meta_get_timeline: 'série diária Meta',
  meta_get_demographics: 'público Meta',
  google_get_campaigns: 'campanhas Google',
  google_get_timeline: 'série diária Google',
}

interface Area {
  id: string
  title: string
  desc: string
  mark?: { short: string; color: string }
  icon?: typeof Wallet
  soon?: boolean
  needs?: 'meta' | 'google'
  prompts: string[]
}

const AREAS: Area[] = [
  {
    id: 'meta', title: 'Meta Ads', desc: 'Campanhas, criativos e CTWA', mark: { short: 'M', color: '#1877F2' }, needs: 'meta',
    prompts: [
      'Quais campanhas da Meta gastaram mais e trouxeram menos resultado nos últimos 7 dias?',
      'Monte o ranking dos criativos de Click to WhatsApp por custo por conversa iniciada.',
      'Quais conjuntos estão com frequência acima de 4 nos últimos 14 dias?',
    ],
  },
  {
    id: 'google', title: 'Google Ads', desc: 'Pesquisa, custo e conversões', mark: { short: 'G', color: '#1A73E8' }, needs: 'google',
    prompts: [
      'Resuma o desempenho das campanhas do Google nos últimos 30 dias.',
      'Quais campanhas do Google gastaram e não converteram nos últimos 14 dias?',
      'Compare o custo por conversão entre as campanhas do Google.',
    ],
  },
  {
    id: 'budget', title: 'Orçamento', desc: 'Pausar, ativar e redistribuir', icon: Wallet, needs: 'meta',
    prompts: [
      'Sugira uma redistribuição do orçamento diário entre as campanhas da Meta com base no ROAS dos últimos 7 dias.',
      'Quais campanhas da Meta com CPA acima de R$ 50 nos últimos 7 dias eu deveria pausar?',
    ],
  },
  {
    id: 'diagnosis', title: 'Diagnóstico', desc: 'O que mudou e por quê', icon: Activity,
    prompts: [
      'Por que o resultado caiu nos últimos 7 dias em relação aos 7 anteriores?',
      'Compare Meta e Google no último mês: investimento, conversões e custo por resultado.',
    ],
  },
  {
    id: 'creative', title: 'Criativos', desc: 'Fadiga, ranking e variações', icon: ImageIcon, needs: 'meta',
    prompts: [
      'Quais anúncios mostram sinais de fadiga (CTR caindo e frequência subindo)?',
      'Quais são os 5 melhores anúncios por custo por resultado e o que eles têm em comum?',
    ],
  },
  {
    id: 'report', title: 'Relatórios', desc: 'Resumo pronto para o cliente', icon: FileText,
    prompts: [
      'Gere o relatório da última semana para enviar ao cliente: investimento, resultados, o que mudou e 3 próximos passos.',
    ],
  },
  { id: 'chatgpt', title: 'ChatGPT Ads', desc: 'Anúncios nas respostas do ChatGPT', mark: { short: 'AI', color: '#10A37F' }, soon: true, prompts: [] },
  { id: 'tiktok', title: 'TikTok Ads', desc: 'In-feed e Spark Ads', mark: { short: 'T', color: '#111318' }, soon: true, prompts: [] },
]

export default function AssistantHome({ userName, metaConnected, googleConnected, onGoIntegrations, onDataChanged }: Props) {
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [text, setText] = useState('')
  const [area, setArea] = useState<string>('meta')
  const [busy, setBusy] = useState(false)
  const [pstate, setPstate] = useState<Record<string, PState>>({})
  const ctl = useRef<AbortController | null>(null)
  const input = useRef<HTMLTextAreaElement>(null)
  const endRef = useRef<HTMLDivElement>(null)

  const connected = { meta: metaConnected, google: googleConnected }
  const firstName = (userName || '').split(' ')[0]
  const inThread = msgs.length > 0

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }) }, [msgs, busy])

  function fill(p: string) {
    setText(p)
    requestAnimationFrame(() => { input.current?.focus(); input.current?.setSelectionRange(p.length, p.length) })
  }

  async function send(content?: string) {
    const body = (content ?? text).trim()
    if (!body || busy) return
    const next: Msg[] = [...msgs, { role: 'user', content: body }]
    setMsgs(next); setText(''); setBusy(true)
    ctl.current = new AbortController()
    // historico enviado ao agente: so texto de usuario e assistente
    const turns: ChatTurn[] = next
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }))
    try {
      const r = await askAgent(turns, ctl.current.signal)
      setMsgs(m => [...m, { role: 'assistant', content: r.reply, proposals: r.proposals, toolsUsed: r.toolsUsed }])
    } catch (e: any) {
      if (e?.name !== 'AbortError') setMsgs(m => [...m, { role: 'error', content: e.message || 'O agente não respondeu.' }])
    } finally {
      setBusy(false); ctl.current = null
    }
  }

  async function confirm(p: Proposal) {
    setPstate(s => ({ ...s, [p.id]: { status: 'running' } }))
    const r = await executeProposal(p)
    setPstate(s => ({ ...s, [p.id]: r.ok ? { status: 'done' } : { status: 'failed', error: r.error } }))
    if (r.ok) onDataChanged()
  }

  const composer = (
    <div className="rounded-2xl border border-border bg-white shadow-composer focus-within:border-border-2">
      <label htmlFor="agent-input" className="sr-only">Mensagem para o assistente</label>
      <textarea
        id="agent-input" ref={input} rows={inThread ? 2 : 3} value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
        placeholder={inThread ? 'Continue a conversa...' : 'Peça uma análise ou uma ação. Ex.: pausar os conjuntos com frequência acima de 4'}
        className="block w-full resize-none rounded-t-2xl bg-transparent px-5 pt-4 text-[15px] leading-relaxed text-ink placeholder:text-muted outline-none"
      />
      <div className="flex items-center justify-between gap-3 px-3 pb-3 pt-1">
        <div className="flex flex-wrap items-center gap-1.5">
          {([['meta', 'Meta Ads', '#1877F2', 'M'], ['google', 'Google Ads', '#1A73E8', 'G']] as const).map(([id, label, color, short]) => (
            <button key={id} type="button" onClick={connected[id] ? undefined : onGoIntegrations}
              className={clsx(
                'inline-flex items-center gap-1.5 rounded-full border py-1 pl-1 pr-2.5 text-[12px] font-medium',
                connected[id] ? 'cursor-default border-border text-ink' : 'border-dashed border-border-2 text-muted hover:text-ink',
              )}
              title={connected[id] ? `${label} conectado` : `Conectar ${label}`}>
              <span className="grid h-5 w-5 place-items-center rounded-full text-[10px] font-bold text-white"
                style={{ background: connected[id] ? color : '#C4C8D0' }}>{short}</span>
              {connected[id] ? label : `Conectar ${label}`}
            </button>
          ))}
        </div>
        {busy ? (
          <button type="button" onClick={() => ctl.current?.abort()} aria-label="Parar"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ink text-white">
            <Square size={13} fill="currentColor" />
          </button>
        ) : (
          <button type="button" onClick={() => send()} disabled={!text.trim()} aria-label="Enviar"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent text-white transition-opacity disabled:opacity-30">
            <ArrowUp size={18} strokeWidth={2.25} />
          </button>
        )}
      </div>
    </div>
  )

  // ---------- conversa ----------
  if (inThread) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-7rem)] max-w-[780px] flex-col">
        <div className="mb-4 flex justify-end">
          <button type="button" onClick={() => { setMsgs([]); setPstate({}) }} className="btn-ghost py-1.5 text-[13px]">
            <Plus size={14} /> Nova conversa
          </button>
        </div>

        <div className="flex-1 space-y-6 pb-6">
          {msgs.map((m, i) => {
            if (m.role === 'user') {
              return (
                <div key={i} className="flex justify-end">
                  <p className="max-w-[80%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-[#F0F1F4] px-4 py-2.5 text-[15px] text-ink">{m.content}</p>
                </div>
              )
            }
            if (m.role === 'error') {
              return (
                <div key={i} role="alert" className="flex items-start gap-2 rounded-xl bg-[#FDECEC] px-4 py-3 text-[14px] text-[#B91C1C]">
                  <AlertCircle size={16} className="mt-0.5 shrink-0" />
                  <span>{m.content}</span>
                </div>
              )
            }
            return (
              <div key={i}>
                {m.toolsUsed.length > 0 && (
                  <p className="mb-2 text-[12px] text-muted">Consultou {m.toolsUsed.map(t => TOOL_LABEL[t] || t).join(', ')}</p>
                )}
                <Markdown text={m.content} />
                {m.proposals.length > 0 && (
                  <div className="mt-4 space-y-2.5">
                    {m.proposals.map(p => {
                      const st = pstate[p.id]?.status || 'idle'
                      return (
                        <div key={p.id} className="rounded-xl border border-border bg-white p-4">
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div className="min-w-0">
                              <p className="text-[14px] font-semibold text-ink">{p.title}</p>
                              <p className="mt-0.5 text-[13px] text-muted-2">{p.reason}</p>
                              <p className="mt-1.5 text-[12px] tabular-nums text-muted">{describeArgs(p)}</p>
                            </div>
                            {st === 'idle' && (
                              <div className="flex shrink-0 gap-1.5">
                                <button type="button" className="btn-ghost py-1.5 text-[13px]" onClick={() => setPstate(s => ({ ...s, [p.id]: { status: 'dismissed' } }))}>Descartar</button>
                                <button type="button" className="btn-primary py-1.5 text-[13px]" onClick={() => confirm(p)}>Confirmar alteração</button>
                              </div>
                            )}
                            {st === 'running' && <span className="inline-flex items-center gap-1.5 text-[13px] text-muted-2"><Loader2 size={14} className="animate-spin" /> Aplicando...</span>}
                            {st === 'done' && <span className="badge-green"><Check size={12} /> Alteração aplicada</span>}
                            {st === 'dismissed' && <span className="badge"><X size={12} /> Descartada</span>}
                          </div>
                          {st === 'failed' && <p role="alert" className="mt-2 text-[13px] text-[#B91C1C]">{pstate[p.id]?.error}</p>}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
          {busy && (
            <p className="inline-flex items-center gap-2 text-[14px] text-muted-2">
              <Loader2 size={15} className="animate-spin" /> Consultando suas contas...
            </p>
          )}
          <div ref={endRef} />
        </div>

        <div className="sticky bottom-0 bg-gradient-to-t from-bg via-bg to-transparent pb-2 pt-6">{composer}</div>
      </div>
    )
  }

  // ---------- inicio ----------
  const current = AREAS.find(a => a.id === area)!
  return (
    <div className="mx-auto max-w-[880px] pb-10 pt-10 lg:pt-16">
      {firstName && <p className="text-[16px] text-muted-2">Olá, {firstName}</p>}
      <h1 className="mt-1 text-[34px] font-semibold leading-[1.15] tracking-[-0.025em] text-ink">
        O que vamos fazer pelas suas campanhas hoje?
      </h1>

      <div className="mt-8">{composer}</div>

      <div className="mt-10 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {AREAS.map(a => {
          const Icon = a.icon
          const selected = a.id === area && !a.soon
          return (
            <button key={a.id} type="button" disabled={a.soon} onClick={() => setArea(a.id)} aria-pressed={selected}
              className={clsx(
                'flex flex-col items-start gap-3 rounded-2xl border p-4 text-left transition-colors outline-none focus-visible:ring-2 focus-visible:ring-accent/40',
                a.soon ? 'cursor-not-allowed border-border bg-surface-2' : selected ? 'border-ink bg-white' : 'border-border bg-white hover:border-border-2',
              )}>
              {a.mark ? (
                <span className={clsx('grid h-9 w-9 place-items-center rounded-xl text-[13px] font-bold text-white', a.soon && 'opacity-40')}
                  style={{ background: a.mark.color }}>{a.mark.short}</span>
              ) : Icon ? (
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#F0F1F4] text-ink"><Icon size={18} strokeWidth={1.75} /></span>
              ) : null}
              <span>
                <span className={clsx('flex items-center gap-2 text-[14px] font-semibold', a.soon ? 'text-muted' : 'text-ink')}>
                  {a.title}
                  {a.soon && <span className="rounded-md bg-[#E9EBEF] px-1.5 py-0.5 text-[11px] font-medium text-muted-2">Em breve</span>}
                </span>
                <span className="mt-0.5 block text-[13px] text-muted">{a.desc}</span>
              </span>
            </button>
          )
        })}
      </div>

      {current.prompts.length > 0 && (
        <section className="mt-6" aria-label={`Sugestões para ${current.title}`}>
          {current.needs && !connected[current.needs] ? (
            <p className="rounded-xl border border-dashed border-border-2 px-4 py-3 text-[14px] text-muted-2">
              Conecte o {current.needs === 'meta' ? 'Meta Ads' : 'Google Ads'} para usar estas análises.{' '}
              <button type="button" onClick={onGoIntegrations} className="font-medium text-accent hover:underline">Ir para Integrações</button>
            </p>
          ) : (
            <ul className="divide-y divide-border overflow-hidden rounded-2xl border border-border bg-white">
              {current.prompts.map(p => (
                <li key={p}>
                  <button type="button" onClick={() => fill(p)}
                    className="w-full px-5 py-3.5 text-left text-[14px] text-ink transition-colors hover:bg-surface-2 outline-none focus-visible:bg-surface-2">
                    {p}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  )
}
