import { useState } from 'react'
import { ChevronDown, RefreshCw, CheckCircle2, Building2 } from 'lucide-react'

interface Account { id: string; name: string; status: number; currency: string }

interface Props {
  accountId:   string
  accountName: string
  userName:    string
  accounts:    Account[]
  status:      string
  onSwitch:    (accountId: string) => void
}

const STATUS_BADGE: Record<number, { label: string; color: string }> = {
  1: { label: 'Ativa',        color: '#16A34A' },
  2: { label: 'Desativada',   color: '#DC2626' },
  3: { label: 'Inadimplente', color: '#D97706' },
  7: { label: 'Em revisão',   color: '#D97706' },
  9: { label: 'Fechada',      color: '#DC2626' },
}

export default function AccountSwitcher({ accountId, accountName, userName, accounts, status, onSwitch }: Props) {
  const [open, setOpen] = useState(false)
  const isLoading = status === 'loading'

  if (!accountId) return null

  const displayName = accountName || accountId
  const shortName   = displayName.length > 22 ? displayName.slice(0, 22) + '…' : displayName

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl transition-all text-sm"
        style={{
          background: 'rgba(30,107,255,0.1)',
          border: '1px solid rgba(30,107,255,0.2)',
          color: '#111827',
          maxWidth: 260,
        }}
      >
        {isLoading
          ? <RefreshCw size={13} className="animate-spin flex-shrink-0" style={{ color: '#1E6BFF' }} />
          : <Building2 size={13} className="flex-shrink-0" style={{ color: '#1E6BFF' }} />
        }
        <div className="flex flex-col items-start min-w-0">
          <span className="font-semibold leading-tight truncate w-full" style={{ fontSize: 12 }}>{shortName}</span>
          {userName && <span className="leading-tight truncate w-full" style={{ fontSize: 10, color: '#6B7280' }}>{userName}</span>}
        </div>
        {accounts.length > 1 && (
          <ChevronDown size={12} className="flex-shrink-0 transition-transform duration-150"
            style={{ color: '#6B7280', transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }} />
        )}
      </button>

      {open && accounts.length > 1 && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />

          {/* Dropdown */}
          <div className="absolute top-full left-0 mt-1.5 z-50 card py-1 min-w-[280px] max-h-72 overflow-y-auto"
            style={{ boxShadow: '0 8px 40px rgba(17,24,39,0.06)' }}>
            <div className="px-3 py-2 border-b" style={{ borderColor: '#E6E8EC' }}>
              <div className="text-xs font-semibold" style={{ color: '#6B7280' }}>TROCAR CONTA</div>
              <div className="text-xs mt-0.5" style={{ color: '#4B5563' }}>{accounts.length} contas disponíveis</div>
            </div>
            {accounts.map(a => {
              const st   = STATUS_BADGE[a.status] || { label: String(a.status), color: '#6B7280' }
              const active = a.id === accountId
              return (
                <button
                  key={a.id}
                  onClick={() => { onSwitch(a.id); setOpen(false) }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-left transition-all"
                  style={{ background: active ? 'rgba(30,107,255,0.1)' : 'transparent' }}
                  onMouseEnter={e => { if (!active) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.03)' }}
                  onMouseLeave={e => { if (!active) (e.currentTarget as HTMLElement).style.background = 'transparent' }}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-ink truncate">{a.name}</span>
                      {active && <CheckCircle2 size={12} style={{ color: '#1E6BFF', flexShrink: 0 }} />}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>
                      {a.id} · {a.currency}
                    </div>
                  </div>
                  <span className="text-xs px-1.5 py-0.5 rounded-md font-medium flex-shrink-0"
                    style={{ background: `${st.color}15`, color: st.color }}>
                    {st.label}
                  </span>
                </button>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
