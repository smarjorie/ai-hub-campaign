import { Megaphone, MessageSquare, Zap } from 'lucide-react'

export type DashMode = 'ads' | 'bsp' | 'hybrid'

interface Props { mode: DashMode; onChange: (m: DashMode) => void }

const MODES = [
  { id: 'ads'   as const, label: 'Tráfego Pago', icon: Megaphone,    color: '#1E6BFF', border: 'rgba(30,107,255,0.3)',  bg: 'rgba(30,107,255,0.15)'  },
  { id: 'bsp'   as const, label: 'WhatsApp CRM', icon: MessageSquare, color: '#1DAA5B', border: 'rgba(37,211,102,0.3)',  bg: 'rgba(37,211,102,0.15)'  },
  { id: 'hybrid'as const, label: 'Visão Híbrida', icon: Zap,          color: '#D97706', border: 'rgba(217,119,6,0.3)',   bg: 'rgba(217,119,6,0.15)'   },
]

export default function ModeSwitch({ mode, onChange }: Props) {
  return (
    <div className="flex items-center gap-1 p-1 rounded-xl flex-shrink-0"
      style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}>
      {MODES.map(m => {
        const active = mode === m.id
        return (
          <button key={m.id} onClick={() => onChange(m.id)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200"
            style={{
              background: active ? m.bg        : 'transparent',
              color:      active ? m.color     : '#6B7280',
              border:     active ? `1px solid ${m.border}` : '1px solid transparent',
            }}>
            <m.icon size={13} />
            <span className="hidden md:inline">{m.label}</span>
          </button>
        )
      })}
    </div>
  )
}
