import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'

const GENDER_COLORS = ['#1E6BFF', '#A855F7', '#6B7280']
const AGE_COLORS    = ['#1E6BFF', '#3D8BFF', '#0891B2', '#0891B2', '#0E7490', '#006D8F']

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-2.5">
      <div className="text-sm font-semibold text-ink">{payload[0].name}</div>
      <div className="text-xs mt-0.5" style={{ color: '#4B5563' }}>{payload[0].value}%</div>
    </div>
  )
}

function Legend({ data, colors }: { data: { name: string; value: number }[]; colors: string[] }) {
  return (
    <div className="flex flex-col gap-1.5 mt-1">
      {data.map((d, i) => (
        <div key={d.name} className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: colors[i] }} />
            <span className="text-xs" style={{ color: '#4B5563' }}>{d.name}</span>
          </div>
          <span className="text-xs font-semibold text-ink">{d.value}%</span>
        </div>
      ))}
    </div>
  )
}

export default function DemographicsChart({ data }: { data: { gender: any[]; age: any[] } }) {
  const gender = data?.gender || []
  const age    = data?.age    || []

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <div className="section-title mb-4">Gênero</div>
        <div className="flex items-center gap-4">
          <ResponsiveContainer width={140} height={140}>
            <PieChart>
              <Pie data={gender} dataKey="value" cx="50%" cy="50%" innerRadius={40} outerRadius={64} strokeWidth={0}>
                {gender.map((_: any, i: number) => <Cell key={i} fill={GENDER_COLORS[i]} />)}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <Legend data={gender} colors={GENDER_COLORS} />
        </div>
      </div>
      <div>
        <div className="section-title mb-4">Faixa Etária</div>
        <div className="flex items-center gap-4">
          <ResponsiveContainer width={140} height={140}>
            <PieChart>
              <Pie data={age} dataKey="value" cx="50%" cy="50%" innerRadius={40} outerRadius={64} strokeWidth={0}>
                {age.map((_: any, i: number) => <Cell key={i} fill={AGE_COLORS[i % AGE_COLORS.length]} />)}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <Legend data={age} colors={AGE_COLORS} />
        </div>
      </div>
    </div>
  )
}
