import { useState, useMemo } from 'react'
import {
  ChevronRight, ExternalLink, Edit2, Check, X,
  Layers, Target, Image, Search, ArrowLeft,
  DollarSign, TrendingUp, MousePointer, ShoppingCart,
} from 'lucide-react'
import { Campaign, AdSet, Ad } from '@/lib/mockData'
import { fmt } from '@/lib/format'

// ─── Types ────────────────────────────────────────────────────────────────────

type ViewLevel = 'campaigns' | 'adsets' | 'ads'

// ─── Shared sub-components ────────────────────────────────────────────────────

function Toggle({ active, onChange }: { active: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="toggle-wrap" onClick={e => { e.stopPropagation(); onChange(!active) }}>
      <input type="checkbox" className="toggle-input" checked={active} onChange={() => {}} />
      <span className="toggle-slider" />
    </label>
  )
}

function BudgetEditor({ value, onChange, type }: {
  value: number; onChange: (v: number) => void; type: 'CBO' | 'ABO'
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft]     = useState(String(value))
  const cls = type === 'CBO' ? 'badge-purple' : 'badge-blue'

  if (!editing) return (
    <button
      className="flex items-center gap-1.5 group"
      onClick={e => { e.stopPropagation(); setEditing(true); setDraft(String(value)) }}
    >
      <span className={cls}>{type}</span>
      <span className="text-sm font-semibold text-ink">{fmt.brl(value)}</span>
      <Edit2 size={11} className="opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: '#6B7280' }} />
    </button>
  )

  return (
    <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
      <span className={cls}>{type}</span>
      <input
        autoFocus
        className="input-field text-sm py-1 px-2 w-24"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Enter') { const v = parseFloat(draft); if (!isNaN(v)) onChange(v); setEditing(false) }
          if (e.key === 'Escape') setEditing(false)
        }}
      />
      <button onClick={() => { const v = parseFloat(draft); if (!isNaN(v)) onChange(v); setEditing(false) }}>
        <Check size={14} style={{ color: '#16A34A' }} />
      </button>
      <button onClick={() => setEditing(false)}>
        <X size={14} style={{ color: '#DC2626' }} />
      </button>
    </div>
  )
}

function MiniBar({ value, max, color = '#1E6BFF' }: { value: number; max: number; color?: string }) {
  const pct = Math.min((value / (max || 1)) * 100, 100)
  return (
    <div style={{ width: 52, height: 4, background: '#E6E8EC', borderRadius: 2, overflow: 'hidden', marginTop: 4 }}>
      <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 2 }} />
    </div>
  )
}

const PLAT_BADGE: Record<string, string> = { meta: 'badge-meta', google: 'badge-google', tiktok: 'badge-tiktok' }
const PLAT_LABEL: Record<string, string> = { meta: 'Meta', google: 'Google', tiktok: 'TikTok' }

// ─── Level 1: Campaign table row ──────────────────────────────────────────────

function CampRow({
  c, onDrill, maxSpend, isActive, onToggle, budget, onBudget,
}: {
  c: Campaign; onDrill: () => void; maxSpend: number
  isActive: boolean; onToggle: (v: boolean) => void
  budget: number; onBudget: (v: number) => void
}) {
  return (
    <tr
      style={{ borderBottom: '1px solid #E6E8EC', cursor: 'pointer', transition: 'background 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.background = '#F7F8FA')}
      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
    >
      {/* Name + controls */}
      <td className="px-4 py-3" style={{ minWidth: 300 }}>
        <div className="flex items-center gap-2 flex-wrap">
          <span onClick={e => e.stopPropagation()}>
            <Toggle active={isActive} onChange={onToggle} />
          </span>
          <span className={`status-${isActive ? 'active' : 'paused'}`} />
          <span className={PLAT_BADGE[c.platform]}>{PLAT_LABEL[c.platform]}</span>
          <span className="font-semibold text-ink text-sm" style={{ wordBreak: 'break-word' }}>{c.name}</span>
        </div>
        <div className="flex items-center gap-3 mt-1.5" style={{ paddingLeft: 52 }} onClick={e => e.stopPropagation()}>
          <BudgetEditor value={budget} onChange={onBudget} type={c.budgetType as 'CBO' | 'ABO'} />
          <span className="text-xs" style={{ color: '#6B7280' }}>{c.adSets.length} conjuntos</span>
        </div>
      </td>

      {/* Spend */}
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm font-bold text-ink">{fmt.brlK(c.spend)}</div>
        <MiniBar value={c.spend} max={maxSpend} color="#1E6BFF" />
      </td>

      {/* ROAS */}
      <td className="px-4 py-3" onClick={onDrill}>
        <span className={`text-sm font-bold ${fmt.roasColor(c.roas)}`}>{fmt.roas(c.roas)}</span>
      </td>

      {/* Impressions */}
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{fmt.numK(c.impressions)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPM {fmt.brl(c.cpm)}</div>
      </td>

      {/* Clicks */}
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{fmt.numK(c.clicks)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>{fmt.pct(c.ctr)} CTR</div>
      </td>

      {/* Sales */}
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{c.salesDb}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPA {fmt.brl(c.cpa.db)}</div>
      </td>

      {/* Drill CTA */}
      <td className="px-4 py-3 text-right" onClick={onDrill}>
        <button className="btn-ghost py-1 px-2 text-xs flex items-center gap-1 ml-auto" style={{ fontSize: 11 }}>
          Conjuntos <ChevronRight size={11} />
        </button>
      </td>
    </tr>
  )
}

// ─── Level 2: AdSet table row ─────────────────────────────────────────────────

function AdSetRow({ a, onDrill, maxSpend }: { a: AdSet; onDrill: () => void; maxSpend: number }) {
  const [active, setActive] = useState(a.status === 'ACTIVE')
  const [budget, setBudget] = useState(a.budget)
  return (
    <tr
      style={{ borderBottom: '1px solid #E6E8EC', cursor: 'pointer', transition: 'background 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.background = '#F7F8FA')}
      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
    >
      <td className="px-4 py-3" style={{ minWidth: 300 }}>
        <div className="flex items-center gap-2 flex-wrap">
          <span onClick={e => e.stopPropagation()}><Toggle active={active} onChange={setActive} /></span>
          <span className={`status-${active ? 'active' : 'paused'}`} />
          <span className="font-semibold text-ink text-sm" style={{ wordBreak: 'break-word' }}>{a.name}</span>
        </div>
        <div className="flex items-center gap-3 mt-1.5" style={{ paddingLeft: 52 }} onClick={e => e.stopPropagation()}>
          <BudgetEditor value={budget} onChange={setBudget} type="ABO" />
          <span className="text-xs" style={{ color: '#6B7280' }}>{a.ads.length} anuncios</span>
        </div>
      </td>
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm font-bold text-ink">{fmt.brlK(a.spend)}</div>
        <MiniBar value={a.spend} max={maxSpend} color="#8B5CF6" />
      </td>
      <td className="px-4 py-3" onClick={onDrill}>
        <span className={`text-sm font-bold ${fmt.roasColor(a.roas)}`}>{fmt.roas(a.roas)}</span>
      </td>
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{fmt.numK(a.impressions)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPM {fmt.brl(a.cpm)}</div>
      </td>
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{fmt.numK(a.clicks)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>{fmt.pct(a.ctr)} CTR</div>
      </td>
      <td className="px-4 py-3" onClick={onDrill}>
        <div className="text-sm text-ink">{a.salesDb}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPA {fmt.brl(a.cpa.db)}</div>
      </td>
      <td className="px-4 py-3 text-right" onClick={onDrill}>
        <button className="btn-ghost py-1 px-2 text-xs flex items-center gap-1 ml-auto" style={{ fontSize: 11 }}>
          Anuncios <ChevronRight size={11} />
        </button>
      </td>
    </tr>
  )
}

// ─── Level 3: Ad table row ────────────────────────────────────────────────────

function AdRow({ ad, maxSpend }: { ad: Ad; maxSpend: number }) {
  const [active, setActive] = useState(ad.status === 'ACTIVE')
  return (
    <tr
      style={{ borderBottom: '1px solid #E6E8EC', transition: 'background 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.background = '#F7F8FA')}
      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
    >
      <td className="px-4 py-3" style={{ minWidth: 300 }}>
        <div className="flex items-center gap-2">
          <Toggle active={active} onChange={setActive} />
          <span className={`status-${active ? 'active' : 'paused'}`} />
          {ad.thumbnail && (
            <img
              src={ad.thumbnail} alt=""
              style={{ width: 36, height: 36, borderRadius: 6, objectFit: 'cover', border: '1px solid #E6E8EC', flexShrink: 0 }}
            />
          )}
          <span className="font-semibold text-ink text-sm" style={{ wordBreak: 'break-word' }}>{ad.name}</span>
        </div>
      </td>
      <td className="px-4 py-3">
        <div className="text-sm font-bold text-ink">{fmt.brlK(ad.spend)}</div>
        <MiniBar value={ad.spend} max={maxSpend} color="#F59E0B" />
      </td>
      <td className="px-4 py-3">
        <span className={`text-sm font-bold ${fmt.roasColor(ad.roas)}`}>{fmt.roas(ad.roas)}</span>
      </td>
      <td className="px-4 py-3">
        <div className="text-sm text-ink">{fmt.numK(ad.impressions)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPM {fmt.brl(ad.cpm)}</div>
      </td>
      <td className="px-4 py-3">
        <div className="text-sm text-ink">{fmt.numK(ad.clicks)}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>{fmt.pct(ad.ctr)} CTR</div>
      </td>
      <td className="px-4 py-3">
        <div className="text-sm text-ink">{ad.salesDb}</div>
        <div className="text-xs" style={{ color: '#6B7280' }}>CPA {fmt.brl(ad.cpa.db)}</div>
      </td>
      <td className="px-4 py-3 text-right">
        {ad.postUrl && (
          <a
            href={ad.postUrl} target="_blank" rel="noreferrer"
            className="btn-ghost py-1 px-2 text-xs flex items-center gap-1 ml-auto"
            style={{ fontSize: 11, textDecoration: 'none' }}
            onClick={e => e.stopPropagation()}
          >
            <ExternalLink size={11} /> Ver post
          </a>
        )}
      </td>
    </tr>
  )
}

// ─── KPI summary bar ─────────────────────────────────────────────────────────

function KpiBar({ spend, roas, impressions, clicks, sales }: {
  spend: number; roas: number; impressions: number; clicks: number; sales: number
}) {
  const items = [
    { label: 'Investimento', value: fmt.brlK(spend),        color: '#111827',    icon: <DollarSign size={13} /> },
    { label: 'ROAS Medio',   value: fmt.roas(roas),         color: roas >= 5 ? '#16A34A' : roas >= 3 ? '#D97706' : '#DC2626', icon: <TrendingUp size={13} /> },
    { label: 'Impressoes',   value: fmt.numK(impressions),  color: '#4B5563', icon: <MousePointer size={13} /> },
    { label: 'Cliques',      value: fmt.numK(clicks),       color: '#4B5563', icon: <MousePointer size={13} /> },
    { label: 'Compras',      value: fmt.num(sales),         color: '#16A34A', icon: <ShoppingCart size={13} /> },
  ]
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: `repeat(${items.length},1fr)`,
      gap: 1, background: '#E6E8EC', borderRadius: 12,
      overflow: 'hidden', border: '1px solid #E6E8EC',
    }}>
      {items.map((k, i) => (
        <div key={i} style={{ background: '#FFFFFF', padding: '12px 16px' }}>
          <div className="flex items-center gap-1.5 mb-1.5" style={{ color: '#6B7280', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            {k.icon} {k.label}
          </div>
          <div className="font-bold" style={{ color: k.color, fontSize: 18 }}>{k.value}</div>
        </div>
      ))}
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function CampaignManager({ campaigns }: { campaigns: Campaign[] }) {
  const [level,   setLevel]   = useState<ViewLevel>('campaigns')
  const [selCamp, setSelCamp] = useState<Campaign | null>(null)
  const [selAS,   setSelAS]   = useState<AdSet | null>(null)

  const [search,         setSearch]         = useState('')
  const [filterStatus,   setFilterStatus]   = useState<'all' | 'ACTIVE' | 'PAUSED'>('all')
  const [filterPlatform, setFilterPlatform] = useState<'all' | 'meta' | 'google' | 'tiktok'>('all')
  const [sortBy,         setSortBy]         = useState<'spend' | 'roas' | 'salesDb'>('spend')

  // Editable campaign state
  const [activeMap, setActiveMap] = useState<Record<string, boolean>>(
    Object.fromEntries(campaigns.map(c => [c.id, c.status === 'ACTIVE']))
  )
  const [budgets, setBudgets] = useState<Record<string, number>>(
    Object.fromEntries(campaigns.map(c => [c.id, c.budget]))
  )

  // Filtered & sorted lists
  const visCamps = useMemo(() => {
    let items = [...campaigns]
    if (search)               items = items.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
    if (filterStatus !== 'all')   items = items.filter(c => c.status === filterStatus)
    if (filterPlatform !== 'all') items = items.filter(c => c.platform === filterPlatform)
    return items.sort((a, b) => (b as any)[sortBy] - (a as any)[sortBy])
  }, [campaigns, search, filterStatus, filterPlatform, sortBy])

  const visAS = useMemo(() => {
    if (!selCamp) return []
    let items = [...selCamp.adSets]
    if (filterStatus !== 'all') items = items.filter(a => a.status === filterStatus)
    return items.sort((a, b) => (b as any)[sortBy] - (a as any)[sortBy])
  }, [selCamp, filterStatus, sortBy])

  const visAds = useMemo(() => {
    if (!selAS) return []
    let items = [...selAS.ads]
    if (filterStatus !== 'all') items = items.filter(a => a.status === filterStatus)
    return items.sort((a, b) => (b as any)[sortBy] - (a as any)[sortBy])
  }, [selAS, filterStatus, sortBy])

  // KPIs
  const kpis = useMemo(() => {
    const rows: any[] = level === 'campaigns' ? visCamps : level === 'adsets' ? visAS : visAds
    return {
      spend:       rows.reduce((s, m) => s + m.spend, 0),
      sales:       rows.reduce((s, m) => s + m.salesDb, 0),
      impressions: rows.reduce((s, m) => s + m.impressions, 0),
      clicks:      rows.reduce((s, m) => s + m.clicks, 0),
      roas:        rows.length ? rows.reduce((s, m) => s + m.roas, 0) / rows.length : 0,
    }
  }, [level, visCamps, visAS, visAds])

  const maxSpend = useMemo(() => {
    const rows: any[] = level === 'campaigns' ? visCamps : level === 'adsets' ? visAS : visAds
    return Math.max(...rows.map(x => x.spend), 1)
  }, [level, visCamps, visAS, visAds])

  // Level meta
  const LEVEL_COLOR = { campaigns: '#1E6BFF', adsets: '#8B5CF6', ads: '#F59E0B' }
  const LEVEL_NAME  = { campaigns: 'Campanhas', adsets: 'Conjuntos', ads: 'Anuncios' }
  const LEVEL_COUNT = { campaigns: visCamps.length, adsets: visAS.length, ads: visAds.length }

  function goLevel(l: ViewLevel) {
    setLevel(l)
    if (l === 'campaigns') { setSelCamp(null); setSelAS(null) }
    if (l === 'adsets')    setSelAS(null)
  }

  const HEADERS = ['NOME / STATUS', 'INVESTIMENTO', 'ROAS', 'IMPRESSOES', 'CLIQUES', 'COMPRAS', '']

  return (
    <div className="flex flex-col gap-4">

      {/* ── Breadcrumb ─────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => goLevel('campaigns')}
          className="flex items-center gap-1.5 text-xs py-1 px-2.5 rounded-lg transition-all"
          style={{
            border: `1px solid ${level === 'campaigns' ? '#1E6BFF44' : '#E6E8EC'}`,
            background: level === 'campaigns' ? '#1E6BFF1A' : 'transparent',
            color: level === 'campaigns' ? '#1E6BFF' : '#6B7280',
            fontWeight: level === 'campaigns' ? 700 : 400,
          }}
        >
          <Layers size={11} /> Campanhas
        </button>

        {selCamp && (
          <>
            <ChevronRight size={11} style={{ color: '#6B7280' }} />
            <button
              onClick={() => goLevel('adsets')}
              className="flex items-center gap-1.5 text-xs py-1 px-2.5 rounded-lg transition-all"
              style={{
                maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                border: `1px solid ${level === 'adsets' ? '#8B5CF644' : '#E6E8EC'}`,
                background: level === 'adsets' ? 'rgba(139,92,246,0.1)' : 'transparent',
                color: level === 'adsets' ? '#7C3AED' : '#6B7280',
                fontWeight: level === 'adsets' ? 700 : 400,
              }}
            >
              <Target size={11} style={{ flexShrink: 0 }} />
              <span className="truncate ml-1">{selCamp.name}</span>
            </button>
          </>
        )}

        {selAS && (
          <>
            <ChevronRight size={11} style={{ color: '#6B7280' }} />
            <button
              onClick={() => goLevel('ads')}
              className="flex items-center gap-1.5 text-xs py-1 px-2.5 rounded-lg transition-all"
              style={{
                maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                border: '1px solid rgba(245,158,11,0.3)', background: 'rgba(245,158,11,0.1)',
                color: '#F59E0B', fontWeight: 700,
              }}
            >
              <Image size={11} style={{ flexShrink: 0 }} />
              <span className="truncate ml-1">{selAS.name}</span>
            </button>
          </>
        )}
      </div>

      {/* ── Level tabs ─────────────────────────────────────────────────────── */}
      <div style={{
        display: 'inline-flex', gap: 2, background: '#FFFFFF',
        borderRadius: 10, padding: 4, border: '1px solid #E6E8EC',
      }}>
        {(['campaigns', 'adsets', 'ads'] as ViewLevel[]).map((l, i) => {
          const labels = ['Nivel 1 - Campanhas', 'Nivel 2 - Conjuntos', 'Nivel 3 - Anuncios']
          const icons  = [<Layers size={12} />, <Target size={12} />, <Image size={12} />]
          const colors = ['#1E6BFF', '#8B5CF6', '#F59E0B']
          const isActive   = level === l
          const isDisabled = (l === 'adsets' && !selCamp) || (l === 'ads' && !selAS)
          return (
            <button
              key={l}
              disabled={isDisabled}
              onClick={() => !isDisabled && goLevel(l)}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '5px 14px', borderRadius: 8, border: 'none',
                background: isActive ? colors[i] : 'transparent',
                color: isActive ? '#fff' : isDisabled ? '#C4C8D0' : '#4B5563',
                fontSize: 12, fontWeight: isActive ? 700 : 400,
                cursor: isDisabled ? 'not-allowed' : 'pointer',
                transition: 'all 0.12s',
              }}
            >
              {icons[i]} {labels[i]}
            </button>
          )
        })}
      </div>

      {/* ── KPI bar ────────────────────────────────────────────────────────── */}
      <KpiBar
        spend={kpis.spend} roas={kpis.roas}
        impressions={kpis.impressions} clicks={kpis.clicks} sales={kpis.sales}
      />

      {/* ── Filters ────────────────────────────────────────────────────────── */}
      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1" style={{ minWidth: 180 }}>
          <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#6B7280' }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar..."
            className="input-field text-sm w-full"
            style={{ paddingLeft: 30 }}
          />
        </div>
        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value as any)}
          className="input-field text-sm"
          style={{ width: 'auto' }}
        >
          <option value="all">Todos os status</option>
          <option value="ACTIVE">Ativo</option>
          <option value="PAUSED">Pausado</option>
        </select>
        {level === 'campaigns' && (
          <select
            value={filterPlatform}
            onChange={e => setFilterPlatform(e.target.value as any)}
            className="input-field text-sm"
            style={{ width: 'auto' }}
          >
            <option value="all">Todas plataformas</option>
            <option value="meta">Meta</option>
            <option value="google">Google</option>
            <option value="tiktok">TikTok</option>
          </select>
        )}
        <select
          value={sortBy}
          onChange={e => setSortBy(e.target.value as any)}
          className="input-field text-sm"
          style={{ width: 'auto' }}
        >
          <option value="spend">Ordenar: Investimento</option>
          <option value="roas">Ordenar: ROAS</option>
          <option value="salesDb">Ordenar: Compras</option>
        </select>
      </div>

      {/* ── Table ──────────────────────────────────────────────────────────── */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>

        {/* Table column headers */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '3fr 1.4fr 1fr 1.3fr 1.3fr 1fr 110px',
          padding: '10px 16px',
          borderBottom: '1px solid #E6E8EC',
          background: 'rgba(255,255,255,0.8)',
        }}>
          {HEADERS.map((h, i) => (
            <span key={i} style={{
              fontSize: 10, fontWeight: 700, color: '#6B7280',
              textTransform: 'uppercase', letterSpacing: '0.08em',
              textAlign: i === HEADERS.length - 1 ? 'right' : 'left',
            }}>
              {h}
            </span>
          ))}
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <tbody>
              {level === 'campaigns' && visCamps.map(c => (
                <CampRow
                  key={c.id}
                  c={c}
                  maxSpend={maxSpend}
                  isActive={activeMap[c.id]}
                  onToggle={v => setActiveMap(p => ({ ...p, [c.id]: v }))}
                  budget={budgets[c.id]}
                  onBudget={v => setBudgets(p => ({ ...p, [c.id]: v }))}
                  onDrill={() => { setSelCamp(c); setLevel('adsets') }}
                />
              ))}

              {level === 'adsets' && visAS.map(a => (
                <AdSetRow
                  key={a.id}
                  a={a}
                  maxSpend={maxSpend}
                  onDrill={() => { setSelAS(a); setLevel('ads') }}
                />
              ))}

              {level === 'ads' && visAds.map(a => (
                <AdRow key={a.id} ad={a} maxSpend={maxSpend} />
              ))}

              {/* Empty state */}
              {((level === 'campaigns' && !visCamps.length) ||
                (level === 'adsets'   && !visAS.length) ||
                (level === 'ads'      && !visAds.length)) && (
                <tr>
                  <td colSpan={7} style={{ padding: 48, textAlign: 'center', color: '#6B7280', fontSize: 13 }}>
                    Nenhum item encontrado com os filtros aplicados
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div style={{
          padding: '10px 16px', borderTop: '1px solid #E6E8EC',
          background: 'rgba(255,255,255,0.6)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span className="text-xs" style={{ color: '#6B7280' }}>
            {LEVEL_COUNT[level]} {LEVEL_NAME[level]}
          </span>
          <span className="text-xs" style={{ color: '#C4C8D0' }}>
            {level !== 'ads' ? 'Clique em uma linha para abrir o nivel seguinte' : 'Nivel mais granular'}
          </span>
        </div>
      </div>

      {/* ── Back button ────────────────────────────────────────────────────── */}
      {level !== 'campaigns' && (
        <button
          onClick={() => goLevel(level === 'ads' ? 'adsets' : 'campaigns')}
          className="btn-ghost text-sm flex items-center gap-2 self-start"
        >
          <ArrowLeft size={14} />
          Voltar para {level === 'ads' ? 'Conjuntos de Anuncios' : 'Campanhas'}
        </button>
      )}
    </div>
  )
}
