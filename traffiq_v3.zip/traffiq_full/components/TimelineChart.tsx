import { useState } from 'react'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { fmt } from '@/lib/format'

type Metric = 'spend' | 'clicks' | 'cpm' | 'revenue' | 'roas'

const METRICS: { key: Metric; label: string; color: string; format: (v: number) => string }[] = [
  { key: 'spend',   label: 'Investido', color: '#8B5CF6', format: fmt.brlK },
  { key: 'clicks',  label: 'Cliques',   color: '#0891B2', format: fmt.numK },
  { key: 'cpm',     label: 'CPM',       color: '#D97706', format: fmt.brl  },
  { key: 'revenue', label: 'Receita',   color: '#1E6BFF', format: fmt.brlK },
  { key: 'roas',    label: 'ROAS',      color: '#16A34A', format: fmt.roas },
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-3 min-w-[140px]">
      <div className="text-xs mb-2" style={{ color: '#4B5563' }}>{label}</div>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-xs" style={{ color: '#4B5563' }}>{p.name}</span>
          </div>
          <span className="text-sm font-semibold text-ink">
            {METRICS.find(m => m.key === p.dataKey)?.format(p.value) || p.value}
          </span>
        </div>
      ))}
    </div>
  )
}

export default function TimelineChart({ data }: { data: any[] }) {
  // Default: investido, cliques, cpm
  const [active, setActive] = useState<Metric[]>(['spend', 'clicks', 'cpm'])

  const toggle = (key: Metric) =>
    setActive(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key])

  // Add cpm to data if missing (calculate from spend/impressions)
  const enriched = data.map(d => ({
    ...d,
    cpm: d.cpm ?? (d.impressions > 0 ? parseFloat(((d.spend / d.impressions) * 1000).toFixed(2)) : 0),
  }))

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Toggles */}
      <div className="flex flex-wrap gap-2">
        {METRICS.map(m => (
          <button key={m.key} onClick={() => toggle(m.key)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
            style={{
              background: active.includes(m.key) ? `${m.color}20` : '#F7F8FA',
              border: `1px solid ${active.includes(m.key) ? m.color + '40' : '#E6E8EC'}`,
              color:  active.includes(m.key) ? m.color : '#6B7280',
            }}>
            <div className="w-2 h-2 rounded-full" style={{ background: m.color, opacity: active.includes(m.key) ? 1 : 0.3 }} />
            {m.label}
          </button>
        ))}
      </div>

      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={enriched} margin={{ top:5, right:10, left:0, bottom:0 }}>
          <defs>
            {METRICS.map(m => (
              <linearGradient key={m.key} id={`grad-${m.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={m.color} stopOpacity={0.25} />
                <stop offset="95%" stopColor={m.color} stopOpacity={0} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" />
          <XAxis dataKey="label" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false}
            tickFormatter={(_: any, idx: number) => idx % 5 === 0 ? enriched[idx]?.label : ''} />
          <YAxis tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} width={48} />
          <Tooltip content={<CustomTooltip />} />
          {METRICS.filter(m => active.includes(m.key)).map(m => (
            <Area key={m.key} type="monotone" dataKey={m.key} name={m.label}
              stroke={m.color} strokeWidth={2} fill={`url(#grad-${m.key})`}
              dot={false} activeDot={{ r:4, fill:m.color }} />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
