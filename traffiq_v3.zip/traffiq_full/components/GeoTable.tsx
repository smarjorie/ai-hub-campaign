import { MapPin, Info } from 'lucide-react'
import { fmt } from '@/lib/format'

interface GeoRow { region: string; reach: number; spend?: number; conversions?: number }

interface Props {
  data: GeoRow[]
  isReal?: boolean
  onGoToIntegrations?: () => void
}

export default function GeoTable({ data, isReal, onGoToIntegrations }: Props) {
  // Guard: filter out rows with no region or zero reach
  const valid = (data || []).filter(r => r?.region && (r.reach || 0) > 0)
  const max   = valid[0]?.reach || 1

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <MapPin size={16} style={{ color: '#1E6BFF' }} />
        <span className="section-title">Alcance por Região</span>
        {isReal
          ? <span className="badge-green ml-1">Ao vivo</span>
          : <span className="badge-yellow ml-1">Demo</span>
        }
      </div>

      {valid.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-center rounded-xl"
          style={{ background: 'rgba(30,107,255,0.04)', border: '1px dashed rgba(30,107,255,0.15)' }}>
          <Info size={24} style={{ color: '#6B7280' }} className="mb-2" />
          <div className="text-sm font-medium text-ink mb-1">Sem dados de região</div>
          <p className="text-xs max-w-[200px]" style={{ color: '#6B7280' }}>
            {isReal
              ? 'Nenhum dado de região disponível para o período selecionado.'
              : 'Conecte o Meta Ads para ver a distribuição geográfica real do seu público.'
            }
          </p>
          {!isReal && onGoToIntegrations && (
            <button onClick={onGoToIntegrations} className="btn-ghost text-xs mt-3 py-1.5">
              Ir para Integrações
            </button>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-2.5">
          {valid.slice(0, 10).map((row, i) => (
            <div key={`${row.region}-${i}`}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs w-4 text-right flex-shrink-0 font-mono" style={{ color: '#6B7280' }}>{i+1}</span>
                  <span className="text-sm text-ink">{row.region}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="text-xs font-medium" style={{ color: '#4B5563' }}>{fmt.numK(row.reach)}</span>
                  {(row.conversions || 0) > 0 && (
                    <span className="badge-green">{row.conversions} conv.</span>
                  )}
                </div>
              </div>
              <div className="h-1.5 rounded-full ml-6" style={{ background: '#E6E8EC' }}>
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${Math.max(2, (row.reach / max) * 100)}%`,
                    background: 'linear-gradient(90deg, #1E6BFF, #0891B2)',
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
