import { fmt } from '@/lib/format'
import { ChevronRight, MessageSquare } from 'lucide-react'

interface FunnelStep { label: string; value: number; pct: number }

interface Props {
  data:      FunnelStep[]
  onSelect?: (step: FunnelStep) => void
  selected?: string | null
}

const COLORS = ['#1E6BFF', '#1A5FE8', '#1554D0', '#1049B8', '#0A3E9F']

const RATE_LABELS: Record<string, string> = {
  'Page Views':  'Connect Rate',
  'Add to Cart': 'Taxa Add Cart',
  'Checkouts':   'Taxa Checkout',
  'Compras':     'Taxa Compras',
}

// Etapas que têm dados de WhatsApp relevantes
const WA_STEPS = new Set(['Cliques', 'Page Views', 'Checkouts', 'Compras'])

export default function FunnelChart({ data, onSelect, selected }: Props) {
  if (!data.length) return null
  const max = data[0].value || 1

  return (
    <div className="flex flex-col items-center gap-0 w-full">
      {data.map((step, i) => {
        const widthPct  = 30 + ((step.value / max) * 55)
        const isLast    = i === data.length - 1
        const isActive  = selected === step.label
        const hasWA     = WA_STEPS.has(step.label)

        return (
          <div key={step.label} className="w-full flex items-center gap-3">
            {/* Funnel segment */}
            <div className="flex-1 flex flex-col items-center">
              <button
                onClick={() => onSelect?.(step)}
                className="relative flex items-center justify-center transition-all duration-200 w-full focus:outline-none"
                style={{
                  cursor: onSelect ? 'pointer' : 'default',
                  filter: isActive ? 'brightness(1.15)' : undefined,
                }}
                title={`Clique para detalhar ${step.label}`}
              >
                <div
                  style={{
                    width: `${widthPct}%`,
                    minWidth: 100,
                    background: isActive
                      ? `linear-gradient(135deg, ${COLORS[i]}, #0891B2)`
                      : `linear-gradient(135deg, ${COLORS[i]}, ${COLORS[Math.min(i+1, COLORS.length-1)]})`,
                    height: 44,
                    clipPath: isLast
                      ? 'polygon(8% 0%, 92% 0%, 100% 100%, 0% 100%)'
                      : 'polygon(0% 0%, 100% 0%, 92% 100%, 8% 100%)',
                    boxShadow: isActive
                      ? `0 0 24px ${COLORS[i]}80`
                      : `0 4px 20px ${COLORS[i]}40`,
                    marginBottom: isLast ? 0 : -2,
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <div className="text-center px-2 pointer-events-none">
                    <div className="text-white text-xs font-semibold leading-tight flex items-center justify-center gap-1">
                      {step.label}
                      {hasWA && <MessageSquare size={9} style={{ opacity: 0.7 }} />}
                    </div>
                    <div className="text-white font-bold text-sm">{fmt.numK(step.value)}</div>
                  </div>
                </div>

                {/* Active indicator */}
                {isActive && onSelect && (
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 -translate-x-1"
                    style={{ color: '#0891B2' }}>
                    <ChevronRight size={16} />
                  </div>
                )}
              </button>
            </div>

            {/* Conversion rate + click hint */}
            <div className="w-32 flex flex-col gap-0.5 flex-shrink-0">
              {i > 0 ? (
                <>
                  <div className="text-xs" style={{ color: '#6B7280' }}>
                    {RATE_LABELS[step.label] || 'Taxa'}
                  </div>
                  <div className="text-ink font-bold text-base leading-tight">{step.pct}%</div>
                </>
              ) : (
                <div className="text-xs" style={{ color: '#6B7280' }}>Entrada</div>
              )}
              {onSelect && (
                <div className="text-xs mt-0.5 flex items-center gap-1"
                  style={{ color: isActive ? '#0891B2' : '#9CA3AF' }}>
                  {isActive ? '← detalhe aberto' : 'clique p/ detalhar'}
                </div>
              )}
            </div>
          </div>
        )
      })}

      {/* Overall conversion */}
      {data.length >= 2 && (
        <div className="mt-4 w-full flex items-center justify-between px-3 py-2 rounded-xl"
          style={{ background: 'rgba(30,107,255,0.08)', border: '1px solid rgba(30,107,255,0.15)' }}>
          <span className="text-xs" style={{ color: '#4B5563' }}>Taxa de Conversão Geral</span>
          <span className="text-ink font-bold">
            {((data[data.length-1].value / data[0].value) * 100).toFixed(2)}%
          </span>
        </div>
      )}
    </div>
  )
}
