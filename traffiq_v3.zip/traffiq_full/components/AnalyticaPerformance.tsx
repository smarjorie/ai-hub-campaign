import { useState, useMemo } from 'react'
import {
  TrendingUp, Eye, Globe, Users, Clock, BarChart2, MessageSquare
} from 'lucide-react'
import {
  ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, PieChart, Pie, Cell, BarChart,
} from 'recharts'
import FunnelChart from '@/components/FunnelChart'
import FunnelDetail from '@/components/FunnelDetail'
import GeoTable from '@/components/GeoTable'
import DemographicsChart from '@/components/DemographicsChart'
import TrafficSourceChart from '@/components/TrafficSourceChart'
import { fmt } from '@/lib/format'
import { genHourlySales } from '@/lib/mockData'

interface Props {
  funnel:       any[]
  geoData:      any[]
  demographics: any
  summary:      any
  isReal:       boolean
  metaToken:    string
  accountId:    string
  period:       string
  onGoIntegrations: () => void
}

type Tab = 'funil' | 'origens' | 'horario' | 'geo' | 'demograficos'

const TABS: { id: Tab; label: string; icon: any }[] = [
  { id: 'funil',       label: 'Funil de Tráfego',   icon: TrendingUp  },
  { id: 'origens',     label: 'Origem dos Acessos',  icon: Globe       },
  { id: 'horario',     label: 'Vendas por Horário',  icon: Clock       },
  { id: 'geo',         label: 'Mapa de Alcance',     icon: Eye         },
  { id: 'demograficos',label: 'Público',             icon: Users       },
]

const HourTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-3">
      <div className="text-xs mb-1.5" style={{ color: '#4B5563' }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.fill || p.stroke }} />
          <span className="text-xs text-ink font-semibold">
            {p.dataKey === 'revenue' ? fmt.brl(p.value) : `${p.value} vendas`}
          </span>
        </div>
      ))}
    </div>
  )
}

export default function AnalyticaPerformance({
  funnel, geoData, demographics, summary,
  isReal, metaToken, accountId, period, onGoIntegrations,
}: Props) {
  const [tab,               setTab]               = useState<Tab>('funil')
  const [selectedFunnelStep,setSelectedFunnelStep]= useState<any>(null)
  const hourly = useMemo(() => genHourlySales(), [])

  // Extra KPIs for analytics view
  const kpis = [
    { label:'ROAS',       value: fmt.roas(summary.roas),    color:'#0891B2' },
    { label:'Receita',    value: fmt.brlK(summary.revenue), color:'#16A34A' },
    { label:'Alcance',    value: fmt.numK(summary.reach||0),color:'#8B5CF6' },
    { label:'Frequência', value: `${(summary.frequency||0).toFixed(2)}x`,   color:'#D97706' },
    { label:'CPA',        value: fmt.brl(summary.cpa?.db||0),color:'#DC2626'},
    { label:'CTR',        value: fmt.pct(summary.ctr||0),   color:'#1E6BFF' },
  ]

  return (
    <div className="flex flex-col gap-5">
      {/* Extra KPIs */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {kpis.map(k => (
          <div key={k.label} className="card p-3">
            <div className="metric-label mb-1">{k.label}</div>
            <div className="text-lg font-black" style={{ color: k.color }}>{k.value}</div>
          </div>
        ))}
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-0 border-b flex-wrap" style={{ borderColor:'#E6E8EC' }}>
        {TABS.map(t => {
          const Icon   = t.icon
          const active = tab === t.id
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-all relative whitespace-nowrap"
              style={{ color: active ? '#1E6BFF' : '#6B7280' }}>
              <Icon size={13} />
              {t.label}
              {active && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full"
                  style={{ background: '#1E6BFF' }} />
              )}
            </button>
          )
        })}
      </div>

      {/* ── FUNIL ──────────────────────────────────────────────────────── */}
      {tab === 'funil' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-5">
            <div className="section-title mb-2">Funil de Tráfego</div>
            <div className="text-xs mb-5" style={{ color:'#6B7280' }}>
              Clique em uma etapa para ver o detalhe e origem dos dados
            </div>
            <FunnelChart
              data={funnel}
              onSelect={setSelectedFunnelStep}
              selected={selectedFunnelStep?.label}
            />
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Métricas por Etapa</div>
            {funnel.map((step: any, i: number) => (
              <div key={step.label}
                className="flex items-center justify-between py-2.5 border-b cursor-pointer transition-colors"
                style={{ borderColor:'#E6E8EC' }}
                onClick={() => setSelectedFunnelStep(step)}
                onMouseEnter={e => (e.currentTarget.style.background='rgba(30,107,255,0.04)')}
                onMouseLeave={e => (e.currentTarget.style.background='transparent')}>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs"
                    style={{ background:'rgba(30,107,255,0.15)', color:'#1E6BFF' }}>{i+1}</div>
                  <span className="font-medium text-ink text-sm">{step.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-ink">{fmt.num(step.value)}</span>
                  {i > 0 && <span className="badge-blue">{step.pct}%</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── ORIGENS ────────────────────────────────────────────────────── */}
      {tab === 'origens' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-5">
            <TrafficSourceChart />
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Distribuição de Investimento por Plataforma</div>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={[
                { name:'Facebook',   value: 43.2, color:'#1877F2' },
                { name:'Instagram',  value: 31.8, color:'#E1306C' },
                { name:'Google',     value: 14.6, color:'#EA4335' },
                { name:'Orgânico',   value:  8.5, color:'#16A34A' },
                { name:'TikTok',     value:  1.9, color:'#FF0050' },
              ]} layout="vertical" margin={{ top:0, right:40, left:10, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" horizontal={false} />
                <XAxis type="number" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false}
                  tickFormatter={v => `${v}%`} />
                <YAxis type="category" dataKey="name" tick={{ fill:'#4B5563', fontSize:12 }}
                  axisLine={false} tickLine={false} width={72} />
                <Tooltip contentStyle={{ background:'#FFFFFF', border:'1px solid #E6E8EC', borderRadius:12 }}
                  formatter={(v: any) => [`${v}%`, 'Share']} />
                <Bar dataKey="value" name="% tráfego" radius={[0,6,6,0]}>
                  {[
                    { name:'Facebook',  color:'#1877F2' },
                    { name:'Instagram', color:'#E1306C' },
                    { name:'Google',    color:'#EA4335' },
                    { name:'Orgânico',  color:'#16A34A' },
                    { name:'TikTok',    color:'#FF0050' },
                  ].map((e, i) => <Cell key={i} fill={e.color} opacity={0.85} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ── HORÁRIO ────────────────────────────────────────────────────── */}
      {tab === 'horario' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-5">
            <div className="section-title mb-4">Volume de Vendas por Hora</div>
            <ResponsiveContainer width="100%" height={260}>
              <ComposedChart data={hourly} margin={{ top:5, right:20, left:0, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" />
                <XAxis dataKey="hour" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} interval={2} />
                <YAxis yAxisId="left"  tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} width={36} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} width={60}
                  tickFormatter={v => fmt.brlK(v)} />
                <Tooltip content={<HourTip />} />
                <Bar yAxisId="left" dataKey="sales" fill="#1E6BFF" radius={[4,4,0,0]} name="Vendas" opacity={0.9} />
                <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#0891B2" strokeWidth={2.5} dot={false} name="Receita" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Análise por Período do Dia</div>
            {[
              { period:'Madrugada (00h–05h)', sales: hourly.slice(0,6).reduce((s:number,h:any)=>s+h.sales,0),   color:'#6B7280', desc:'Volume baixo — evite concentrar verba' },
              { period:'Manhã (06h–11h)',     sales: hourly.slice(6,12).reduce((s:number,h:any)=>s+h.sales,0),  color:'#D97706', desc:'Pico moderado — bom para awareness' },
              { period:'Tarde (12h–17h)',     sales: hourly.slice(12,18).reduce((s:number,h:any)=>s+h.sales,0), color:'#1E6BFF', desc:'Volume alto — bom para conversão' },
              { period:'Noite (18h–23h)',     sales: hourly.slice(18,24).reduce((s:number,h:any)=>s+h.sales,0), color:'#16A34A', desc:'Pico máximo — priorize o orçamento aqui' },
            ].map(p => {
              const total = hourly.reduce((s: number, h: any) => s + h.sales, 0) || 1
              const pct   = ((p.sales / total) * 100).toFixed(1)
              return (
                <div key={p.period} className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-ink font-medium">{p.period}</span>
                    <span className="text-sm font-bold" style={{ color: p.color }}>{pct}%</span>
                  </div>
                  <div className="h-2 rounded-full mb-1" style={{ background:'#E6E8EC' }}>
                    <div className="h-full rounded-full transition-all"
                      style={{ width:`${pct}%`, background: p.color, opacity: 0.8 }} />
                  </div>
                  <div className="text-xs" style={{ color:'#6B7280' }}>{p.desc}</div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── GEO ────────────────────────────────────────────────────────── */}
      {tab === 'geo' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-5">
            <GeoTable data={geoData} isReal={isReal} onGoToIntegrations={onGoIntegrations} />
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Investimento por Região</div>
            {geoData.filter((d:any) => d.spend > 0).length === 0 ? (
              <div className="flex items-center justify-center h-48 text-sm" style={{ color:'#6B7280' }}>
                Sem dados de investimento por região.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart
                  data={geoData.slice(0,8).map((d:any) => ({
                    name: (d.region||'').replace(' (state)','').slice(0,16),
                    spend: d.spend||0,
                    conv: d.conversions||0,
                  }))}
                  layout="vertical" margin={{ top:0, right:40, left:40, bottom:0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" horizontal={false} />
                  <XAxis type="number" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="name" tick={{ fill:'#4B5563', fontSize:11 }}
                    axisLine={false} tickLine={false} width={100} />
                  <Tooltip contentStyle={{ background:'#FFFFFF', border:'1px solid #E6E8EC', borderRadius:12 }} />
                  <Bar dataKey="spend" name="Investido (R$)" fill="#1E6BFF" radius={[0,4,4,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      )}

      {/* ── DEMOGRAFICOS ───────────────────────────────────────────────── */}
      {tab === 'demograficos' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-6"><DemographicsChart data={demographics} /></div>
          <div className="card p-6">
            <div className="section-title mb-4">Distribuição Etária</div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={(demographics.age||[]).map((a:any) => ({ age:a.name, pct:a.value }))}
                margin={{ top:0, right:0, left:-20, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" />
                <XAxis dataKey="age" tick={{ fill:'#6B7280', fontSize:11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill:'#6B7280', fontSize:11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background:'#FFFFFF', border:'1px solid #E6E8EC', borderRadius:12 }} />
                <Bar dataKey="pct" name="%" fill="#1E6BFF" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Funnel detail drawer */}
      <FunnelDetail
        step={selectedFunnelStep}
        onClose={() => setSelectedFunnelStep(null)}
        accountId={accountId}
        token={metaToken}
        datePeriod={period}
        isReal={isReal}
      />
    </div>
  )
}
