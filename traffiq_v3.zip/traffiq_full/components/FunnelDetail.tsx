import { useState, useEffect } from 'react'
import {
  X, RefreshCw, MessageSquare, BarChart2, Layers,
  Smartphone, AlertCircle, Info, Monitor, Tablet,
  TrendingUp, DollarSign, Users, ExternalLink,
} from 'lucide-react'
import { fmt } from '@/lib/format'

// ── Mock data ─────────────────────────────────────────────────────────────────
function mockDetail(step: string) {
  const waConvs = step === 'purchases' ? 312 : step === 'checkouts' ? 42 : step === 'clicks' ? 8200 : 0
  return {
    stepTotal: step === 'clicks' ? 378200 : step === 'page_views' ? 265500 : step === 'add_to_cart' ? 853 : step === 'checkouts' ? 254 : 1836,
    actionBreakdown: step === 'clicks' ? [
      { type: 'link_click',           label: 'Cliques no link',           count: 310400, value: 0,      isWhatsApp: false },
      { type: 'landing_page_view',    label: 'Visualizações de página',   count: 265500, value: 0,      isWhatsApp: false },
      { type: 'onsite_conversion.messaging_conversation_started_7d', label: 'Conversa iniciada WA (7d)', count: 8200, value: 0, isWhatsApp: true },
    ] : step === 'purchases' ? [
      { type: 'purchase',              label: 'Compra',             count: 1124, value: 142800, isWhatsApp: false },
      { type: 'omni_purchase',         label: 'Compra (omni)',      count:  712, value:  89400, isWhatsApp: false },
      { type: 'offsite_conversion.fb_pixel_purchase', label: 'Compra (Pixel)', count: 984, value: 124200, isWhatsApp: false },
      { type: 'onsite_conversion.messaging_conversation_started_7d', label: 'Via WhatsApp (CTWA)', count: 312, value: 38400, isWhatsApp: true },
    ] : [
      { type: 'lead',      label: 'Lead',          count: 180, value: 0, isWhatsApp: false },
      { type: 'omni_lead', label: 'Lead (omni)',   count:  74, value: 0, isWhatsApp: false },
      { type: 'onsite_conversion.messaging_conversation_started_7d', label: 'Conversa WA', count: 42, value: 0, isWhatsApp: true },
    ],
    placements: [
      { label: 'Instagram',        impressions: 2820000, clicks: 230000, spend: 67300, actions: 892, ctr: 2.8, cpm: 23.8, isWhatsApp: false },
      { label: 'Facebook',         impressions: 1320000, clicks: 148400, spend: 31800, actions: 621, ctr: 2.1, cpm: 18.4, isWhatsApp: false },
      { label: 'Audience Network', impressions:  480000, clicks:  32100, spend:  8400, actions:  82, ctr: 0.9, cpm: 12.1, isWhatsApp: false },
      { label: 'WhatsApp',         impressions:  210000, clicks:  18100, spend:  3400, actions: waConvs, ctr: 3.2, cpm: 8.6, isWhatsApp: true },
    ],
    devices: [
      { platform: 'mobile_phone', impressions: 3820000, clicks: 298000, spend: 89400 },
      { platform: 'desktop',      impressions:  970000, clicks:  80200, spend: 25500 },
      { platform: 'tablet',       impressions:  200000, clicks:  11800, spend:  3800 },
    ],
    whatsapp: {
      total: waConvs, ctwa: Math.round(waConvs * 0.83),
      firstReply: Math.round(waConvs * 0.41), totalConn: waConvs,
      pctOfStep: waConvs > 0 ? parseFloat(((waConvs / (step === 'clicks' ? 378200 : step === 'checkouts' ? 254 : 1836)) * 100).toFixed(1)) : 0,
      campaigns: waConvs > 0 ? [
        { campaign_id:'c1', campaign_name:'PROS — Escala — Topo de Funil', adset_name:'LAL 1%', ad_id:'a1', ad_name:'Criativo 1 — Depoimento', spend:4200, impressions:180000, clicks:9800, waConvs:148, ctwa:120, firstReply:62, cpl:28.38, revenue:42800, permalink:'https://www.facebook.com/ads/library/?id=123456789', thumbnail:null },
        { campaign_id:'c1', campaign_name:'PROS — Escala — Topo de Funil', adset_name:'Interesse Amplo', ad_id:'a2', ad_name:'Criativo 2 — Produto', spend:2800, impressions:98000, clicks:5200, waConvs:84, ctwa:71, firstReply:38, cpl:33.33, revenue:24200, permalink:'https://www.facebook.com/ads/library/?id=234567890', thumbnail:null },
        { campaign_id:'c2', campaign_name:'RETARGETING — Visitantes 30d', adset_name:'Remarketing 30d', ad_id:'a3', ad_name:'Criativo 3 — VSL Curto', spend:1800, impressions:42000, clicks:3100, waConvs:52, ctwa:44, firstReply:28, cpl:34.62, revenue:14900, permalink:'https://www.instagram.com/p/example123/', thumbnail:null },
        { campaign_id:'c2', campaign_name:'RETARGETING — Visitantes 30d', adset_name:'LAL 3%', ad_id:'a4', ad_name:'Criativo 4 — Oferta', spend:1200, impressions:28000, clicks:2200, waConvs:28, ctwa:21, firstReply:14, cpl:42.86, revenue:8100, permalink:null, thumbnail:null },
      ] : [],
    },
  }
}

// ── Config ────────────────────────────────────────────────────────────────────
interface FunnelStep { label: string; value: number; pct: number }
interface Props {
  step: FunnelStep | null; onClose: () => void
  accountId: string; token: string; datePeriod: string; isReal: boolean
}

const STEP_KEY_MAP: Record<string, string> = {
  'Cliques': 'clicks', 'Page Views': 'page_views',
  'Add to Cart': 'add_to_cart', 'Checkouts': 'checkouts', 'Compras': 'purchases',
}
const PERIOD_MAP: Record<string, string> = {
  'Hoje':'today','Ontem':'yesterday','Últimos 7 dias':'last_7d',
  'Últimos 30 dias':'last_30d','Este mês':'this_month','Mês anterior':'last_month',
}
const DEVICE_ICONS: Record<string, any> = {
  mobile_phone: Smartphone, desktop: Monitor, tablet: Tablet,
}
const DEVICE_LABELS: Record<string, string> = {
  mobile_phone: 'Mobile', desktop: 'Desktop', tablet: 'Tablet', connected_tv: 'Smart TV',
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function FunnelDetail({ step, onClose, accountId, token, datePeriod, isReal }: Props) {
  const [data,    setData]    = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [tab,     setTab]     = useState<'actions'|'placements'|'devices'|'whatsapp'>('actions')

  const stepKey = step ? (STEP_KEY_MAP[step.label] || 'purchases') : 'purchases'

  useEffect(() => {
    if (!step) return
    setData(null); setError(''); setTab('actions')

    if (!isReal || !token || !accountId) {
      setTimeout(() => setData(mockDetail(stepKey)), 250)
      return
    }

    setLoading(true)
    const preset = PERIOD_MAP[datePeriod] || 'last_30d'
    fetch(`/api/meta/funnel-detail?account_id=${accountId}&date_preset=${preset}&step=${stepKey}`, {
      headers: { 'x-meta-token': token },
    })
      .then(r => r.json())
      .then(d => { if (d.error) throw new Error(d.error); setData(d) })
      .catch(e => { setError(e.message); setData(mockDetail(stepKey)) })
      .finally(() => setLoading(false))
  }, [step, stepKey, isReal, token, accountId, datePeriod])

  if (!step) return null

  const maxPlacement = data ? Math.max(...(data.placements || []).map((p: any) => p.impressions || 0), 1) : 1
  const maxDevice    = data ? Math.max(...(data.devices   || []).map((d: any) => d.impressions || 0), 1) : 1
  const waCampaigns  = data?.whatsapp?.campaigns || []

  const TABS = [
    { key: 'actions',    label: 'Datasets',    icon: BarChart2   },
    { key: 'placements', label: 'Plataformas', icon: Layers      },
    { key: 'devices',    label: 'Dispositivos',icon: Smartphone  },
    { key: 'whatsapp',   label: 'WhatsApp',    icon: MessageSquare, highlight: (data?.whatsapp?.total || 0) > 0 },
  ] as const

  return (
    <>
      <div className="fixed inset-0 z-40" style={{ background: 'rgba(17,24,39,0.06)' }} onClick={onClose} />

      <div className="fixed right-0 top-0 bottom-0 z-50 flex flex-col"
        style={{
          width: 'min(540px, 96vw)',
          background: '#FFFFFF',
          borderLeft: '1px solid #E6E8EC',
          boxShadow: '-8px 0 48px rgba(17,24,39,0.06)',
          animation: 'slideFromRight 0.22s ease-out',
        }}>
        <style>{`@keyframes slideFromRight{from{transform:translateX(40px);opacity:0}to{transform:translateX(0);opacity:1}}`}</style>

        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b flex-shrink-0" style={{ borderColor:'#E6E8EC' }}>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background:'#1E6BFF' }} />
              <span className="font-bold text-ink text-xl">{step.label}</span>
              <span className="badge-blue text-sm">{fmt.numK(step.value)}</span>
              {!isReal && <span className="badge-yellow">Demo</span>}
            </div>
            <div className="text-xs mt-1" style={{ color:'#6B7280' }}>Detalhe dos dados que compõem esta etapa do funil</div>
          </div>
          <button onClick={onClose} className="btn-ghost p-2 flex-shrink-0"><X size={18}/></button>
        </div>

        {/* WA highlight */}
        {data?.whatsapp?.total > 0 && (
          <div className="mx-5 mt-4 flex-shrink-0 p-3 rounded-xl"
            style={{ background:'rgba(37,211,102,0.08)', border:'1px solid rgba(37,211,102,0.2)' }}>
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare size={14} style={{ color:'#1DAA5B' }} />
              <span className="text-sm font-bold text-ink">
                {fmt.numK(data.whatsapp.total)} vieram do WhatsApp
              </span>
              <span className="text-xs font-semibold" style={{ color:'#1DAA5B' }}>
                ({data.whatsapp.pctOfStep}% desta etapa)
              </span>
            </div>
            <div className="flex flex-wrap gap-4">
              {data.whatsapp.ctwa > 0 && (
                <div>
                  <div className="text-xs" style={{ color:'#6B7280' }}>CTWA</div>
                  <div className="text-sm font-bold text-ink">{fmt.numK(data.whatsapp.ctwa)}</div>
                </div>
              )}
              {data.whatsapp.firstReply > 0 && (
                <div>
                  <div className="text-xs" style={{ color:'#6B7280' }}>1ª resposta</div>
                  <div className="text-sm font-bold text-ink">{fmt.numK(data.whatsapp.firstReply)}</div>
                </div>
              )}
              {data.whatsapp.totalConn > 0 && (
                <div>
                  <div className="text-xs" style={{ color:'#6B7280' }}>Conexões</div>
                  <div className="text-sm font-bold text-ink">{fmt.numK(data.whatsapp.totalConn)}</div>
                </div>
              )}
              {waCampaigns.length > 0 && (
                <button onClick={() => setTab('whatsapp')}
                  className="text-xs flex items-center gap-1 ml-auto transition-colors"
                  style={{ color:'#1DAA5B' }}
                  onMouseEnter={e=>(e.currentTarget.style.color='#16A34A')}
                  onMouseLeave={e=>(e.currentTarget.style.color='#1DAA5B')}>
                  Ver {waCampaigns.length} criativos →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1.5 px-5 mt-4 flex-shrink-0 flex-wrap">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key as any)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all relative"
              style={{
                background: tab === t.key ? 'rgba(30,107,255,0.15)' : '#F7F8FA',
                border: `1px solid ${tab===t.key ? 'rgba(30,107,255,0.3)' : '#E6E8EC'}`,
                color: tab === t.key ? '#111827' : '#6B7280',
              }}>
              {t.key === 'whatsapp'
                ? <t.icon size={12} style={{ color: tab===t.key ? '#1DAA5B' : '#6B7280' }} />
                : <t.icon size={12} />
              }
              {t.label}
              {t.key === 'whatsapp' && waCampaigns.length > 0 && (
                <span className="ml-1 px-1.5 py-0.5 rounded-md text-xs font-bold"
                  style={{ background:'rgba(37,211,102,0.2)', color:'#1DAA5B', fontSize:10 }}>
                  {waCampaigns.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {loading && (
            <div className="flex items-center justify-center py-16 gap-3">
              <RefreshCw size={18} className="animate-spin" style={{ color:'#1E6BFF' }} />
              <span className="text-sm" style={{ color:'#4B5563' }}>Buscando dados da Meta API...</span>
            </div>
          )}
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-xl mb-4 text-xs"
              style={{ background:'rgba(220,38,38,0.08)', border:'1px solid rgba(220,38,38,0.2)', color:'#DC2626' }}>
              <AlertCircle size={13} className="flex-shrink-0 mt-0.5" /> {error} — exibindo dados demo.
            </div>
          )}

          {data && !loading && (
            <>
              {/* ── DATASETS ─────────────────────────────────────────────── */}
              {tab === 'actions' && (
                <div className="flex flex-col gap-3">
                  <div className="flex items-start gap-2 mb-1 p-2.5 rounded-xl"
                    style={{ background:'rgba(30,107,255,0.05)', border:'1px solid rgba(30,107,255,0.1)' }}>
                    <Info size={12} style={{ color:'#6B7280', flexShrink:0, marginTop:1 }} />
                    <span className="text-xs" style={{ color:'#6B7280' }}>
                      Cada dataset é um <code className="font-mono px-1 rounded" style={{ background:'#E6E8EC', color:'#4B5563' }}>action_type</code> contabilizado pela Meta.
                      Um evento pode aparecer em múltiplos datasets (omni, pixel, nativo).
                    </span>
                  </div>
                  {data.actionBreakdown.map((a: any) => (
                    <div key={a.type} className="card p-4"
                      style={a.isWhatsApp ? { border:'1px solid rgba(37,211,102,0.2)', background:'rgba(37,211,102,0.03)' } : {}}>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                            {a.isWhatsApp && <MessageSquare size={12} style={{ color:'#1DAA5B' }} />}
                            <span className="text-sm font-semibold text-ink">{a.label}</span>
                            {a.isWhatsApp && <span className="badge-green">WhatsApp</span>}
                          </div>
                          <code className="text-xs font-mono" style={{ color:'#6B7280' }}>{a.type}</code>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-lg font-bold text-ink">{fmt.numK(a.count)}</div>
                          {a.value > 0 && <div className="text-xs roas-high">{fmt.brl(a.value)}</div>}
                        </div>
                      </div>
                      <div className="h-1.5 rounded-full" style={{ background:'#E6E8EC' }}>
                        <div className="h-full rounded-full transition-all duration-700"
                          style={{
                            width: `${Math.max(2,(a.count/(data.stepTotal||1))*100)}%`,
                            background: a.isWhatsApp ? 'linear-gradient(90deg,#1DAA5B,#128C7E)' : 'linear-gradient(90deg,#1E6BFF,#0891B2)',
                          }} />
                      </div>
                      <div className="text-xs mt-1" style={{ color:'#6B7280' }}>
                        {data.stepTotal > 0 ? ((a.count/data.stepTotal)*100).toFixed(1) : 0}% do total desta etapa
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* ── PLATAFORMAS ───────────────────────────────────────────── */}
              {tab === 'placements' && (
                <div className="flex flex-col gap-3">
                  <p className="text-xs mb-1" style={{ color:'#6B7280' }}>
                    Distribuição por plataforma de publicação do anúncio.
                  </p>
                  {data.placements.map((p: any) => (
                    <div key={p.label} className="card p-4"
                      style={p.isWhatsApp ? { border:'1px solid rgba(37,211,102,0.2)', background:'rgba(37,211,102,0.03)' } : {}}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {p.isWhatsApp
                            ? <MessageSquare size={14} style={{ color:'#1DAA5B' }} />
                            : <Layers size={14} style={{ color:'#1E6BFF' }} />}
                          <span className="text-sm font-semibold text-ink">{p.label}</span>
                          {p.isWhatsApp && <span className="badge-green">WhatsApp</span>}
                        </div>
                        <span className="text-sm font-bold text-ink">{fmt.numK(p.impressions)}</span>
                      </div>
                      <div className="h-1.5 rounded-full mb-3" style={{ background:'#E6E8EC' }}>
                        <div className="h-full rounded-full"
                          style={{
                            width:`${Math.max(2,(p.impressions/maxPlacement)*100)}%`,
                            background: p.isWhatsApp ? 'linear-gradient(90deg,#1DAA5B,#128C7E)' : 'linear-gradient(90deg,#1E6BFF,#0891B2)',
                          }} />
                      </div>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          { label:'Cliques',   val: fmt.numK(p.clicks)  },
                          { label:'Investido', val: fmt.brlK(p.spend)   },
                          { label:'CTR',       val: fmt.pct(p.ctr)      },
                          { label:'CPM',       val: fmt.brl(p.cpm)      },
                        ].map(m => (
                          <div key={m.label}>
                            <div className="text-xs" style={{ color:'#6B7280' }}>{m.label}</div>
                            <div className="text-sm font-medium text-ink">{m.val}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* ── DISPOSITIVOS ─────────────────────────────────────────── */}
              {tab === 'devices' && (
                <div className="flex flex-col gap-3">
                  {data.devices.map((d: any) => {
                    const pct  = ((d.impressions / maxDevice) * 100).toFixed(1)
                    const Icon = DEVICE_ICONS[d.platform] || Smartphone
                    return (
                      <div key={d.platform} className="card p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                            style={{ background:'rgba(30,107,255,0.1)' }}>
                            <Icon size={16} style={{ color:'#1E6BFF' }} />
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-ink capitalize">
                              {DEVICE_LABELS[d.platform] || d.platform}
                            </div>
                            <div className="text-xs" style={{ color:'#6B7280' }}>{pct}% das impressões</div>
                          </div>
                        </div>
                        <div className="h-1.5 rounded-full mb-3" style={{ background:'#E6E8EC' }}>
                          <div className="h-full rounded-full"
                            style={{ width:`${pct}%`, background:'linear-gradient(90deg,#1E6BFF,#8B5CF6)' }} />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { label:'Impressões', val: fmt.numK(d.impressions) },
                            { label:'Cliques',    val: fmt.numK(d.clicks)      },
                            { label:'Investido',  val: fmt.brlK(d.spend)       },
                          ].map(m => (
                            <div key={m.label}>
                              <div className="text-xs" style={{ color:'#6B7280' }}>{m.label}</div>
                              <div className="text-sm font-medium text-ink">{m.val}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}

              {/* ── WHATSAPP CAMPAIGNS ────────────────────────────────────── */}
              {tab === 'whatsapp' && (
                <div className="flex flex-col gap-3">
                  {waCampaigns.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center rounded-2xl"
                      style={{ background:'rgba(37,211,102,0.04)', border:'1px dashed rgba(37,211,102,0.2)' }}>
                      <MessageSquare size={28} style={{ color:'#1DAA5B', opacity:0.5 }} className="mb-3" />
                      <div className="text-sm font-semibold text-ink mb-1">Sem dados de WhatsApp</div>
                      <p className="text-xs max-w-[220px]" style={{ color:'#6B7280' }}>
                        Nenhuma campanha com conversões de WhatsApp encontrada para este período.
                      </p>
                    </div>
                  ) : (
                    <>
                      {/* Summary bar */}
                      <div className="grid grid-cols-3 gap-2 mb-1">
                        {[
                          { label:'Total WA',    val: fmt.numK(data.whatsapp.total),     icon: MessageSquare, color:'#1DAA5B' },
                          { label:'CTWA',        val: fmt.numK(data.whatsapp.ctwa),      icon: TrendingUp,    color:'#1E6BFF' },
                          { label:'CPL Médio',   val: waCampaigns.length > 0 ? fmt.brl(waCampaigns.reduce((s:number,c:any)=>s+c.cpl,0)/waCampaigns.length) : '—', icon: DollarSign, color:'#D97706' },
                        ].map(m => (
                          <div key={m.label} className="card p-3">
                            <div className="text-xs mb-1" style={{ color:'#6B7280' }}>{m.label}</div>
                            <div className="font-bold text-ink">{m.val}</div>
                          </div>
                        ))}
                      </div>

                      <p className="text-xs mb-1" style={{ color:'#6B7280' }}>
                        Campanhas e criativos ordenados por conversões WhatsApp. Dados por anúncio (ad level).
                      </p>

                      {waCampaigns.map((c: any, i: number) => (
                        <div key={`${c.ad_id}-${i}`} className="card p-4"
                          style={{ border:'1px solid rgba(37,211,102,0.15)' }}>
                          {/* Names */}
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className="flex-1 min-w-0">
                              <div className="text-xs mb-0.5 truncate" style={{ color:'#6B7280' }}>
                                {c.campaign_name}
                                {c.adset_name && <span style={{ color:'#9CA3AF' }}> › {c.adset_name}</span>}
                              </div>
                              <div className="text-sm font-semibold text-ink truncate">{c.ad_name}</div>
                            </div>
                            <div className="flex flex-col items-end flex-shrink-0">
                              <div className="flex items-center gap-1.5">
                                <MessageSquare size={12} style={{ color:'#1DAA5B' }} />
                                <span className="font-bold text-ink text-lg leading-none">{fmt.numK(c.waConvs)}</span>
                              </div>
                              <div className="text-xs mt-0.5" style={{ color:'#1DAA5B' }}>conversões WA</div>
                            </div>
                          </div>

                          {/* Metrics grid */}
                          <div className="grid grid-cols-3 gap-2 mb-3">
                            {[
                              { label:'CTWA',        val: fmt.numK(c.ctwa)      },
                              { label:'1ª Resposta', val: fmt.numK(c.firstReply)},
                              { label:'CPL WA',      val: fmt.brl(c.cpl)        },
                              { label:'Investido',   val: fmt.brl(c.spend)      },
                              { label:'Impressões',  val: fmt.numK(c.impressions)},
                              { label:'Cliques',     val: fmt.numK(c.clicks)    },
                            ].map(m => (
                              <div key={m.label}>
                                <div className="text-xs" style={{ color:'#6B7280' }}>{m.label}</div>
                                <div className="text-sm font-medium text-ink">{m.val}</div>
                              </div>
                            ))}
                          </div>

                          {/* WA conversion bar */}
                          <div className="h-1.5 rounded-full mb-3" style={{ background:'#E6E8EC' }}>
                            <div className="h-full rounded-full"
                              style={{
                                width:`${Math.max(2,(c.waConvs/Math.max(...waCampaigns.map((x:any)=>x.waConvs),1))*100)}%`,
                                background:'linear-gradient(90deg,#1DAA5B,#128C7E)',
                              }} />
                          </div>

                          {/* Creative links */}
                          <div className="flex items-center gap-2 flex-wrap">
                            {c.permalink ? (
                              <a href={c.permalink} target="_blank" rel="noreferrer"
                                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all font-medium"
                                style={{ background:'rgba(24,119,242,0.12)', color:'#1877F2', border:'1px solid rgba(24,119,242,0.2)' }}
                                onMouseEnter={e=>(e.currentTarget.style.background='rgba(24,119,242,0.2)')}
                                onMouseLeave={e=>(e.currentTarget.style.background='rgba(24,119,242,0.12)')}>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                                Ver post no Facebook
                              </a>
                            ) : (
                              <span className="text-xs px-3 py-1.5 rounded-lg" style={{ background:'rgba(90,96,128,0.1)', color:'#6B7280' }}>
                                Link do post não disponível
                              </span>
                            )}
                            <a href={`https://www.facebook.com/ads/library/?q=${encodeURIComponent(c.ad_name || '')}`}
                              target="_blank" rel="noreferrer"
                              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all font-medium"
                              style={{ background:'rgba(30,107,255,0.1)', color:'#1E6BFF', border:'1px solid rgba(30,107,255,0.15)' }}
                              onMouseEnter={e=>(e.currentTarget.style.background='rgba(30,107,255,0.2)')}
                              onMouseLeave={e=>(e.currentTarget.style.background='rgba(30,107,255,0.1)')}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                              Biblioteca de Anúncios
                            </a>
                          </div>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  )
}
