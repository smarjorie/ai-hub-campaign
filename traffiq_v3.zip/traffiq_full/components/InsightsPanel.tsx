import { insights } from '@/lib/mockData'
import { Lightbulb, AlertTriangle, TrendingUp, Info, ArrowRight } from 'lucide-react'

const TYPE_CONFIG = {
  opportunity: { icon: TrendingUp, color: '#16A34A', bg: 'rgba(22,163,74,0.1)', border: 'rgba(22,163,74,0.2)', badge: 'badge-green', label: 'Oportunidade' },
  warning:     { icon: AlertTriangle, color: '#D97706', bg: 'rgba(217,119,6,0.1)', border: 'rgba(217,119,6,0.2)', badge: 'badge-yellow', label: 'Atenção' },
  alert:       { icon: AlertTriangle, color: '#DC2626', bg: 'rgba(220,38,38,0.1)', border: 'rgba(220,38,38,0.2)', badge: 'badge-red', label: 'Alerta' },
  info:        { icon: Info, color: '#0891B2', bg: 'rgba(8,145,178,0.1)', border: 'rgba(8,145,178,0.2)', badge: 'badge-cyan', label: 'Info' },
}
const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 }
const PLATFORM_BADGE: Record<string, string> = { meta: 'badge-meta', google: 'badge-google', tiktok: 'badge-tiktok' }

export default function InsightsPanel() {
  const sorted = [...insights].sort((a, b) => PRIORITY_ORDER[a.priority as keyof typeof PRIORITY_ORDER] - PRIORITY_ORDER[b.priority as keyof typeof PRIORITY_ORDER])

  return (
    <div className="flex flex-col gap-3">
      {sorted.map(insight => {
        const cfg = TYPE_CONFIG[insight.type as keyof typeof TYPE_CONFIG]
        const Icon = cfg.icon
        return (
          <div key={insight.id} className="card-hover p-4" style={{ borderLeft: `3px solid ${cfg.color}` }}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>
                <Icon size={16} style={{ color: cfg.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                  <span className={cfg.badge}>{cfg.label}</span>
                  <span className={PLATFORM_BADGE[insight.platform]}>{insight.platform}</span>
                  {insight.priority === 'high' && <span className="badge-red">Alta prioridade</span>}
                </div>
                <div className="text-sm font-semibold text-ink mb-1 break-words">{insight.title}</div>
                <div className="text-xs mb-2 break-words" style={{ color: '#4B5563' }}>{insight.description}</div>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-1.5">
                    <TrendingUp size={11} style={{ color: '#16A34A' }} />
                    <span className="text-xs font-medium" style={{ color: '#16A34A' }}>{insight.impact}</span>
                  </div>
                  <button className="flex items-center gap-1 text-xs font-medium transition-colors"
                    style={{ color: '#1E6BFF' }}
                    onMouseEnter={e => (e.currentTarget.style.color = '#3D8BFF')}
                    onMouseLeave={e => (e.currentTarget.style.color = '#1E6BFF')}>
                    {insight.action} <ArrowRight size={11} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
