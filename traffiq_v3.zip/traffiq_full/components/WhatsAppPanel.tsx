import { useState } from 'react'
import { MessageSquare, Send, Users, TrendingUp, Phone, Search, MoreVertical, CheckCheck } from 'lucide-react'
import { fmt } from '@/lib/format'

const conversations = [
  { id: '1', name: 'Ana Lima', phone: '+55 11 9xxxx-1234', lastMsg: 'Gostei muito! Posso parcelar no cartão?', time: '14:32', unread: 2, status: 'lead', campaign: 'PROS — Escala' },
  { id: '2', name: 'Carlos Mendes', phone: '+55 21 9xxxx-5678', lastMsg: 'Já recebi o produto! Top demais 🔥', time: '13:18', unread: 0, status: 'customer', campaign: 'RETARGETING' },
  { id: '3', name: 'Fernanda Costa', phone: '+55 31 9xxxx-9012', lastMsg: 'Qual o prazo de entrega para BH?', time: '12:55', unread: 1, status: 'lead', campaign: 'PROS — Escala' },
  { id: '4', name: 'Rafael Souza', phone: '+55 51 9xxxx-3456', lastMsg: 'Obrigado pelo atendimento!', time: '11:40', unread: 0, status: 'customer', campaign: 'Google Search' },
  { id: '5', name: 'Juliana Martins', phone: '+55 85 9xxxx-7890', lastMsg: 'Qual o link para pagar?', time: '10:22', unread: 3, status: 'hot', campaign: 'PROS — Escala' },
]

const msgsByConv: Record<string, { role: 'user'|'bot'; text: string; time: string }[]> = {
  '1': [
    { role: 'bot', text: 'Olá Ana! Vi que você clicou no nosso anúncio 😊 Posso te ajudar?', time: '14:28' },
    { role: 'user', text: 'Oi! Sim, fiquei interessada no produto. Tem disponível?', time: '14:30' },
    { role: 'bot', text: 'Temos sim! E ainda com 30% de desconto para compras hoje 🎉 Quer que eu te envie mais detalhes?', time: '14:31' },
    { role: 'user', text: 'Gostei muito! Posso parcelar no cartão?', time: '14:32' },
  ],
  '5': [
    { role: 'user', text: 'Oi! Quero comprar, como faço?', time: '10:20' },
    { role: 'bot', text: 'Oi Juliana! Que ótimo! Posso te enviar o link de pagamento direto aqui no WhatsApp 🛒', time: '10:21' },
    { role: 'user', text: 'Qual o link para pagar?', time: '10:22' },
  ],
}

const STATUS_CONFIG = {
  lead:     { label: 'Lead',     color: '#1E6BFF', bg: 'rgba(30,107,255,0.15)' },
  hot:      { label: '🔥 Quente', color: '#DC2626', bg: 'rgba(220,38,38,0.15)' },
  customer: { label: 'Cliente',  color: '#16A34A', bg: 'rgba(22,163,74,0.15)' },
}

export default function WhatsAppPanel() {
  const [selected, setSelected] = useState('1')
  const [draft, setDraft] = useState('')
  const conv = conversations.find(c => c.id === selected)
  const msgs = msgsByConv[selected] || [{ role: 'bot' as const, text: 'Conversa carregada. Aguardando mensagens...', time: '—' }]

  const kpis = [
    { label: 'Conversas Ativas', value: '47', change: 12 },
    { label: 'Taxa de Resposta', value: '94%', change: 3 },
    { label: 'Conv. em Vendas', value: '23%', change: 8 },
    { label: 'Ticket Médio', value: 'R$ 312', change: -2 },
  ]

  return (
    <div className="flex flex-col gap-5">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpis.map(k => (
          <div key={k.label} className="card p-3">
            <div className="metric-label mb-1">{k.label}</div>
            <div className="text-xl font-bold text-ink">{k.value}</div>
            <div className={k.change >= 0 ? 'metric-up text-xs' : 'metric-down text-xs'}>{k.change > 0 ? '+' : ''}{k.change}%</div>
          </div>
        ))}
      </div>

      {/* Chat UI */}
      <div className="card overflow-hidden" style={{ height: 520 }}>
        <div className="flex h-full">
          {/* Sidebar list */}
          <div className="w-64 flex-shrink-0 flex flex-col border-r" style={{ borderColor: '#E6E8EC' }}>
            <div className="p-3 border-b" style={{ borderColor: '#E6E8EC' }}>
              <div className="relative">
                <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: '#6B7280' }} />
                <input className="input-field text-xs py-1.5 pl-8" placeholder="Buscar conversa..." />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {conversations.map(c => {
                const st = STATUS_CONFIG[c.status as keyof typeof STATUS_CONFIG]
                return (
                  <button key={c.id} onClick={() => setSelected(c.id)}
                    className="w-full p-3 flex items-start gap-2.5 text-left transition-all border-b"
                    style={{ borderColor: '#E6E8EC', background: selected === c.id ? 'rgba(30,107,255,0.1)' : 'transparent' }}>
                    <div className="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-sm"
                      style={{ background: '#E6E8EC', color: '#1E6BFF' }}>
                      {c.name[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-ink truncate">{c.name}</span>
                        <span className="text-xs flex-shrink-0 ml-1" style={{ color: '#6B7280' }}>{c.time}</span>
                      </div>
                      <div className="text-xs truncate mb-1" style={{ color: '#6B7280' }}>{c.lastMsg}</div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs px-1.5 py-0.5 rounded-md font-medium" style={{ background: st.bg, color: st.color }}>{st.label}</span>
                        {c.unread > 0 && <span className="w-4 h-4 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: '#1DAA5B' }}>{c.unread}</span>}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Chat area */}
          <div className="flex-1 flex flex-col">
            {/* Header */}
            {conv && (
              <div className="p-3 border-b flex items-center gap-3" style={{ borderColor: '#E6E8EC' }}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold" style={{ background: '#E6E8EC', color: '#1DAA5B' }}>
                  {conv.name[0]}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-ink text-sm">{conv.name}</div>
                  <div className="text-xs flex items-center gap-2" style={{ color: '#6B7280' }}>
                    <Phone size={10} /> {conv.phone}
                    <span>·</span>
                    <span style={{ color: '#1E6BFF' }}>📢 {conv.campaign}</span>
                  </div>
                </div>
                <button className="btn-ghost p-1.5"><MoreVertical size={14} /></button>
              </div>
            )}

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {msgs.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className="max-w-[72%] px-3 py-2 rounded-xl text-sm"
                    style={{
                      background: m.role === 'user' ? '#1DAA5B' : '#F1F3F6',
                      color: m.role === 'user' ? '#000' : '#111827',
                      borderRadius: m.role === 'user' ? '14px 14px 2px 14px' : '14px 14px 14px 2px',
                    }}>
                    <div>{m.text}</div>
                    <div className="flex items-center gap-1 mt-1 justify-end">
                      <span className="text-xs opacity-60">{m.time}</span>
                      {m.role === 'bot' && <CheckCheck size={11} style={{ opacity: 0.6 }} />}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="p-3 border-t flex items-center gap-2" style={{ borderColor: '#E6E8EC' }}>
              <input
                className="input-field flex-1 text-sm"
                placeholder="Escreva uma mensagem..."
                value={draft}
                onChange={e => setDraft(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && draft.trim()) setDraft('') }}
              />
              <button className="btn-primary py-2 px-3" onClick={() => setDraft('')}>
                <Send size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
