import { useState, useMemo } from 'react'
import {
  MessageSquare, TrendingUp, DollarSign, Send, BarChart2,
  Calendar, ChevronDown, ArrowRight, X,
  CheckCircle2, AlertCircle, XCircle, Database,
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell,
} from 'recharts'
import {
  genBspFunnel, genBspTimeline, bspChannels, bspSummary,
  bspDemographics, bspEntryPoints, BspFunnelStep,
} from '@/lib/mockBspData'
import { fmt } from '@/lib/format'

// ── Step → data source mapping ────────────────────────────────────────────────
const STEP_SOURCES: Record<string, { source: string; type: string; description: string; fields: string[] }> = {
  'Sessão iniciada':      { source:'BSP / Chatbot',        type:'Evento de entrada',       description:'Disparado quando o usuário envia a primeira mensagem ou clica no link de abertura do fluxo conversacional.', fields:['session_id','phone_hash','timestamp','entry_point','channel'] },
  'CPF informado':        { source:'BSP / Chatbot',        type:'Input do usuário',        description:'Capturado quando o usuário digita o CPF no fluxo. O BSP valida o formato antes de registrar.',             fields:['cpf_hash','session_id','validated_at','format_valid'] },
  'E-mail informado':     { source:'BSP / Chatbot',        type:'Input do usuário',        description:'Capturado após o CPF. Campo opcional em alguns fluxos.',                                                     fields:['email_hash','session_id','captured_at'] },
  'Consulta autorizada':  { source:'API de Elegibilidade', type:'Resposta de API externa', description:'Retorno da API de bureau/elegibilidade após envio do CPF. Registra que o usuário autorizou a consulta.',     fields:['cpf_hash','auth_token','consulted_at','bureau_code'] },
  'Sucesso Consulta':     { source:'API de Elegibilidade', type:'Resposta de API externa', description:'API retornou dados válidos. Confirma que a consulta teve retorno positivo.',                                  fields:['cpf_hash','eligibility_score','products_found','consulted_at'] },
  'Oferta realizada':     { source:'Motor de Ofertas',     type:'Decisão do sistema',      description:'Sistema de decisão gerou ao menos uma oferta de crédito com base no perfil retornado.',                      fields:['cpf_hash','offer_id','product_type','value_range','rate'] },
  'Oferta aceita':        { source:'BSP / Chatbot',        type:'Interação do usuário',    description:'Usuário clicou/respondeu aceitando a oferta apresentada no fluxo.',                                         fields:['offer_id','session_id','accepted_at','product_type'] },
  'CEP coletado':         { source:'BSP / Chatbot',        type:'Input do usuário',        description:'CEP informado pelo usuário após aceitar a oferta, para validação de endereço.',                             fields:['cep','session_id','captured_at'] },
  'Endereço informado':   { source:'API de CEP / BSP',     type:'Input + validação',       description:'Endereço completo confirmado pelo usuário ou preenchido via API de CEP.',                                   fields:['address_hash','cep','city','state','session_id'] },
  'Banco informado':      { source:'BSP / Chatbot',        type:'Input do usuário',        description:'Usuário informou o banco de preferência para recebimento do crédito.',                                      fields:['bank_code','bank_name','session_id','captured_at'] },
  'Banco validado':       { source:'API Bancária',         type:'Resposta de API externa', description:'Banco informado foi validado pela API bancária como disponível para o produto.',                             fields:['bank_code','validated_at','status','session_id'] },
  'Proposta criada':      { source:'Sistema de Propostas', type:'Evento de backend',       description:'Proposta formal criada no sistema legado após validação de todos os dados do usuário.',                      fields:['proposal_id','cpf_hash','product_id','value','rate','session_id'] },
  'Biometria solicitada': { source:'API de Biometria',     type:'Chamada de API externa',  description:'Solicitação de biometria facial/liveness enviada ao provedor externo.',                                     fields:['proposal_id','biometry_request_id','requested_at','provider'] },
  'Biometria aprovada':   { source:'API de Biometria',     type:'Resposta de API externa', description:'Provedor de biometria retornou aprovação após validação da identidade.',                                     fields:['proposal_id','biometry_id','approved_at','score','provider'] },
  'Proposta aprovada':    { source:'Sistema de Crédito',   type:'Decisão do sistema',      description:'Proposta passou pela análise final de crédito e foi aprovada.',                                             fields:['proposal_id','approved_at','final_value','final_rate','expiry_date'] },
}

const SOURCE_COLORS: Record<string, string> = {
  'BSP / Chatbot':        '#1DAA5B',
  'API de Elegibilidade': '#1E6BFF',
  'Motor de Ofertas':     '#8B5CF6',
  'API de CEP / BSP':     '#1DAA5B',
  'API Bancária':         '#0891B2',
  'Sistema de Propostas': '#D97706',
  'API de Biometria':     '#EC4899',
  'Sistema de Crédito':   '#10B981',
}

type BspTab = 'overview' | 'conversao' | 'demograficos' | 'canais' | 'entrypoints'
const TABS: { id: BspTab; label: string }[] = [
  { id:'overview',     label:'Dados gerais'         },
  { id:'conversao',    label:'Detalhe de conversão' },
  { id:'demograficos', label:'Dados demográficos'   },
  { id:'canais',       label:'Performance por canal'},
  { id:'entrypoints',  label:'Entry Points'         },
]

const GENDER_COLORS = ['#A855F7','#1E6BFF','#6B7280']
const AGE_COLORS    = ['#1E6BFF','#3D8BFF','#0891B2','#0891B2','#0E7490','#1DAA5B']

// ── KPI Card ──────────────────────────────────────────────────────────────────
function KpiCard({ label, value, change, icon: Icon, color = '#1DAA5B', sub }: {
  label:string; value:string; change?:number; icon:any; color?:string; sub?:string
}) {
  return (
    <div className="card-hover p-4">
      <div className="flex items-start justify-between mb-3">
        <span className="metric-label">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background:`${color}18`, border:`1px solid ${color}25` }}>
          <Icon size={14} style={{ color }} />
        </div>
      </div>
      <div className="metric-value">{value}</div>
      {sub && <div className="text-xs mt-0.5" style={{ color:'#6B7280' }}>{sub}</div>}
      {change !== undefined && (
        <div className={`text-xs mt-1 font-semibold ${change >= 0 ? 'metric-up' : 'metric-down'}`}>
          {change > 0 ? '+' : ''}{Math.abs(change) < 200 ? `${change}%` : fmt.numK(change)} vs período anterior
        </div>
      )}
    </div>
  )
}

// ── Badge ─────────────────────────────────────────────────────────────────────
function Badge({ value, thresholds }: { value: number; thresholds: [number,number] }) {
  const color = value >= thresholds[1] ? '#16A34A' : value >= thresholds[0] ? '#D97706' : '#DC2626'
  const bg    = value >= thresholds[1] ? 'rgba(22,163,74,0.12)' : value >= thresholds[0] ? 'rgba(217,119,6,0.12)' : 'rgba(220,38,38,0.12)'
  const bd    = value >= thresholds[1] ? 'rgba(22,163,74,0.2)' : value >= thresholds[0] ? 'rgba(217,119,6,0.2)' : 'rgba(220,38,38,0.2)'
  return (
    <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-md text-xs font-bold min-w-[52px]"
      style={{ background:bg, color, border:`1px solid ${bd}` }}>
      {value.toFixed(1)}%
    </span>
  )
}

// ── Funnel bar (horizontal, dark) ─────────────────────────────────────────────
function FunnelBar({ steps, onSelect, selected }: { steps:BspFunnelStep[]; onSelect?:(s:BspFunnelStep)=>void; selected?:string }) {
  const max = steps[0]?.value || 1
  return (
    <div className="flex flex-col gap-1">
      {steps.map((step, i) => {
        const pct    = (step.value / max) * 100
        const active = selected === step.label
        const health = i === 0 ? 'ok' : step.pct >= 80 ? 'ok' : step.pct >= 50 ? 'warn' : 'bad'
        const barColor = { ok:'#1DAA5B', warn:'#D97706', bad:'#DC2626' }[health]

        return (
          <button key={step.label} onClick={() => onSelect?.(step)}
            className="flex items-center gap-3 w-full text-left rounded-xl px-2 py-1 transition-all border border-transparent"
            style={{
              background: active ? 'rgba(37,211,102,0.08)' : 'transparent',
              borderColor: active ? 'rgba(37,211,102,0.2)' : 'transparent',
              cursor: onSelect ? 'pointer' : 'default',
            }}>
            {/* Label */}
            <div className="flex-shrink-0 text-right" style={{ width:172 }}>
              <span className="text-xs" style={{ color: active ? '#111827' : '#4B5563', fontWeight: active ? 600 : 400 }}>
                {step.label}
              </span>
            </div>
            {/* Bar */}
            <div className="flex-1 h-[22px] rounded-md overflow-hidden relative" style={{ background:'#E6E8EC' }}>
              <div style={{
                width:`${Math.max(3, pct)}%`, height:'100%',
                background: active ? '#1DAA5B' : barColor,
                borderRadius:6, display:'flex', alignItems:'center', justifyContent:'flex-end',
                paddingRight:6, transition:'width 0.6s ease',
                opacity: active ? 1 : 0.8,
              }}>
                {pct > 18 && (
                  <span style={{ fontSize:10, fontWeight:700, color:'#fff' }}>
                    {i === 0 ? '100%' : `${step.pct}%`}
                  </span>
                )}
              </div>
              {pct <= 18 && (
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold" style={{ color:'#6B7280', fontSize:10 }}>
                  {i === 0 ? '100%' : `${step.pct}%`}
                </span>
              )}
            </div>
            {/* Value */}
            <div className="flex-shrink-0 text-right text-xs font-semibold" style={{ width:52, color: active ? '#1DAA5B' : '#374151' }}>
              {fmt.numK(step.value)}
            </div>
          </button>
        )
      })}
    </div>
  )
}

// ── Step detail panel ─────────────────────────────────────────────────────────
function StepDetail({ step, onClose }: { step:BspFunnelStep; onClose:()=>void }) {
  const src     = STEP_SOURCES[step.label]
  const health  = step.pct >= 80 ? 'ok' : step.pct >= 50 ? 'warn' : 'bad'
  const srcColor= src ? (SOURCE_COLORS[src.source] || '#1DAA5B') : '#1DAA5B'

  return (
    <div className="card p-5 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full" style={{ background:'#1DAA5B' }} />
          <span className="font-bold text-ink text-base">{step.label}</span>
          <span className="badge-green">{fmt.numK(step.value)}</span>
        </div>
        <button onClick={onClose} className="btn-ghost p-1.5"><X size={15} /></button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label:'Total desta etapa',   value: fmt.numK(step.value),               color: undefined },
          { label:'% etapa anterior',    value: `${step.pct}%`,                     color: step.pct >= 80 ? '#16A34A' : step.pct >= 50 ? '#D97706' : '#DC2626' },
          { label:'% da sessão inicial', value: `${step.absolute}%`,               color: undefined },
          { label:'Drop-off',            value: `${(100-step.pct).toFixed(1)}%`,   color: step.pct < 80 ? '#DC2626' : '#16A34A' },
        ].map(m => (
          <div key={m.label} className="p-3 rounded-xl" style={{ background:'#F7F8FA', border:'1px solid #E6E8EC' }}>
            <div className="text-xs mb-1" style={{ color:'#6B7280' }}>{m.label}</div>
            <div className="text-xl font-black" style={{ color: m.color || '#111827' }}>{m.value}</div>
          </div>
        ))}
      </div>

      {/* Health indicator */}
      <div className="flex items-center gap-2 p-3 rounded-xl text-xs"
        style={{
          background: health==='ok' ? 'rgba(22,163,74,0.08)' : health==='warn' ? 'rgba(217,119,6,0.08)' : 'rgba(220,38,38,0.08)',
          border: `1px solid ${health==='ok' ? 'rgba(22,163,74,0.2)' : health==='warn' ? 'rgba(217,119,6,0.2)' : 'rgba(220,38,38,0.2)'}`,
          color: health==='ok' ? '#16A34A' : health==='warn' ? '#D97706' : '#DC2626',
        }}>
        {health==='ok'
          ? <CheckCircle2 size={13} className="flex-shrink-0" />
          : health==='warn'
          ? <AlertCircle  size={13} className="flex-shrink-0" />
          : <XCircle      size={13} className="flex-shrink-0" />}
        <span style={{ color:'#4B5563' }}>
          {health==='ok'
            ? 'Alta taxa de continuidade. Etapa saudável.'
            : health==='warn'
            ? 'Drop-off moderado. Analise possíveis fricções nesta etapa.'
            : 'Drop-off crítico — etapa com maior fricção no funil.'}
        </span>
      </div>

      {/* Data source */}
      {src ? (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Database size={13} style={{ color:'#6B7280' }} />
            <span className="text-xs font-bold uppercase tracking-wider" style={{ color:'#6B7280' }}>Origem do dado</span>
          </div>
          <div className="p-4 rounded-xl" style={{ background:`${srcColor}08`, border:`1px solid ${srcColor}25` }}>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-xs font-bold px-2 py-0.5 rounded-md"
                style={{ background:`${srcColor}18`, color:srcColor }}>
                {src.type}
              </span>
              <span className="text-sm font-bold text-ink">{src.source}</span>
            </div>
            <p className="text-xs mb-3 leading-relaxed" style={{ color:'#4B5563' }}>{src.description}</p>
            <div>
              <div className="text-xs mb-2 font-semibold" style={{ color:'#6B7280' }}>Campos do evento:</div>
              <div className="flex flex-wrap gap-1.5">
                {src.fields.map(f => (
                  <code key={f} className="text-xs px-2 py-0.5 rounded-md font-mono"
                    style={{ background:'#F7F8FA', color:'#4B5563', border:'1px solid #E6E8EC' }}>
                    {f}
                  </code>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-xs text-center py-4" style={{ color:'#6B7280' }}>
          Sem mapeamento de fonte disponível para esta etapa.
        </div>
      )}
    </div>
  )
}

// ── Channel table ─────────────────────────────────────────────────────────────
function ChannelTable({ channels }: { channels: typeof bspChannels }) {
  const [sortKey,  setSortKey]  = useState('conversoes')
  const [sortDesc, setSortDesc] = useState(true)

  const sorted = [...channels].sort((a: any, b: any) =>
    sortDesc ? b[sortKey] - a[sortKey] : a[sortKey] - b[sortKey]
  )

  function Th({ label, k, right }: { label:string; k:string; right?:boolean }) {
    return (
      <th className={`whitespace-nowrap cursor-pointer select-none ${right?'text-right':''}`}
        onClick={() => { if(k===sortKey) setSortDesc(!sortDesc); else { setSortKey(k); setSortDesc(true) } }}>
        <div className={`flex items-center gap-1 ${right?'justify-end':''}`}>
          <span>{label}</span>
          <span style={{ color: k===sortKey ? '#1E6BFF' : '#9CA3AF', fontSize:10 }}>{k===sortKey?(sortDesc?'↓':'↑'):'↕'}</span>
        </div>
      </th>
    )
  }

  return (
    <div className="overflow-x-auto">
      <table className="data-table">
        <thead>
          <tr>
            <Th label="Tracking"        k="tracking"      />
            <Th label="Source"          k="source"        />
            <Th label="% Engaj."        k="engajamento"   right />
            <Th label="% Elegib."       k="elegibilidade" right />
            <Th label="% Conv. Eleg."   k="convElegivel"  right />
            <Th label="Ticket Médio"    k="ticketMedio"   right />
            <Th label="Taxa Mensal"     k="taxaMensal"    right />
            <Th label="Disparos"        k="disparos"      right />
            <Th label="Sessões"         k="sessoes"       right />
            <Th label="Conversões"      k="conversoes"    right />
          </tr>
        </thead>
        <tbody>
          {sorted.map(ch => (
            <tr key={ch.tracking}>
              <td>
                <div className="flex items-center gap-2">
                  <MessageSquare size={11} style={{ color:'#1DAA5B', flexShrink:0 }} />
                  <span className="text-ink font-medium text-xs">{ch.tracking}</span>
                </div>
              </td>
              <td>
                <span className="text-xs px-2 py-0.5 rounded-md font-medium"
                  style={{
                    background: ch.source==='Orgânico' ? 'rgba(22,163,74,0.1)' : 'rgba(30,107,255,0.1)',
                    color:      ch.source==='Orgânico' ? '#16A34A'              : '#1E6BFF',
                  }}>
                  {ch.source}
                </span>
              </td>
              <td className="text-right">
                {ch.engajamento > 0 ? <Badge value={ch.engajamento} thresholds={[20,40]} />
                  : <span style={{ color:'#6B7280' }}>—</span>}
              </td>
              <td className="text-right"><Badge value={ch.elegibilidade} thresholds={[10,30]} /></td>
              <td className="text-right"><Badge value={ch.convElegivel}  thresholds={[10,20]} /></td>
              <td className="text-right"><span className="text-sm font-semibold text-ink">{fmt.brl(ch.ticketMedio)}</span></td>
              <td className="text-right"><span className="text-sm" style={{ color:'#4B5563' }}>{ch.taxaMensal.toFixed(2)}%</span></td>
              <td className="text-right"><span className="text-sm" style={{ color:'#4B5563' }}>{fmt.numK(ch.disparos)}</span></td>
              <td className="text-right"><span className="text-sm" style={{ color:'#4B5563' }}>{fmt.numK(ch.sessoes)}</span></td>
              <td className="text-right"><span className="text-sm font-bold text-ink">{fmt.numK(ch.conversoes)}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── Tooltip ───────────────────────────────────────────────────────────────────
const ChartTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-3 min-w-[130px]">
      <div className="text-xs mb-2" style={{ color:'#4B5563' }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color||p.fill }} />
            <span className="text-xs" style={{ color:'#4B5563' }}>{p.name}</span>
          </div>
          <span className="text-sm font-semibold text-ink">{fmt.numK(p.value)}</span>
        </div>
      ))}
    </div>
  )
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function BspDashboard() {
  const [tab,          setTab]          = useState<BspTab>('overview')
  const [selectedStep, setSelectedStep] = useState<BspFunnelStep|null>(null)
  const [period,       setPeriod]       = useState('Últimos 30 dias')
  const [showPeriod,   setShowPeriod]   = useState(false)
  const [originFilter, setOriginFilter] = useState('Todos')

  const funnel   = useMemo(() => genBspFunnel(),   [])
  const timeline = useMemo(() => genBspTimeline(), [])

  const PERIODS = ['Hoje','Ontem','Últimos 7 dias','Últimos 30 dias','Este mês','Mês anterior']
  const origins = ['Todos', ...Array.from(new Set(bspChannels.map(c => c.source)))]
  const filteredChannels = originFilter==='Todos' ? bspChannels : bspChannels.filter(c=>c.source===originFilter)

  return (
    <div className="flex flex-col gap-5">

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-ink">WhatsApp CRM</h1>
          <p className="text-sm mt-0.5" style={{ color:'#6B7280' }}>Funil de conversão e performance dos disparos BSP · {period}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <select value={originFilter} onChange={e=>setOriginFilter(e.target.value)}
              className="input-field text-sm py-1.5 pr-8 appearance-none cursor-pointer" style={{ minWidth:140 }}>
              {origins.map(o=><option key={o} value={o}>{o}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color:'#6B7280' }} />
          </div>
          <div className="relative">
            <button onClick={()=>setShowPeriod(!showPeriod)}
              className="btn-secondary text-sm py-1.5 flex items-center gap-1.5">
              <Calendar size={12}/>{period}<ChevronDown size={12}/>
            </button>
            {showPeriod && (
              <div className="absolute top-full right-0 mt-1 card py-1 z-50 w-44">
                {PERIODS.map(p=>(
                  <button key={p} onClick={()=>{setPeriod(p);setShowPeriod(false)}}
                    className="w-full text-left px-3 py-2 text-sm transition-colors"
                    style={{ color:p===period?'#1DAA5B':'#4B5563', background:p===period?'rgba(37,211,102,0.08)':'transparent' }}>
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>
          <span className="badge-yellow">Demo</span>
        </div>
      </div>

      {/* ── Tab bar ─────────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-0 border-b flex-wrap" style={{ borderColor:'#E6E8EC' }}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)}
            className="px-4 py-2.5 text-sm font-medium transition-all relative whitespace-nowrap"
            style={{ color: tab===t.id ? '#1DAA5B' : '#6B7280' }}>
            {t.label}
            {tab===t.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background:'#1DAA5B' }} />}
          </button>
        ))}
      </div>

      {/* ══ DADOS GERAIS ══════════════════════════════════════════════════════ */}
      {tab==='overview' && (
        <div className="flex flex-col gap-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <KpiCard label="Disparos enviados"   value={fmt.numK(bspSummary.disparos)}           change={29462} icon={Send}          color="#1E6BFF" />
            <KpiCard label="Sessões iniciadas"   value={fmt.numK(bspSummary.sessoes)}            change={-2}    icon={MessageSquare}  color="#1DAA5B" />
            <KpiCard label="Valor desembolsado"  value={`R$ ${fmt.numK(bspSummary.valorTotal)}`} change={-63}   icon={DollarSign}     color="#8B5CF6" />
            <KpiCard label="Ticket médio"        value={fmt.brl(bspSummary.ticketMedio)}         change={20}    icon={TrendingUp}     color="#D97706" />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
            {/* Donut conversão */}
            <div className="card p-5">
              <div className="section-title mb-1">Conversão de elegíveis</div>
              <div className="text-xs mb-4" style={{ color:'#6B7280' }}>% usuários convertidos</div>
              <div className="flex flex-col items-center">
                <div className="relative">
                  <PieChart width={160} height={160}>
                    <Pie data={[{value:bspSummary.conversao},{value:100-bspSummary.conversao}]}
                      dataKey="value" cx="50%" cy="50%" innerRadius={52} outerRadius={72} strokeWidth={0}>
                      <Cell fill="#1DAA5B"/><Cell fill="#E6E8EC"/>
                    </Pie>
                  </PieChart>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-black text-ink">{bspSummary.conversao}%</span>
                    <span className="text-xs" style={{ color:'#6B7280' }}>-69% ant.</span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 w-full mt-3">
                  {[
                    { label:'Únicos',       val: fmt.numK(bspSummary.usuariosUnicos) },
                    { label:'Elegibilidade',val: `${bspSummary.elegibilidade}%`       },
                    { label:'Conversões',   val: fmt.numK(Math.round(bspSummary.sessoes*bspSummary.conversao/100)) },
                  ].map(m=>(
                    <div key={m.label} className="text-center">
                      <div className="text-xs" style={{ color:'#6B7280' }}>{m.label}</div>
                      <div className="text-sm font-bold text-ink">{m.val}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Funil resumido */}
            <div className="card p-5 xl:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="section-title">Funil de vendas</div>
                  <div className="text-xs mt-0.5" style={{ color:'#6B7280' }}>% de usuários únicos referente à etapa anterior</div>
                </div>
                <button onClick={()=>setTab('conversao')}
                  className="flex items-center gap-1 text-xs font-medium transition-colors"
                  style={{ color:'#1DAA5B' }}>
                  Ver detalhe <ArrowRight size={11}/>
                </button>
              </div>
              <FunnelBar steps={funnel.slice(0,8)} onSelect={s=>{setSelectedStep(s);setTab('conversao')}} selected={selectedStep?.label} />
            </div>
          </div>

          {/* Timeline */}
          <div className="card p-5">
            <div className="section-title mb-4">Volume de disparos e sessões</div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={timeline} margin={{ top:5,right:10,left:0,bottom:0 }}>
                <defs>
                  <linearGradient id="bG1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#1E6BFF" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#1E6BFF" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="bG2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#1DAA5B" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#1DAA5B" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)"/>
                <XAxis dataKey="label" tick={{ fill:'#6B7280',fontSize:10 }} axisLine={false} tickLine={false} interval={4}/>
                <YAxis tick={{ fill:'#6B7280',fontSize:10 }} axisLine={false} tickLine={false} width={44}/>
                <Tooltip content={<ChartTip/>}/>
                <Area type="monotone" dataKey="disparos" name="Disparos" stroke="#1E6BFF" strokeWidth={2} fill="url(#bG1)" dot={false}/>
                <Area type="monotone" dataKey="sessoes"  name="Sessões"  stroke="#1DAA5B" strokeWidth={2} fill="url(#bG2)" dot={false}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ══ DETALHE DE CONVERSÃO ══════════════════════════════════════════════ */}
      {tab==='conversao' && (
        <div className={`grid gap-5 ${selectedStep ? 'grid-cols-1 xl:grid-cols-2' : 'grid-cols-1'}`}>
          <div className="card p-5">
            <div className="section-title mb-1">Funil de vendas completo</div>
            <div className="text-xs mb-4" style={{ color:'#6B7280' }}>
              Clique em uma etapa para ver métricas detalhadas e a <strong style={{ color:'#4B5563' }}>origem do dataset</strong>
            </div>
            <FunnelBar steps={funnel} onSelect={setSelectedStep} selected={selectedStep?.label}/>
          </div>
          {selectedStep
            ? <StepDetail step={selectedStep} onClose={()=>setSelectedStep(null)}/>
            : (
              <div className="card p-10 flex flex-col items-center justify-center text-center">
                <BarChart2 size={32} style={{ color:'#9CA3AF' }} className="mb-3"/>
                <div className="text-sm font-semibold text-ink mb-1">Selecione uma etapa</div>
                <p className="text-xs max-w-[200px]" style={{ color:'#6B7280' }}>
                  Clique em qualquer barra do funil ao lado para ver métricas e a fonte do dado.
                </p>
              </div>
            )
          }
        </div>
      )}

      {/* ══ DEMOGRÁFICOS ══════════════════════════════════════════════════════ */}
      {tab==='demograficos' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <div className="card p-5">
            <div className="section-title mb-4">Gênero</div>
            <div className="flex items-center gap-6">
              <PieChart width={150} height={150}>
                <Pie data={bspDemographics.gender} dataKey="value" cx="50%" cy="50%" innerRadius={44} outerRadius={68} strokeWidth={0}>
                  {bspDemographics.gender.map((_,i)=><Cell key={i} fill={GENDER_COLORS[i]}/>)}
                </Pie>
              </PieChart>
              <div className="flex flex-col gap-2">
                {bspDemographics.gender.map((g,i)=>(
                  <div key={g.name} className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-sm" style={{ background:GENDER_COLORS[i] }}/>
                      <span className="text-sm" style={{ color:'#4B5563' }}>{g.name}</span>
                    </div>
                    <span className="text-sm font-bold text-ink">{g.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Faixa Etária</div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={bspDemographics.age} margin={{ top:0,right:0,left:-20,bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)"/>
                <XAxis dataKey="name" tick={{ fill:'#6B7280',fontSize:11 }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fill:'#6B7280',fontSize:11 }} axisLine={false} tickLine={false}/>
                <Tooltip content={<ChartTip/>}/>
                <Bar dataKey="value" name="%" radius={[4,4,0,0]}>
                  {bspDemographics.age.map((_,i)=><Cell key={i} fill={AGE_COLORS[i%AGE_COLORS.length]}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ══ CANAIS ════════════════════════════════════════════════════════════ */}
      {tab==='canais' && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <KpiCard label="Disparos enviados"  value={fmt.numK(bspSummary.disparos)}           icon={Send}         color="#1E6BFF"/>
            <KpiCard label="Sessões iniciadas"  value={fmt.numK(bspSummary.sessoes)}            icon={MessageSquare} color="#1DAA5B"/>
            <KpiCard label="Valor desembolsado" value={`R$ ${fmt.numK(bspSummary.valorTotal)}`} icon={DollarSign}    color="#8B5CF6"/>
            <KpiCard label="Ticket médio"       value={fmt.brl(bspSummary.ticketMedio)}         icon={TrendingUp}    color="#D97706"/>
          </div>
          <div className="card overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between" style={{ borderColor:'#E6E8EC' }}>
              <div>
                <div className="section-title text-sm">Performance comparativa por canal</div>
                <div className="text-xs mt-0.5" style={{ color:'#6B7280' }}>KPIs por canal — taxa, ticket e conversão</div>
              </div>
              <div className="relative">
                <select value={originFilter} onChange={e=>setOriginFilter(e.target.value)}
                  className="input-field text-xs py-1.5 pr-7 appearance-none cursor-pointer" style={{ minWidth:120 }}>
                  {origins.map(o=><option key={o} value={o}>{o}</option>)}
                </select>
                <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color:'#6B7280' }}/>
              </div>
            </div>
            <ChannelTable channels={filteredChannels}/>
          </div>
        </div>
      )}

      {/* ══ ENTRY POINTS ══════════════════════════════════════════════════════ */}
      {tab==='entrypoints' && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {bspEntryPoints.map(ep=>{
              const convColor = ep.convRate>=2 ? '#16A34A' : ep.convRate>=1.2 ? '#D97706' : '#DC2626'
              return (
                <div key={ep.name} className="card-hover p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background:'rgba(37,211,102,0.1)', border:'1px solid rgba(37,211,102,0.2)' }}>
                      <MessageSquare size={15} style={{ color:'#1DAA5B' }}/>
                    </div>
                    <span className="text-sm font-semibold text-ink">{ep.name}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    {[
                      { label:'Sessões',    val: fmt.numK(ep.sessoes),    color: undefined },
                      { label:'Conv.',      val: fmt.numK(ep.conversoes), color: undefined },
                      { label:'Taxa conv.', val: `${ep.convRate.toFixed(2)}%`, color: convColor },
                    ].map(m=>(
                      <div key={m.label}>
                        <div className="text-xs" style={{ color:'#6B7280' }}>{m.label}</div>
                        <div className="text-sm font-bold" style={{ color: m.color||'#111827' }}>{m.val}</div>
                      </div>
                    ))}
                  </div>
                  <div className="h-1.5 rounded-full" style={{ background:'#E6E8EC' }}>
                    <div className="h-full rounded-full" style={{
                      width:`${(ep.sessoes/bspEntryPoints[0].sessoes)*100}%`,
                      background:'linear-gradient(90deg,#1DAA5B,#128C7E)',
                    }}/>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="card p-5">
            <div className="section-title mb-4">Sessões por entry point</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={bspEntryPoints} layout="vertical" margin={{ top:0,right:60,left:20,bottom:0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)" horizontal={false}/>
                <XAxis type="number" tick={{ fill:'#6B7280',fontSize:10 }} axisLine={false} tickLine={false}/>
                <YAxis type="category" dataKey="name" tick={{ fill:'#4B5563',fontSize:11 }} axisLine={false} tickLine={false} width={160}/>
                <Tooltip content={<ChartTip/>}/>
                <Bar dataKey="sessoes" name="Sessões" fill="#1DAA5B" radius={[0,4,4,0]} opacity={0.9}/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  )
}
