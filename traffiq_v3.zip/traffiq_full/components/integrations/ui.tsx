import { useEffect, useRef, useState, type ReactNode, type InputHTMLAttributes } from 'react'
import { createPortal } from 'react-dom'
import clsx from 'clsx'
import { X } from 'lucide-react'
export interface MarkDef { id: string; short: string; color: string; name: string }

// Marca da plataforma: usa /public/logos/<id>.svg se existir, senao monograma na cor da marca
export function PlatformMark({ p, size = 40, muted = false }: { p: MarkDef; size?: number; muted?: boolean }) {
  const [failed, setFailed] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)
  // o 404 pode acontecer antes da hidratacao e o onError nao dispara: checa ao montar
  useEffect(() => {
    const img = imgRef.current
    if (img && img.complete && img.naturalWidth === 0) setFailed(true)
  }, [])
  return (
    <span
      className={clsx('grid shrink-0 place-items-center overflow-hidden rounded-xl border border-border bg-white', muted && 'grayscale opacity-60')}
      style={{ width: size, height: size }}
    >
      {!failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img ref={imgRef} src={`/logos/${p.id}.svg`} alt="" width={size * 0.55} height={size * 0.55} onError={() => setFailed(true)} />
      ) : (
        <span
          className="grid h-full w-full place-items-center font-bold text-white"
          style={{ background: p.color, fontSize: size * (p.short.length > 1 ? 0.3 : 0.4) }}
          aria-hidden
        >
          {p.short}
        </span>
      )}
    </span>
  )
}

export function StatusPill({ tone, children }: { tone: 'ok' | 'idle' | 'warn' | 'soon'; children: ReactNode }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[12px] font-medium',
        tone === 'ok' && 'bg-[#E7F6EC] text-success',
        tone === 'warn' && 'bg-[#FEF3E2] text-warning',
        tone === 'idle' && 'bg-bg text-muted-2',
        tone === 'soon' && 'bg-bg text-muted',
      )}
    >
      {tone === 'ok' && <span className="h-1.5 w-1.5 rounded-full bg-success" aria-hidden />}
      {tone === 'warn' && <span className="h-1.5 w-1.5 rounded-full bg-warning" aria-hidden />}
      {children}
    </span>
  )
}

export function Modal({ open, onClose, title, subtitle, children, footer, wide = false }: {
  open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode; footer?: ReactNode; wide?: boolean
}) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev }
  }, [open, onClose])

  if (!mounted || !open) return null
  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-ink/30 p-4 font-sans backdrop-blur-[2px]" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={clsx('flex max-h-[90vh] w-full flex-col', wide ? 'max-w-[760px]' : 'max-w-[520px]', 'overflow-hidden rounded-2xl border border-border bg-white shadow-flyout')}
        onMouseDown={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-border px-6 py-5">
          <div>
            <h2 className="text-[17px] font-semibold text-ink">{title}</h2>
            {subtitle && <p className="mt-1 text-[14px] leading-relaxed text-muted-2">{subtitle}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Fechar" className="rounded-lg p-1.5 text-muted-2 hover:bg-[#F0F1F4] focus-visible:ring-2 focus-visible:ring-accent/50 outline-none">
            <X size={18} />
          </button>
        </div>
        <div className="overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-border bg-surface-2 px-6 py-4">{footer}</div>}
      </div>
    </div>,
    document.body,
  )
}

export function Field({ label, hint, ...props }: { label: string; hint?: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-medium text-ink">{label}</span>
      <input
        {...props}
        className="h-10 w-full rounded-lg border border-border bg-white px-3 text-[14px] text-ink placeholder:text-muted outline-none transition-shadow focus:border-accent focus:ring-2 focus:ring-accent/20"
      />
      {hint && <span className="mt-1.5 block text-[12px] leading-relaxed text-muted">{hint}</span>}
    </label>
  )
}

export function Button({ variant = 'primary', className, ...props }: { variant?: 'primary' | 'secondary' | 'ghost' | 'danger' } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={clsx(
        'inline-flex h-9 items-center justify-center gap-1.5 rounded-lg px-3.5 text-[14px] font-medium transition-colors outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:cursor-not-allowed disabled:opacity-50',
        variant === 'primary' && 'bg-ink text-white hover:bg-ink/85',
        variant === 'secondary' && 'border border-border bg-white text-ink hover:bg-[#F0F1F4]',
        variant === 'ghost' && 'text-muted-2 hover:bg-[#F0F1F4] hover:text-ink',
        variant === 'danger' && 'text-danger hover:bg-[#FDECEC]',
        className,
      )}
    />
  )
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div role="tablist" className="inline-flex rounded-lg bg-bg p-1">
      {options.map(o => (
        <button
          key={o.value}
          role="tab"
          type="button"
          aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={clsx(
            'rounded-md px-3 py-1.5 text-[13px] font-medium transition-colors outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
            value === o.value ? 'bg-white text-ink shadow-sm' : 'text-muted-2 hover:text-ink',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
