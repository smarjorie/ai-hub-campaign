import { useState, type ReactNode } from 'react'
import { Plus, Server, Globe, Trash2 } from 'lucide-react'
import { PlatformMark, StatusPill, Modal } from './ui'
import CustomIntegrationModal from './CustomIntegrationModal'
import McpEndpointCard from './McpEndpointCard'
import { useCustomIntegrations } from '@/lib/connections'

type Status = 'real' | 'mock' | 'loading' | 'error'

interface Props {
  meta: { status: Status; accountName?: string; accountId?: string; userName?: string; mcpEnabled: boolean }
  google: { status: Status; customerName?: string }
  metaFlow: ReactNode      // MetaConnectFlow + MetaMcpCard, vindos do index
  googleFlow: ReactNode    // GoogleConnectFlow
}

const CAPS: Record<'meta' | 'google', { label: string; write?: boolean }[]> = {
  meta: [
    { label: 'Insights por campanha, conjunto e anúncio' },
    { label: 'Ranking de criativos e conversas CTWA' },
    { label: 'Pausar e ativar entregas', write: true },
    { label: 'Ajustar orçamento diário', write: true },
  ],
  google: [
    { label: 'Desempenho por campanha' },
    { label: 'Série diária de custo e conversões' },
  ],
}

const PLATFORMS = {
  meta: { id: 'meta', short: 'M', color: '#1877F2', name: 'Meta Ads', desc: 'Facebook e Instagram, com campanhas Click to WhatsApp.' },
  google: { id: 'google', short: 'G', color: '#1A73E8', name: 'Google Ads', desc: 'Pesquisa, Display e Performance Max.' },
  openai: { id: 'openai', short: 'AI', color: '#10A37F', name: 'ChatGPT Ads', desc: 'Anúncios nas respostas do ChatGPT.' },
  tiktok: { id: 'tiktok', short: 'T', color: '#111318', name: 'TikTok Ads', desc: 'Campanhas in-feed e Spark Ads.' },
}

function statusPill(s: Status) {
  if (s === 'real') return <StatusPill tone="ok">Conectado</StatusPill>
  if (s === 'loading') return <StatusPill tone="idle">Carregando...</StatusPill>
  if (s === 'error') return <StatusPill tone="warn">Erro na conexão</StatusPill>
  return <StatusPill tone="idle">Não conectado</StatusPill>
}

export default function IntegrationsHub({ meta, google, metaFlow, googleFlow }: Props) {
  const [openFlow, setOpenFlow] = useState<'meta' | 'google' | null>(null)
  const [customOpen, setCustomOpen] = useState(false)
  const custom = useCustomIntegrations()

  const cards = [
    { key: 'meta' as const, st: meta.status, account: meta.accountName || meta.accountId, extra: meta.mcpEnabled ? 'MCP ativo' : undefined },
    { key: 'google' as const, st: google.status, account: google.customerName, extra: undefined },
  ]
  const activeCount = cards.filter(c => c.st === 'real').length + custom.list.length

  return (
    <div className="mx-auto max-w-[1080px]">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-semibold tracking-[-0.02em] text-ink">Integrações</h1>
          <p className="mt-1.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
            Conecte as contas que o painel, o Assistente e as Automações usam. Alterações nas contas sempre pedem sua confirmação.
          </p>
        </div>
        <p className="text-[14px] tabular-nums text-muted-2">
          {activeCount === 0 ? 'Nenhuma conexão ativa' : `${activeCount} ${activeCount === 1 ? 'conexão ativa' : 'conexões ativas'}`}
        </p>
      </header>

      <section aria-labelledby="ads">
        <h2 id="ads" className="mb-3 text-[15px] font-semibold text-ink">Plataformas de anúncio</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {cards.map(c => {
            const p = PLATFORMS[c.key]
            const connected = c.st === 'real'
            return (
              <article key={c.key} className="flex flex-col rounded-2xl border border-border bg-white">
                <header className="flex items-start gap-3.5 p-5 pb-4">
                  <PlatformMark p={p} size={44} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-[16px] font-semibold text-ink">{p.name}</h3>
                      {statusPill(c.st)}
                      {c.extra && <span className="badge-blue">{c.extra}</span>}
                    </div>
                    <p className="mt-1 text-[14px] leading-relaxed text-muted-2">{p.desc}</p>
                  </div>
                </header>
                {connected && c.account && (
                  <p className="mx-5 mb-4 rounded-xl border border-border bg-surface-2 px-3 py-2 text-[13px]">
                    <span className="text-muted">Conta: </span><span className="font-medium text-ink">{c.account}</span>
                  </p>
                )}
                <div className="px-5 pb-5">
                  <p className="mb-2 text-[13px] font-medium text-ink">O que fica disponível</p>
                  <ul className="space-y-1.5">
                    {CAPS[c.key].map(cap => (
                      <li key={cap.label} className="flex items-center justify-between gap-3 text-[14px] text-muted-2">
                        <span>{cap.label}</span>
                        <span className={cap.write ? 'shrink-0 text-[12px] text-[#B45309]' : 'shrink-0 text-[12px] text-muted'}>
                          {cap.write ? 'com confirmação' : 'leitura'}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <footer className="mt-auto flex justify-end border-t border-border px-5 py-3.5">
                  <button type="button" className={connected ? 'btn-secondary py-1.5 text-[13px]' : 'btn-primary py-1.5 text-[13px]'} onClick={() => setOpenFlow(c.key)}>
                    {connected ? 'Gerenciar' : 'Conectar'}
                  </button>
                </footer>
              </article>
            )
          })}
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {(['openai', 'tiktok'] as const).map(k => {
            const p = PLATFORMS[k]
            return (
              <article key={k} aria-disabled="true" className="flex items-center gap-3.5 rounded-2xl border border-border bg-surface-2 p-4">
                <PlatformMark p={p} size={38} muted />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-[15px] font-semibold text-muted-2">{p.name}</h3>
                    <StatusPill tone="soon">Em breve</StatusPill>
                  </div>
                  <p className="mt-0.5 truncate text-[13px] text-muted">{p.desc}</p>
                </div>
                <button type="button" className="btn-secondary py-1.5 text-[13px]" disabled aria-label={`Conectar ${p.name} (em breve)`}>Conectar</button>
              </article>
            )
          })}
        </div>
      </section>

      <section aria-labelledby="custom" className="mt-10">
        <h2 id="custom" className="text-[15px] font-semibold text-ink">Suas integrações</h2>
        <p className="mb-3 mt-1 text-[14px] text-muted-2">CRM, BSP de WhatsApp, planilhas ou qualquer servidor MCP.</p>
        <div className="grid gap-4 md:grid-cols-2">
          <button type="button" onClick={() => setCustomOpen(true)}
            className="flex items-center gap-3.5 rounded-2xl border border-dashed border-border-2 p-4 text-left transition-colors hover:border-accent hover:bg-[#F5F8FF] outline-none focus-visible:ring-2 focus-visible:ring-accent/40">
            <span className="grid h-[38px] w-[38px] place-items-center rounded-xl bg-[#F0F1F4] text-muted-2"><Plus size={18} /></span>
            <span>
              <span className="block text-[15px] font-semibold text-ink">Adicionar integração</span>
              <span className="block text-[13px] text-muted-2">Servidor MCP ou API própria</span>
            </span>
          </button>
        </div>
        {custom.list.length > 0 && (
          <ul className="mt-4 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-white">
            {custom.list.map(c => {
              const Icon = c.type === 'mcp' ? Server : Globe
              return (
                <li key={c.id} className="flex items-center gap-3.5 px-4 py-3">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-[#F0F1F4] text-muted-2"><Icon size={17} /></span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[14px] font-medium text-ink">{c.name}</p>
                    <p className="truncate text-[12px] text-muted">{c.type === 'mcp' ? 'MCP' : 'REST'}: {c.url}</p>
                  </div>
                  <StatusPill tone="ok">Adicionada</StatusPill>
                  <button type="button" onClick={() => custom.remove(c.id)} aria-label={`Remover ${c.name}`}
                    className="rounded-lg p-2 text-muted hover:bg-[#FDECEC] hover:text-danger">
                    <Trash2 size={16} />
                  </button>
                </li>
              )
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="mcp" className="mt-10">
        <h2 id="mcp" className="mb-3 text-[15px] font-semibold text-ink">Usar o Traffiq em outras IAs</h2>
        <McpEndpointCard />
      </section>

      <Modal wide open={openFlow === 'meta'} onClose={() => setOpenFlow(null)} title="Meta Ads" subtitle="Conecte com um token da Insights API ou ative o uso via MCP.">
        <div className="space-y-4">{metaFlow}</div>
      </Modal>
      <Modal wide open={openFlow === 'google'} onClose={() => setOpenFlow(null)} title="Google Ads" subtitle="Developer token, OAuth e Customer ID da conta.">
        {googleFlow}
      </Modal>
      <CustomIntegrationModal open={customOpen} onClose={() => setCustomOpen(false)} onSave={custom.add} />
    </div>
  )
}
