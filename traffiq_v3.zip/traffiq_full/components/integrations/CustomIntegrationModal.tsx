import { useState } from 'react'
import type { CustomIntegration } from '@/lib/connections'
import { Modal, Field, Button, Segmented } from './ui'

type Draft = Omit<CustomIntegration, 'id' | 'createdAt'>

export default function CustomIntegrationModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (c: Draft) => void }) {
  const [type, setType] = useState<Draft['type']>('mcp')
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [authHeader, setAuthHeader] = useState('Authorization')
  const [authValue, setAuthValue] = useState('')

  const valid = name.trim().length > 1 && /^https:\/\/.+/.test(url.trim())

  function reset() { setType('mcp'); setName(''); setUrl(''); setAuthHeader('Authorization'); setAuthValue('') }
  function close() { reset(); onClose() }
  function save() {
    onSave({
      type,
      name: name.trim(),
      url: url.trim(),
      authHeader: authValue.trim() ? authHeader.trim() : undefined,
      authValue: authValue.trim() || undefined,
    })
    close()
  }

  return (
    <Modal
      open={open}
      onClose={close}
      title="Adicionar integração"
      subtitle="Conecte um servidor MCP ou uma API própria (CRM, BSP, data warehouse) para o agente usar nas ações."
      footer={<><Button variant="ghost" onClick={close}>Cancelar</Button><Button onClick={save} disabled={!valid}>Adicionar integração</Button></>}
    >
      <div className="space-y-4">
        <Segmented value={type} onChange={setType} options={[{ value: 'mcp', label: 'Servidor MCP' }, { value: 'rest', label: 'API REST' }]} />
        <Field label="Nome" placeholder={type === 'mcp' ? 'Ex.: Semrush' : 'Ex.: CRM de vendas'} value={name} onChange={e => setName(e.target.value)} />
        <Field
          label={type === 'mcp' ? 'URL do servidor' : 'URL base'}
          placeholder={type === 'mcp' ? 'https://mcp.exemplo.com/mcp' : 'https://api.exemplo.com/v1'}
          value={url}
          onChange={e => setUrl(e.target.value)}
          hint="Precisa começar com https://"
        />
        <div className="grid grid-cols-[1fr_1.4fr] gap-3">
          <Field label="Header de autenticação" value={authHeader} onChange={e => setAuthHeader(e.target.value)} />
          <Field label="Valor" type="password" autoComplete="off" placeholder="Bearer ..." value={authValue} onChange={e => setAuthValue(e.target.value)} />
        </div>
        <p className="text-[12px] leading-relaxed text-muted">
          Deixe o valor vazio se o servidor usa OAuth próprio. As credenciais ficam só neste navegador até existir um cofre no backend.
        </p>
      </div>
    </Modal>
  )
}
