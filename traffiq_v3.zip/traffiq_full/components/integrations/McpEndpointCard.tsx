import { useEffect, useState } from 'react'
import { Copy, Check } from 'lucide-react'
import { Button } from './ui'

const CLIENTS = [
  { name: 'Claude', how: 'Configurações > Conectores > Adicionar conector personalizado' },
  { name: 'ChatGPT', how: 'Configurações > Apps e conectores > Modo desenvolvedor > Criar' },
  { name: 'Cursor, Claude Code, Gemini CLI', how: 'Servidor MCP remoto do tipo http no arquivo de configuração' },
]

export default function McpEndpointCard() {
  const [url, setUrl] = useState('')
  const [copied, setCopied] = useState(false)
  useEffect(() => { setUrl(`${window.location.origin}/api/mcp?key=SUA_TRAFFIQ_MCP_KEY`) }, [])

  async function copy() {
    try { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1600) } catch { /* sem clipboard */ }
  }

  return (
    <article className="rounded-2xl border border-border bg-white p-5">
      <p className="text-[14px] leading-relaxed text-muted-2">
        O Traffiq expõe as mesmas contas como um servidor MCP. Cole este endereço em qualquer IA compatível para ela consultar
        campanhas da Meta e do Google usando as credenciais configuradas no servidor.
      </p>
      <div className="mt-4 flex items-center gap-2">
        <code className="min-w-0 flex-1 truncate rounded-lg border border-border bg-surface-2 px-3 py-2 text-[13px] text-ink">{url || '...'}</code>
        <Button variant="secondary" onClick={copy} aria-label="Copiar endereço">
          {copied ? <Check size={15} /> : <Copy size={15} />} {copied ? 'Copiado' : 'Copiar'}
        </Button>
      </div>
      <p className="mt-2 text-[12px] text-muted">Troque SUA_TRAFFIQ_MCP_KEY pela chave definida em TRAFFIQ_MCP_KEY. Clientes que aceitam headers podem usar Authorization: Bearer.</p>
      <ul className="mt-4 divide-y divide-border border-t border-border">
        {CLIENTS.map(c => (
          <li key={c.name} className="flex flex-wrap justify-between gap-x-4 gap-y-0.5 py-2.5 text-[13px]">
            <span className="font-medium text-ink">{c.name}</span>
            <span className="text-muted-2">{c.how}</span>
          </li>
        ))}
      </ul>
    </article>
  )
}
