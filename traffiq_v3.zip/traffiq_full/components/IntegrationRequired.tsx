import { Plug, ArrowRight } from 'lucide-react'

interface Props {
  platform: 'meta' | 'google' | 'whatsapp'
  feature:  string
  onGoToIntegrations: () => void
}

const INFO = {
  meta:      { color: '#1877F2', bg: 'rgba(24,119,242,0.08)', icon: '∞', name: 'Meta Ads',    border: 'rgba(24,119,242,0.2)' },
  google:    { color: '#EA4335', bg: 'rgba(234,67,53,0.08)',  icon: 'G', name: 'Google Ads',  border: 'rgba(234,67,53,0.2)' },
  whatsapp:  { color: '#1DAA5B', bg: 'rgba(37,211,102,0.08)', icon: 'W', name: 'WhatsApp BSP',border: 'rgba(37,211,102,0.2)' },
}

export default function IntegrationRequired({ platform, feature, onGoToIntegrations }: Props) {
  const info = INFO[platform]
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center rounded-2xl"
      style={{ background: info.bg, border: `1px dashed ${info.border}` }}>
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-2xl mb-4"
        style={{ background: `${info.color}20`, color: info.color, border: `1px solid ${info.border}` }}>
        {info.icon}
      </div>
      <div className="text-ink font-semibold text-lg mb-2">
        Conecte o {info.name} para ver {feature}
      </div>
      <p className="text-sm mb-6 max-w-sm" style={{ color: '#4B5563' }}>
        Esta seção exibe dados reais da sua conta. Configure a integração uma vez e os dados atualizam automaticamente.
      </p>
      <button onClick={onGoToIntegrations} className="btn-primary flex items-center gap-2">
        <Plug size={14} /> Ir para Integrações <ArrowRight size={14} />
      </button>
    </div>
  )
}
