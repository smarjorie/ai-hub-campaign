import { BspFunnelStep } from '@/lib/mockBspData'
import { fmt } from '@/lib/format'

interface Props { steps: BspFunnelStep[]; onSelect?: (step: BspFunnelStep) => void; selected?: string }

// Color ramp: blue → teal → green based on position
function stepColor(i: number, total: number): string {
  const t = i / (total - 1)
  // Interpolate from #1E6BFF → #00B8A0
  const r = Math.round(30  + (0   - 30)  * t)
  const g = Math.round(107 + (184 - 107) * t)
  const b = Math.round(255 + (160 - 255) * t)
  return `rgb(${r},${g},${b})`
}

export default function BspFunnelBar({ steps, onSelect, selected }: Props) {
  const maxVal = steps[0]?.value || 1

  return (
    <div className="flex flex-col gap-1.5">
      {steps.map((step, i) => {
        const barW    = (step.value / maxVal) * 100
        const color   = stepColor(i, steps.length)
        const active  = selected === step.label

        return (
          <button
            key={step.label}
            onClick={() => onSelect?.(step)}
            className="flex items-center gap-3 group w-full text-left transition-all rounded-lg px-2 py-1"
            style={{ background: active ? 'rgba(30,107,255,0.06)' : 'transparent' }}
          >
            {/* Label */}
            <div className="w-44 flex-shrink-0 text-right">
              <span className="text-xs transition-colors"
                style={{ color: active ? '#111827' : '#4B5563' }}>
                {step.label}
              </span>
            </div>

            {/* Bar + value */}
            <div className="flex-1 flex items-center gap-2 min-w-0">
              <div className="flex-1 h-5 rounded-md overflow-hidden relative"
                style={{ background: '#E6E8EC' }}>
                <div
                  className="h-full rounded-md flex items-center justify-end pr-2 transition-all duration-700"
                  style={{ width: `${Math.max(4, barW)}%`, background: color, opacity: active ? 1 : 0.85 }}
                >
                  {barW > 25 && (
                    <span className="text-xs font-bold text-ink" style={{ fontSize: 10 }}>
                      {i === 0 ? '100%' : `${step.pct}%`}
                    </span>
                  )}
                </div>
                {barW <= 25 && (
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold"
                    style={{ color: '#4B5563', fontSize: 10 }}>
                    {i === 0 ? '100%' : `${step.pct}%`}
                  </span>
                )}
              </div>

              {/* Absolute number */}
              <span className="text-xs font-semibold w-16 flex-shrink-0 text-right"
                style={{ color: active ? '#111827' : '#374151' }}>
                {fmt.numK(step.value)}
              </span>
            </div>
          </button>
        )
      })}
    </div>
  )
}
