import { useState, useMemo, useEffect } from 'react'
import { createPortal } from 'react-dom'
import {
  ExternalLink, Instagram, Filter, SortDesc,
  MessageSquare, DollarSign, TrendingUp, Eye, Users, ShoppingCart,
  ChevronDown, Search, Play, Image, BarChart2,
  ArrowUpDown, CheckCircle2, XCircle, Clock,
} from 'lucide-react'
import { fmt } from '@/lib/format'

interface Ad {
  id: string; name: string; status: string
  campaign_id: string; campaign_name: string; campaign_objective?: string
  adset_name?: string; platform: string; isCtwa?: boolean
  spend: number; impressions: number; clicks: number
  ctr: number; cpm: number; roas: number
  salesDb: number; revenue: number; profit: number
  cpa?: { db: number }
  addToCart?: number; checkouts?: number; pageViews?: number
  postUrl?: string; thumbnail?: string; creativeUrl?: string
  // WhatsApp metrics (from funnel-detail WA campaigns)
  waConvs?: number; ctwa?: number; cplWa?: number
}

interface Props {
  campaigns: any[]
  isReal:    boolean
  metaToken: string
  accountId: string
  onGoIntegrations: () => void
}

type SortField = 'waConvs' | 'roas' | 'spend' | 'ctr' | 'salesDb' | 'revenue' | 'cplWa'
type FilterPlatform = 'all' | 'meta' | 'google' | 'tiktok'
type FilterStatus   = 'all' | 'ACTIVE' | 'PAUSED'
type FilterObjective = 'all' | 'whatsapp' | 'other'

const SORT_OPTIONS: { key: SortField; label: string }[] = [
  { key: 'waConvs', label: 'Conversas WA'  },
  { key: 'roas',    label: 'ROAS'          },
  { key: 'spend',   label: 'Investimento'  },
  { key: 'salesDb', label: 'Compras/Leads' },
  { key: 'ctr',     label: 'CTR'          },
  { key: 'revenue', label: 'Receita'       },
  { key: 'cplWa',   label: 'CPL WA'       },
]

const PLATFORM_BADGE: Record<string, string> = {
  meta: '#1877F2', google: '#EA4335', tiktok: '#FF0050',
}
const PLATFORM_BG: Record<string, string> = {
  meta: 'rgba(24,119,242,0.12)', google: 'rgba(234,67,53,0.12)', tiktok: 'rgba(255,0,80,0.12)',
}

function roasColor(v: number) {
  return v >= 5 ? '#16A34A' : v >= 3 ? '#D97706' : '#DC2626'
}

function ImageZoom({ src, onClose }: { src: string; onClose: () => void }) {
  // Render via portal directly on body to escape any overflow:hidden parents
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handler)
      document.body.style.overflow = ''
    }
  }, [onClose])

  if (typeof document === 'undefined') return null

  return createPortal(
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(17,24,39,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ position: 'relative', maxWidth: '90vw', maxHeight: '90vh', borderRadius: 16, overflow: 'hidden', boxShadow: '0 24px 80px rgba(17,24,39,0.06)' }}
      >
        <img
          src={src} alt="Criativo"
          style={{ display: 'block', maxWidth: '90vw', maxHeight: '85vh', objectFit: 'contain' }}
        />
        <button
          onClick={onClose}
          style={{
            position: 'absolute', top: 12, right: 12,
            width: 36, height: 36, borderRadius: '50%',
            background: 'rgba(17,24,39,0.06)', border: '1px solid rgba(255,255,255,0.2)',
            color: '#fff', fontSize: 18, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            lineHeight: 1,
          }}
        >
          ✕
        </button>
        <div style={{ position: 'absolute', bottom: 12, left: '50%', transform: 'translateX(-50%)', fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>
          Pressione ESC ou clique fora para fechar
        </div>
      </div>
    </div>,
    document.body
  )
}

function CreativeCard({ ad, rank }: { ad: Ad; rank: number }) {
  const [expanded, setExpanded] = useState(false)
  const [zoomImg,  setZoomImg]  = useState<string | null>(null)
  // isCtwa: STRICT — only from API signal (destination_type=WHATSAPP)
  const isCtwa  = ad.isCtwa === true
  const hasWA   = (ad.waConvs || 0) > 0
  const plColor   = PLATFORM_BADGE[ad.platform] || '#6B7280'
  const plBg      = PLATFORM_BG[ad.platform]    || 'rgba(90,96,128,0.12)'

  // Derive creative type from name
  const creativeType = ad.name.toLowerCase().includes('vsl') || ad.name.toLowerCase().includes('vídeo') ? 'video'
    : ad.name.toLowerCase().includes('imagem') || ad.name.toLowerCase().includes('foto') ? 'image'
    : 'mixed'

  const TypeIcon = creativeType === 'video' ? Play : Image

  return (
    <div className="card-hover overflow-hidden transition-all"
      style={{ borderLeft: hasWA ? '3px solid #1DAA5B' : `3px solid ${plColor}` }}>

      {/* Main row */}
      <div className="flex items-center gap-4 p-4">

        {/* Rank + status */}
        <div className="flex flex-col items-center gap-1 flex-shrink-0" style={{ width: 28 }}>
          <span className="text-xs font-black" style={{ color: rank <= 3 ? '#D97706' : '#6B7280' }}>#{rank}</span>
          <div className={`status-${ad.status === 'ACTIVE' ? 'active' : 'paused'}`} />
        </div>

        {/* Thumbnail / placeholder — click to zoom */}
        <div
          className="flex-shrink-0 rounded-xl overflow-hidden flex items-center justify-center transition-all"
          style={{ width: 52, height: 52, background: `${plColor}18`, border: `1px solid ${plColor}25`, cursor: ad.thumbnail ? 'zoom-in' : 'default' }}
          onClick={() => ad.thumbnail && setZoomImg(ad.thumbnail)}
          title={ad.thumbnail ? 'Clique para ampliar' : undefined}
        >
          {ad.thumbnail
            ? <img src={ad.thumbnail} alt="" className="w-full h-full object-cover hover:opacity-80 transition-opacity" />
            : <TypeIcon size={20} style={{ color: plColor }} />
          }
        </div>
        {zoomImg && <ImageZoom src={zoomImg} onClose={() => setZoomImg(null)} />}

        {/* Name + campaign */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-0.5">
            <span className="text-xs font-bold px-2 py-0.5 rounded-md"
              style={{ background: plBg, color: plColor }}>
              {ad.platform.toUpperCase()}
            </span>
            {isCtwa && (
              <span className="flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-md"
                style={{ background: 'rgba(37,211,102,0.15)', color: '#1DAA5B', border: '1px solid rgba(37,211,102,0.25)' }}>
                <MessageSquare size={10} /> CTWA
              </span>
            )}
            {hasWA && !isCtwa && (
              <span className="flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-md"
                style={{ background: 'rgba(37,211,102,0.10)', color: '#1DAA5B', border: '1px solid rgba(37,211,102,0.15)' }}>
                <MessageSquare size={10} /> WA
              </span>
            )}
            <span className="text-xs px-1.5 py-0.5 rounded"
              style={{ background: ad.status === 'ACTIVE' ? 'rgba(22,163,74,0.1)' : 'rgba(90,96,128,0.1)', color: ad.status === 'ACTIVE' ? '#16A34A' : '#6B7280' }}>
              {ad.status === 'ACTIVE' ? 'Ativo' : 'Pausado'}
            </span>
          </div>
          <div className="text-sm font-semibold text-ink truncate">{ad.name}</div>
          <div className="text-xs truncate" style={{ color: '#6B7280' }}>
            {ad.campaign_name?.slice(0, 40)}{ad.campaign_name?.length > 40 ? '…' : ''}
            {ad.adset_name && <span style={{ color: '#9CA3AF' }}> › {ad.adset_name}</span>}
          </div>
        </div>

        {/* Key metrics */}
        <div className="flex items-center gap-5 flex-shrink-0">
          {hasWA && (
            <div className="text-center">
              <div className="text-xs mb-0.5" style={{ color: '#1DAA5B' }}>Conversas WA</div>
              <div className="text-lg font-black" style={{ color: '#1DAA5B' }}>{fmt.numK(ad.waConvs || 0)}</div>
              {ad.cplWa && <div className="text-xs" style={{ color: '#6B7280' }}>CPL {fmt.brl(ad.cplWa)}</div>}
            </div>
          )}
          <div className="text-center">
            <div className="text-xs mb-0.5" style={{ color: '#6B7280' }}>CPL WA</div>
            <div className="text-lg font-black" style={{ color: (ad.cplWa || 0) > 0 ? '#1DAA5B' : '#6B7280' }}>
              {(ad.cplWa || 0) > 0 ? fmt.brl(ad.cplWa!) : '—'}
            </div>
          </div>
          <div className="text-center hidden md:block">
            <div className="text-xs mb-0.5" style={{ color: '#6B7280' }}>Investido</div>
            <div className="text-base font-bold text-ink">{fmt.brlK(ad.spend)}</div>
          </div>
          <div className="text-center hidden lg:block">
            <div className="text-xs mb-0.5" style={{ color: '#6B7280' }}>CTR</div>
            <div className="text-base font-bold text-ink">{fmt.pct(ad.ctr)}</div>
          </div>
          <div className="text-center hidden lg:block">
            <div className="text-xs mb-0.5" style={{ color: '#6B7280' }}>Compras</div>
            <div className="text-base font-bold text-ink">{ad.salesDb}</div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {ad.postUrl && ad.postUrl.startsWith('http') && !ad.postUrl.includes('example') && (
            <a href={ad.postUrl} target="_blank" rel="noreferrer"
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-all"
              style={{ background: `${plColor}15`, color: plColor, border: `1px solid ${plColor}25` }}
              onMouseEnter={e => (e.currentTarget.style.background = `${plColor}25`)}
              onMouseLeave={e => (e.currentTarget.style.background = `${plColor}15`)}>
              <ExternalLink size={12} />
              <span className="hidden sm:inline">Ver post</span>
            </a>
          )}
          <button onClick={() => setExpanded(!expanded)}
            className="p-1.5 rounded-lg transition-colors"
            style={{ color: '#6B7280', background: 'transparent' }}
            onMouseEnter={e => (e.currentTarget.style.background = '#F7F8FA')}
            onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
            <ChevronDown size={14} style={{ transform: expanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>
        </div>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t px-4 pb-4 pt-3" style={{ borderColor: '#E6E8EC', background: '#F4F5F7' }}>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-4">
            {[
              { label: 'Impressões',  value: fmt.numK(ad.impressions) },
              { label: 'Cliques',     value: fmt.numK(ad.clicks)      },
              { label: 'CTR',         value: fmt.pct(ad.ctr)          },
              { label: 'CPM',         value: fmt.brl(ad.cpm)          },
              { label: 'Receita',     value: fmt.brlK(ad.revenue)     },
              { label: 'CPA',         value: fmt.brl(ad.cpa?.db || 0) },
              ...(ad.pageViews  ? [{ label: 'Page Views',  value: fmt.numK(ad.pageViews)  }] : []),
              ...(ad.addToCart  ? [{ label: 'Add to Cart', value: fmt.numK(ad.addToCart)  }] : []),
              ...(ad.checkouts  ? [{ label: 'Checkouts',   value: fmt.numK(ad.checkouts)  }] : []),
              ...(hasWA ? [
                { label: 'CTWA',         value: fmt.numK(ad.ctwa || 0)  },
                { label: 'Conversas WA', value: fmt.numK(ad.waConvs || 0) },
                { label: 'CPL WA',       value: fmt.brl(ad.cplWa || 0)  },
              ] : []),
            ].map(m => (
              <div key={m.label} className="rounded-lg p-2.5" style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}>
                <div className="text-xs mb-0.5" style={{ color: '#6B7280' }}>{m.label}</div>
                <div className="text-sm font-bold text-ink">{m.value}</div>
              </div>
            ))}
          </div>

          {/* Links */}
          <div className="flex flex-wrap gap-2">
            {ad.postUrl && ad.postUrl.startsWith('http') && !ad.postUrl.includes('example') && (
              <a href={ad.postUrl} target="_blank" rel="noreferrer"
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium"
                style={{ background: `${plColor}15`, color: plColor, border: `1px solid ${plColor}25` }}>
                <ExternalLink size={11} /> Ver post / criativo
              </a>
            )}
            <a href={`https://www.facebook.com/ads/library/?q=${encodeURIComponent(ad.name)}`}
              target="_blank" rel="noreferrer"
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium"
              style={{ background: 'rgba(30,107,255,0.1)', color: '#1E6BFF', border: '1px solid rgba(30,107,255,0.2)' }}>
              <Search size={11} /> Biblioteca de Anúncios
            </a>
            <a href={`https://adsmanager.facebook.com/adsmanager/manage/ads?act=${encodeURIComponent('')}&selected_ad_ids=${ad.id}`}
              target="_blank" rel="noreferrer"
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium"
              style={{ background: 'rgba(30,107,255,0.1)', color: '#1E6BFF', border: '1px solid rgba(30,107,255,0.2)' }}>
              <BarChart2 size={11} /> Gerenciador de Anúncios
            </a>
          </div>
        </div>
      )}
    </div>
  )
}

export default function CreativeRanking({ campaigns, isReal, onGoIntegrations }: Props) {
  const [sortBy,     setSortBy]     = useState<SortField>('waConvs')
  const [platform,   setPlatform]   = useState<FilterPlatform>('all')
  const [status,     setStatus]     = useState<FilterStatus>('all')
  const [search,     setSearch]     = useState('')
  const [showSort,    setShowSort]    = useState(false)
  const [objective,   setObjective]   = useState<FilterObjective>('all')
  const [campaign,    setCampaign]    = useState('all')
  const [adset,       setAdset]       = useState('all')
  const [showCamp,    setShowCamp]    = useState(false)
  const [showAdset,   setShowAdset]   = useState(false)

  // Flatten all ads from campaigns
  const allAds = useMemo((): Ad[] => {
    return campaigns.flatMap((c: any) =>
      (c.adSets || []).flatMap((as: any) =>
        (as.ads || []).map((ad: any) => ({
          ...ad,
          campaign_id:        c.id,
          campaign_name:      c.name,
          campaign_objective: c.objective || '',
          adset_name:         as.name,
          platform:           c.platform || 'meta',
          isCtwa:             ad.isCtwa === true,  // only from API
          // Mock WA data for demo — real data comes from funnel-detail API
          // Use real WA data if available (from API); only estimate for demo mode
          waConvs: ad.waConvs !== undefined ? ad.waConvs
            : (!isReal && ad.status === 'ACTIVE' && ad.clicks > 5000 ? Math.round(ad.clicks * 0.022) : 0),
          ctwa: ad.ctwa !== undefined ? ad.ctwa
            : (!isReal && ad.status === 'ACTIVE' && ad.clicks > 5000 ? Math.round(ad.clicks * 0.018) : 0),
          cplWa: ad.cplWa !== undefined && ad.cplWa > 0 ? ad.cplWa
            : (!isReal && ad.spend && ad.clicks > 5000 ? parseFloat((ad.spend / Math.round(ad.clicks * 0.022)).toFixed(2)) : 0),
          postUrl: ad.postUrl || 'https://www.instagram.com/p/example/',
        }))
      )
    )
  }, [campaigns])

  // Unique campaigns and adsets for filter dropdowns
  const uniqueCampaigns = useMemo(() => {
    const seen = new Map<string, string>()
    allAds.forEach(a => { if (a.campaign_id && !seen.has(a.campaign_id)) seen.set(a.campaign_id, a.campaign_name || a.campaign_id) })
    return Array.from(seen.entries()).map(([id, name]) => ({ id, name })).sort((a,b) => a.name.localeCompare(b.name))
  }, [allAds])

  const uniqueAdsets = useMemo(() => {
    const seen = new Map<string, string>()
    allAds
      .filter(a => campaign === 'all' || a.campaign_id === campaign)
      .forEach(a => { if (a.adset_name && !seen.has(a.adset_name)) seen.set(a.adset_name, a.adset_name) })
    return Array.from(seen.keys()).sort()
  }, [allAds, campaign])

  // Filter
  const filtered = useMemo(() => {
    return allAds.filter(ad => {
      if (platform  !== 'all' && ad.platform    !== platform)  return false
      if (status    !== 'all' && ad.status      !== status)    return false
      if (campaign  !== 'all' && ad.campaign_id !== campaign)  return false
      if (adset     !== 'all' && ad.adset_name  !== adset)     return false
      // isCtwa: ONLY from API — ad.isCtwa set by destination_type=WHATSAPP in campaigns.ts
      const isCtwaAd = ad.isCtwa === true
      if (objective === 'whatsapp' && !isCtwaAd) return false
      if (objective === 'other'    &&  isCtwaAd) return false
      if (search && !ad.name.toLowerCase().includes(search.toLowerCase()) &&
          !ad.campaign_name?.toLowerCase().includes(search.toLowerCase())) return false
      return true
    })
  }, [allAds, platform, status, campaign, adset, objective, search])

  // Sort
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      const va = (a as any)[sortBy] || 0
      const vb = (b as any)[sortBy] || 0
      // CPL: lower is better
      return sortBy === 'cplWa' ? va - vb : vb - va
    })
  }, [filtered, sortBy])

  const totalSpend = sorted.reduce((s, a) => s + a.spend, 0)
  const totalWA    = sorted.reduce((s, a) => s + (a.waConvs || 0), 0)
  const totalSales = sorted.reduce((s, a) => s + (a.salesDb || 0), 0)
  const totalRev   = sorted.reduce((s, a) => s + (a.revenue || 0), 0)
  const avgRoas    = totalSpend > 0 ? parseFloat((totalRev / totalSpend).toFixed(2)) : 0
  const avgCplWa   = (() => {
    const withWA = sorted.filter(a => (a.waConvs || 0) > 0)
    if (!withWA.length) return 0
    const sp = withWA.reduce((s, a) => s + a.spend, 0)
    const wa = withWA.reduce((s, a) => s + (a.waConvs || 0), 0)
    return wa > 0 ? parseFloat((sp / wa).toFixed(2)) : 0
  })()
  // Dynamic: show WA metrics for CTWA filter, performance metrics for others
  const isWaFilter  = objective === 'whatsapp'
  const isOtherFilt = objective === 'other'

  const currentSort = SORT_OPTIONS.find(o => o.key === sortBy)

  return (
    <div className="flex flex-col gap-4">

      {/* Summary bar — dinâmico conforme filtro */}
      <div className="grid grid-cols-3 gap-3">
        {/* Card 1: WA conversas (filtro WA) ou Compras (filtro outros) ou Total WA (todos) */}
        <div className="card p-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: isOtherFilt ? 'rgba(139,92,246,0.12)' : 'rgba(37,211,102,0.12)', border: isOtherFilt ? '1px solid rgba(139,92,246,0.2)' : '1px solid rgba(37,211,102,0.2)' }}>
            {isOtherFilt ? <ShoppingCart size={16} style={{ color: '#8B5CF6' }} /> : <MessageSquare size={16} style={{ color: '#1DAA5B' }} />}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-xs" style={{ color: '#6B7280' }}>
                {isOtherFilt ? 'Total compras' : 'Total conversas WA'}
              </span>
              {isWaFilter  && <span className="text-xs px-1.5 py-0.5 rounded font-bold" style={{ background: 'rgba(37,211,102,0.15)', color: '#1DAA5B' }}>CTWA</span>}
              {isOtherFilt && <span className="text-xs px-1.5 py-0.5 rounded font-bold" style={{ background: 'rgba(217,119,6,0.15)', color: '#D97706' }}>Outras midias</span>}
            </div>
            <div className="text-xl font-black" style={{ color: isOtherFilt ? '#8B5CF6' : '#1DAA5B' }}>
              {isOtherFilt ? fmt.num(totalSales) : fmt.numK(totalWA)}
            </div>
          </div>
        </div>

        {/* Card 2: Total investido (sempre) */}
        <div className="card p-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(30,107,255,0.12)', border: '1px solid rgba(30,107,255,0.2)' }}>
            <DollarSign size={16} style={{ color: '#1E6BFF' }} />
          </div>
          <div>
            <div className="text-xs" style={{ color: '#6B7280' }}>Total investido</div>
            <div className="text-xl font-black text-ink">{fmt.brlK(totalSpend)}</div>
          </div>
        </div>

        {/* Card 3: CPL WA (filtro WA/todos) ou ROAS (filtro outras) */}
        <div className="card p-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: isOtherFilt ? 'rgba(8,145,178,0.12)' : 'rgba(37,211,102,0.12)', border: isOtherFilt ? '1px solid rgba(8,145,178,0.2)' : '1px solid rgba(37,211,102,0.2)' }}>
            {isOtherFilt ? <TrendingUp size={16} style={{ color: '#0891B2' }} /> : <Users size={16} style={{ color: '#1DAA5B' }} />}
          </div>
          <div>
            <div className="text-xs" style={{ color: '#6B7280' }}>
              {isOtherFilt ? 'ROAS medio' : 'CPL WA medio'}
            </div>
            <div className="text-xl font-black" style={{ color: isOtherFilt ? '#0891B2' : (avgCplWa > 0 ? '#1DAA5B' : '#6B7280') }}>
              {isOtherFilt ? fmt.roas(avgRoas) : (avgCplWa > 0 ? fmt.brl(avgCplWa) : '—')}
            </div>
          </div>
        </div>
      </div>

      {/* Filters bar */}
      <div className="card p-3 flex items-center gap-3 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-[180px]">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#6B7280' }} />
          <input className="input-field pl-9 text-sm py-1.5 w-full" placeholder="Buscar criativo ou campanha..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Sort */}
        <div className="relative">
          <button onClick={() => setShowSort(!showSort)}
            className="btn-secondary text-sm py-1.5 flex items-center gap-2">
            <ArrowUpDown size={13} />
            {currentSort?.label}
            <ChevronDown size={12} />
          </button>
          {showSort && (
            <div className="absolute top-full left-0 mt-1 card py-1 z-50 w-44">
              {SORT_OPTIONS.map(o => (
                <button key={o.key} onClick={() => { setSortBy(o.key); setShowSort(false) }}
                  className="w-full text-left px-3 py-2 text-sm transition-colors"
                  style={{ color: sortBy===o.key ? '#1E6BFF' : '#4B5563', background: sortBy===o.key ? 'rgba(30,107,255,0.08)' : 'transparent' }}>
                  {o.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Objective / Type filter — WA vs outras */}
        <div className="flex items-center gap-1 p-1 rounded-lg" style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}>
          {([
            { key: 'all',       label: 'Todos',          color: '#1E6BFF',  bg: 'rgba(30,107,255,0.15)'    },
            { key: 'whatsapp',  label: '💬 WhatsApp',    color: '#1DAA5B',  bg: 'rgba(37,211,102,0.18)'    },
            { key: 'other',     label: '📢 Outras midias',color: '#D97706', bg: 'rgba(217,119,6,0.15)'     },
          ] as { key: FilterObjective; label: string; color: string; bg: string }[]).map(o => (
            <button
              key={o.key}
              onClick={() => setObjective(o.key)}
              className="text-xs px-2.5 py-1 rounded-md font-semibold transition-all whitespace-nowrap"
              style={{
                background: objective === o.key ? o.bg       : 'transparent',
                color:      objective === o.key ? o.color    : '#6B7280',
                border:     objective === o.key ? `1px solid ${o.color}40` : '1px solid transparent',
              }}
            >
              {o.label}
            </button>
          ))}
        </div>

        {/* Platform filter */}
        <div className="flex items-center gap-1 p-1 rounded-lg" style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}>
          {(['all','meta','google','tiktok'] as FilterPlatform[]).map(p => (
            <button key={p} onClick={() => setPlatform(p)}
              className="text-xs px-2.5 py-1 rounded-md font-medium transition-all"
              style={{
                background: platform===p ? (p==='meta' ? 'rgba(24,119,242,0.2)' : p==='google' ? 'rgba(234,67,53,0.2)' : p==='tiktok' ? 'rgba(255,0,80,0.2)' : 'rgba(30,107,255,0.15)') : 'transparent',
                color:      platform===p ? (p==='meta' ? '#1877F2' : p==='google' ? '#DC2626' : p==='tiktok' ? '#E11D48' : '#1E6BFF') : '#6B7280',
              }}>
              {p === 'all' ? 'Todas' : p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-1 p-1 rounded-lg" style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}>
          {(['all','ACTIVE','PAUSED'] as FilterStatus[]).map(s => (
            <button key={s} onClick={() => setStatus(s)}
              className="text-xs px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1"
              style={{
                background: status===s ? (s==='ACTIVE' ? 'rgba(22,163,74,0.15)' : s==='PAUSED' ? 'rgba(90,96,128,0.15)' : 'rgba(30,107,255,0.15)') : 'transparent',
                color:      status===s ? (s==='ACTIVE' ? '#16A34A' : s==='PAUSED' ? '#4B5563' : '#1E6BFF') : '#6B7280',
              }}>
              {s === 'ACTIVE' ? <><CheckCircle2 size={10}/> Ativos</> : s === 'PAUSED' ? <><Clock size={10}/> Pausados</> : 'Todos'}
            </button>
          ))}
        </div>

        {/* Campaign filter */}
        <div className="relative">
          <button
            onClick={() => { setShowCamp(!showCamp); setShowAdset(false) }}
            className="btn-secondary text-xs py-1.5 flex items-center gap-1.5 max-w-[180px]"
          >
            <span className="truncate">{campaign === 'all' ? 'Todas as campanhas' : uniqueCampaigns.find(c => c.id === campaign)?.name?.slice(0,20) + '…'}</span>
            <ChevronDown size={11} className="flex-shrink-0" />
          </button>
          {showCamp && (
            <div className="absolute top-full left-0 mt-1 card py-1 z-50 min-w-[240px] max-h-64 overflow-y-auto">
              <button className="w-full text-left px-3 py-2 text-xs transition-colors"
                style={{ color: campaign==='all'?'#1E6BFF':'#4B5563', background: campaign==='all'?'rgba(30,107,255,0.08)':'transparent' }}
                onClick={() => { setCampaign('all'); setAdset('all'); setShowCamp(false) }}>
                Todas as campanhas
              </button>
              {uniqueCampaigns.map(camp => (
                <button key={camp.id} className="w-full text-left px-3 py-2 text-xs transition-colors"
                  style={{ color: campaign===camp.id?'#1E6BFF':'#4B5563', background: campaign===camp.id?'rgba(30,107,255,0.08)':'transparent' }}
                  onClick={() => { setCampaign(camp.id); setAdset('all'); setShowCamp(false) }}>
                  <span className="truncate block">{camp.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Adset filter — only when campaign selected */}
        {campaign !== 'all' && uniqueAdsets.length > 1 && (
          <div className="relative">
            <button
              onClick={() => { setShowAdset(!showAdset); setShowCamp(false) }}
              className="btn-secondary text-xs py-1.5 flex items-center gap-1.5 max-w-[180px]"
            >
              <span className="truncate">{adset === 'all' ? 'Todos os conjuntos' : adset.slice(0,20) + (adset.length > 20 ? '…' : '')}</span>
              <ChevronDown size={11} className="flex-shrink-0" />
            </button>
            {showAdset && (
              <div className="absolute top-full left-0 mt-1 card py-1 z-50 min-w-[240px] max-h-64 overflow-y-auto">
                <button className="w-full text-left px-3 py-2 text-xs transition-colors"
                  style={{ color: adset==='all'?'#1E6BFF':'#4B5563', background: adset==='all'?'rgba(30,107,255,0.08)':'transparent' }}
                  onClick={() => { setAdset('all'); setShowAdset(false) }}>
                  Todos os conjuntos
                </button>
                {uniqueAdsets.map(as => (
                  <button key={as} className="w-full text-left px-3 py-2 text-xs transition-colors"
                    style={{ color: adset===as?'#1E6BFF':'#4B5563', background: adset===as?'rgba(30,107,255,0.08)':'transparent' }}
                    onClick={() => { setAdset(as); setShowAdset(false) }}>
                    <span className="truncate block">{as}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Count */}
        <div className="text-xs ml-auto flex-shrink-0" style={{ color: '#6B7280' }}>
          {sorted.length} criativo{sorted.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* List */}
      {sorted.length === 0 ? (
        <div className="card p-12 flex flex-col items-center justify-center text-center">
          <Eye size={32} style={{ color: '#9CA3AF' }} className="mb-3" />
          <div className="text-sm font-semibold text-ink mb-1">Nenhum criativo encontrado</div>
          <p className="text-xs max-w-xs" style={{ color: '#6B7280' }}>
            {!isReal ? 'Conecte o Meta Ads para ver seus criativos reais com métricas de WhatsApp.' : 'Tente ajustar os filtros.'}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {sorted.map((ad, i) => <CreativeCard key={ad.id} ad={ad} rank={i + 1} />)}
        </div>
      )}
    </div>
  )
}
