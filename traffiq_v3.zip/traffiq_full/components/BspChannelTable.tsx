import { useState } from 'react'
import { ArrowUpDown, MessageSquare } from 'lucide-react'
import { BspChannel } from '@/lib/mockBspData'
import { fmt } from '@/lib/format'

type SortKey = keyof BspChannel
interface Props { channels: BspChannel[] }

function Badge({ value, thresholds }: { value: number; thresholds: [number, number] }) {
  const color = value >= thresholds[1] ? '#16A34A' : value >= thresholds[0] ? '#D97706' : '#DC2626'
  return (
    <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-md text-xs font-bold min-w-[52px]"
      style={{ background: `${color}18`, color, border: `1px solid ${color}30` }}>
      {value.toFixed(1)}%
    </span>
  )
}

export default function BspChannelTable({ channels }: Props) {
  const [sortKey,  setSortKey]  = useState<SortKey>('conversoes')
  const [sortDesc, setSortDesc] = useState(true)

  const sorted = [...channels].sort((a, b) => {
    const va = a[sortKey] as number
    const vb = b[sortKey] as number
    return sortDesc ? vb - va : va - vb
  })

  function handleSort(key: SortKey) {
    if (key === sortKey) setSortDesc(!sortDesc)
    else { setSortKey(key); setSortDesc(true) }
  }

  const Th = ({ label, k, right }: { label: string; k: SortKey; right?: boolean }) => (
    <th className={`text-right cursor-pointer select-none whitespace-nowrap ${right ? 'text-right' : ''}`}
      onClick={() => handleSort(k)}>
      <div className={`flex items-center gap-1 ${right ? 'justify-end' : 'justify-start'}`}>
        <span>{label}</span>
        <ArrowUpDown size={10} style={{ color: sortKey === k ? '#1E6BFF' : '#6B7280' }} />
      </div>
    </th>
  )

  return (
    <div className="overflow-x-auto">
      <table className="data-table w-full">
        <thead>
          <tr>
            <th className="text-left">Tracking</th>
            <th className="text-left">Source</th>
            <Th label="% Engaj."     k="engajamento"  right />
            <Th label="% Elegib."    k="elegibilidade" right />
            <Th label="% Conv. Eleg."k="convElegivel"  right />
            <Th label="Ticket Médio" k="ticketMedio"   right />
            <Th label="Taxa Mensal"  k="taxaMensal"    right />
            <Th label="Disparos"     k="disparos"      right />
            <Th label="Sessões"      k="sessoes"       right />
            <Th label="Conversões"   k="conversoes"    right />
          </tr>
        </thead>
        <tbody>
          {sorted.map(ch => (
            <tr key={ch.tracking}>
              <td>
                <div className="flex items-center gap-2">
                  <MessageSquare size={12} style={{ color:'#1DAA5B', flexShrink:0 }} />
                  <span className="text-ink font-medium text-xs">{ch.tracking}</span>
                </div>
              </td>
              <td>
                <span className="text-xs px-2 py-0.5 rounded-md"
                  style={{
                    background: ch.source === 'Orgânico' ? 'rgba(22,163,74,0.1)' : 'rgba(30,107,255,0.1)',
                    color:      ch.source === 'Orgânico' ? '#16A34A' : '#1E6BFF',
                  }}>
                  {ch.source}
                </span>
              </td>
              <td className="text-right">
                {ch.engajamento > 0
                  ? <Badge value={ch.engajamento} thresholds={[20, 40]} />
                  : <span style={{ color:'#6B7280' }}>—</span>}
              </td>
              <td className="text-right"><Badge value={ch.elegibilidade} thresholds={[10, 30]} /></td>
              <td className="text-right"><Badge value={ch.convElegivel}  thresholds={[10, 20]} /></td>
              <td className="text-right">
                <span className="text-sm font-semibold text-ink">{fmt.brl(ch.ticketMedio)}</span>
              </td>
              <td className="text-right">
                <span className="text-sm" style={{ color:'#4B5563' }}>{ch.taxaMensal.toFixed(2)}%</span>
              </td>
              <td className="text-right">
                <span className="text-sm" style={{ color:'#4B5563' }}>{fmt.numK(ch.disparos)}</span>
              </td>
              <td className="text-right">
                <span className="text-sm" style={{ color:'#4B5563' }}>{fmt.numK(ch.sessoes)}</span>
              </td>
              <td className="text-right">
                <span className="text-sm font-bold text-ink">{fmt.numK(ch.conversoes)}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
