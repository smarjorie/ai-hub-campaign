import { useMemo } from 'react'
import {
  MessageSquare, DollarSign, TrendingUp, ShoppingCart,
  Send, Users, Zap, ExternalLink, ArrowRight, BarChart2,
} from 'lucide-react'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis,
  CartesianGrid, Tooltip, ComposedChart, Bar,
} from 'recharts'
import { fmt } from '@/lib/format'
import { genBspTimeline, bspSummary } from '@/lib/mockBspData'

interface Props {
  campaigns: any[]
  summary:   any
  timeline:  any[]
  metaStatus: string
  onGoIntegrations: () => void
  onGoCreatives: () => void
}

function KPI({ label, value, sub, color = '#1E6BFF', icon: Icon }: {
  label: string; value: string; sub?: string; color?: string; icon: any
}) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="metric-label">{label}</span>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: `${color}18`, border: `1px solid ${color}25` }}>
          <Icon size={14} style={{ color }} />
        </div>
      </div>
      <div className="metric-value">{value}</div>
      {sub && <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>{sub}</div>}
    </div>
  )
}

const ChartTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="card p-3 min-w-[140px]">
      <div className="text-xs mb-2" style={{ color: '#4B5563' }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color || p.fill }} />
            <span className="text-xs" style={{ color: '#4B5563' }}>{p.name}</span>
          </div>
          <span className="text-xs font-semibold text-ink">
            {p.name?.includes('Invest') || p.name?.includes('Receita') ? fmt.brlK(p.value) : fmt.numK(p.value)}
          </span>
        </div>
      ))}
    </div>
  )
}

export default function HybridView({ campaigns, summary, timeline, metaStatus, onGoCreatives }: Props) {
  const bspTimeline = useMemo(() => genBspTimeline(), [])

  // Merge timelines by date index (both are 30 days)
  const merged = useMemo(() => {
    return timeline.map((d: any, i: number) => ({
      label:     d.label,
      investido: d.spend,
      receita:   d.revenue,
      sessoes:   bspTimeline[i]?.sessoes  || 0,
      disparos:  bspTimeline[i]?.disparos || 0,
    }))
  }, [timeline, bspTimeline])

  // Top WA creatives (ads with waConvs > 0)
  const topWaCreatives = useMemo(() => {
    return campaigns
      .flatMap((c: any) => (c.adSets||[]).flatMap((as: any) => (as.ads||[]).map((ad: any) => ({
        ...ad,
        campaign_name: c.name,
        platform: c.platform || 'meta',
        waConvs: ad.waConvs || (ad.status==='ACTIVE' && ad.clicks>5000 ? Math.round(ad.clicks*0.022) : 0),
        cplWa:   ad.cplWa   || (ad.spend && ad.clicks>5000 ? parseFloat((ad.spend/Math.round(ad.clicks*0.022)).toFixed(2)) : 0),
        postUrl: ad.postUrl || 'https://www.instagram.com/p/example/',
      }))))
      .filter((ad: any) => ad.waConvs > 0)
      .sort((a: any, b: any) => b.waConvs - a.waConvs)
      .slice(0, 6)
  }, [campaigns])

  const totalWaConvs = topWaCreatives.reduce((s: number, a: any) => s + a.waConvs, 0)
  const maxWa = topWaCreatives[0]?.waConvs || 1

  return (
    <div className="flex flex-col gap-5">

      {/* Section title */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'rgba(217,119,6,0.15)', border: '1px solid rgba(217,119,6,0.25)' }}>
          <Zap size={15} style={{ color: '#D97706' }} />
        </div>
        <div>
          <div className="text-lg font-bold text-ink">Visão Híbrida</div>
          <div className="text-xs" style={{ color: '#6B7280' }}>Tráfego Pago + WhatsApp CRM — análise integrada</div>
        </div>
      </div>

      {/* KPIs — two worlds */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-4 rounded-full" style={{ background: '#1E6BFF' }} />
          <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#4B5563' }}>Tráfego Pago (Meta/Google)</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
          <KPI label="Investido"  value={fmt.brlK(summary.spend)}    icon={DollarSign}  color="#1E6BFF" />
          <KPI label="Receita"    value={fmt.brlK(summary.revenue)}  icon={TrendingUp}  color="#16A34A" sub={`ROAS ${fmt.roas(summary.roas)}`} />
          <KPI label="Cliques"    value={fmt.numK(summary.clicks)}   icon={BarChart2}   color="#0891B2" />
          <KPI label="Compras"    value={fmt.num(summary.salesDb)}   icon={ShoppingCart} color="#8B5CF6" />
        </div>

        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-4 rounded-full" style={{ background: '#1DAA5B' }} />
          <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#4B5563' }}>WhatsApp CRM (BSP)</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <KPI label="Disparos"      value={fmt.numK(bspSummary.disparos)}           icon={Send}         color="#1DAA5B" />
          <KPI label="Sessões WA"    value={fmt.numK(bspSummary.sessoes)}            icon={MessageSquare} color="#1DAA5B" />
          <KPI label="Conversões WA" value={fmt.numK(Math.round(bspSummary.sessoes*bspSummary.conversao/100))} icon={Users} color="#1DAA5B" sub={`${bspSummary.conversao}% taxa`} />
          <KPI label="Ticket Médio"  value={fmt.brl(bspSummary.ticketMedio)}         icon={TrendingUp}    color="#D97706" />
        </div>
      </div>

      {/* Merged timeline */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="section-title">Timeline unificada — 30 dias</div>
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5"><div className="w-2.5 h-0.5 rounded" style={{ background:'#1E6BFF' }}/><span style={{ color:'#4B5563' }}>Investido</span></div>
            <div className="flex items-center gap-1.5"><div className="w-2.5 h-0.5 rounded" style={{ background:'#16A34A' }}/><span style={{ color:'#4B5563' }}>Receita</span></div>
            <div className="flex items-center gap-1.5"><div className="w-2.5 h-0.5 rounded" style={{ background:'#1DAA5B' }}/><span style={{ color:'#4B5563' }}>Sessões WA</span></div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={merged} margin={{ top:5, right:10, left:0, bottom:0 }}>
            <defs>
              {[['ads1','#1E6BFF'],['ads2','#16A34A'],['bsp','#1DAA5B']].map(([id,c])=>(
                <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor={c} stopOpacity={0.2}/>
                  <stop offset="95%" stopColor={c} stopOpacity={0}/>
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(230,232,236,0.8)"/>
            <XAxis dataKey="label" tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} interval={4}/>
            <YAxis tick={{ fill:'#6B7280', fontSize:10 }} axisLine={false} tickLine={false} width={44}/>
            <Tooltip content={<ChartTip/>}/>
            <Area type="monotone" dataKey="investido" name="Investido" stroke="#1E6BFF" strokeWidth={1.5} fill="url(#ads1)" dot={false}/>
            <Area type="monotone" dataKey="receita"   name="Receita"   stroke="#16A34A" strokeWidth={1.5} fill="url(#ads2)" dot={false}/>
            <Area type="monotone" dataKey="sessoes"   name="Sessões WA" stroke="#1DAA5B" strokeWidth={1.5} fill="url(#bsp)"  dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Top WA Creatives */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="section-title flex items-center gap-2">
              <MessageSquare size={16} style={{ color: '#1DAA5B' }} />
              Top criativos que geram WhatsApp
            </div>
            <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>
              {fmt.numK(totalWaConvs)} conversas WA geradas pelos criativos abaixo
            </div>
          </div>
          <button onClick={onGoCreatives}
            className="flex items-center gap-1.5 text-xs font-medium transition-colors"
            style={{ color: '#1DAA5B' }}>
            Ver ranking completo <ArrowRight size={12}/>
          </button>
        </div>

        {topWaCreatives.length === 0 ? (
          <div className="text-center py-8 text-sm" style={{ color: '#6B7280' }}>
            {metaStatus !== 'real' ? 'Conecte o Meta Ads para ver os criativos que geram conversas WA.' : 'Nenhum criativo com dados de WA.'}
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {topWaCreatives.map((ad: any, i: number) => (
              <div key={ad.id} className="flex items-center gap-4 p-3 rounded-xl transition-all"
                style={{ background: '#F7F8FA', border: '1px solid #E6E8EC' }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(37,211,102,0.25)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = '#E6E8EC')}>

                {/* Rank */}
                <span className="text-sm font-black flex-shrink-0 w-5 text-center"
                  style={{ color: i < 3 ? '#D97706' : '#6B7280' }}>#{i+1}</span>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-ink truncate">{ad.name}</div>
                  <div className="text-xs truncate" style={{ color: '#6B7280' }}>{ad.campaign_name?.slice(0,45)}</div>
                </div>

                {/* WA bar */}
                <div className="flex-1 max-w-[120px]">
                  <div className="h-2 rounded-full" style={{ background: '#E6E8EC' }}>
                    <div className="h-full rounded-full transition-all"
                      style={{ width: `${(ad.waConvs/maxWa)*100}%`, background: 'linear-gradient(90deg,#1DAA5B,#128C7E)' }}/>
                  </div>
                </div>

                {/* Metrics */}
                <div className="flex items-center gap-4 flex-shrink-0">
                  <div className="text-right">
                    <div className="text-xs" style={{ color: '#1DAA5B' }}>Conversas</div>
                    <div className="text-base font-black" style={{ color: '#1DAA5B' }}>{fmt.numK(ad.waConvs)}</div>
                  </div>
                  <div className="text-right hidden sm:block">
                    <div className="text-xs" style={{ color: '#6B7280' }}>CPL WA</div>
                    <div className="text-sm font-bold text-ink">{fmt.brl(ad.cplWa)}</div>
                  </div>
                  <div className="text-right hidden md:block">
                    <div className="text-xs" style={{ color: '#6B7280' }}>ROAS</div>
                    <div className="text-sm font-bold" style={{ color: ad.roas >= 5 ? '#16A34A' : ad.roas >= 3 ? '#D97706' : '#DC2626' }}>{fmt.roas(ad.roas)}</div>
                  </div>
                  {ad.postUrl && (
                    <a href={ad.postUrl} target="_blank" rel="noreferrer"
                      className="flex-shrink-0 p-1.5 rounded-lg transition-all"
                      style={{ background: 'rgba(37,211,102,0.1)', color: '#1DAA5B' }}
                      onMouseEnter={e => (e.currentTarget.style.background='rgba(37,211,102,0.2)')}
                      onMouseLeave={e => (e.currentTarget.style.background='rgba(37,211,102,0.1)')}>
                      <ExternalLink size={13}/>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
