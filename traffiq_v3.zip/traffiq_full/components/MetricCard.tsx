import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react'
import { fmt } from '@/lib/format'

interface Props {
  label: string
  value: string
  change?: number
  sub?: string
  icon?: LucideIcon
  color?: string
  sparkline?: number[]
  badge?: string
  badgeColor?: string
}

export default function MetricCard({ label, value, change, sub, icon: Icon, color = '#1E6BFF', sparkline, badge, badgeColor = 'badge-blue' }: Props) {
  const chg = change !== undefined ? fmt.change(change) : null

  // mini sparkline SVG
  const spark = sparkline && sparkline.length > 1 ? (() => {
    const max = Math.max(...sparkline), min = Math.min(...sparkline)
    const range = max - min || 1
    const w = 80, h = 28
    const pts = sparkline.map((v, i) => `${(i / (sparkline.length - 1)) * w},${h - ((v - min) / range) * h}`)
    return pts.join(' ')
  })() : null

  return (
    <div className="card-hover p-4 flex flex-col gap-3 animate-fade-up">
      <div className="flex items-start justify-between">
        <span className="metric-label">{label}</span>
        <div className="flex items-center gap-2">
          {badge && <span className={badgeColor}>{badge}</span>}
          {Icon && (
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: `${color}1A`, border: `1px solid ${color}30` }}>
              <Icon size={14} style={{ color }} />
            </div>
          )}
        </div>
      </div>

      <div className="flex items-end justify-between gap-2">
        <div>
          <div className="metric-value">{value}</div>
          {sub && <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>{sub}</div>}
        </div>
        {spark && (
          <svg width={80} height={28} viewBox={`0 0 80 28`} className="opacity-70">
            <polyline
              points={spark}
              fill="none"
              stroke={color}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </div>

      {chg && (
        <div className="flex items-center gap-1.5">
          {change! >= 0
            ? <TrendingUp size={12} style={{ color: '#16A34A' }} />
            : <TrendingDown size={12} style={{ color: '#DC2626' }} />
          }
          <span className={chg.cls}>{chg.text}</span>
          <span className="text-xs" style={{ color: '#6B7280' }}>vs. mês anterior</span>
        </div>
      )}
    </div>
  )
}
