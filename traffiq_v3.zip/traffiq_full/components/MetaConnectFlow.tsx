import { useState } from 'react'
import {
  Eye, EyeOff, Check, X, RefreshCw, ExternalLink,
  ChevronDown, AlertCircle, CheckCircle2, Wifi, WifiOff,
} from 'lucide-react'

interface Account { id: string; name: string; status: number; currency: string }

interface Props {
  token:        string
  accountId:    string
  accountName?: string
  source:       string
  userName:     string
  accounts?:    Account[]
  onConnect:    (token: string, accountId: string) => void
  onDisconnect: () => void
  onSwitch?:    (accountId: string) => void
  validateToken:(token: string) => Promise<{ valid: boolean; accounts: Account[]; userName: string; error?: string }>
}

const ACCOUNT_STATUS: Record<number, { label: string; cls: string }> = {
  1: { label: 'Ativa',         cls: 'badge-green'  },
  2: { label: 'Desativada',    cls: 'badge-red'     },
  3: { label: 'Inadimplente',  cls: 'badge-yellow'  },
  7: { label: 'Em revisão',    cls: 'badge-yellow'  },
  9: { label: 'Fechada',       cls: 'badge-red'     },
}

export default function MetaConnectFlow({ token: currentToken, accountId: currentAccount, accountName, source, userName, accounts: existingAccounts, onConnect, onDisconnect, onSwitch, validateToken }: Props) {
  const [step, setStep] = useState<'idle'|'input'|'validating'|'choose'|'connecting'>(
    currentToken ? 'idle' : 'idle'
  )
  const [token,    setToken]    = useState('')
  const [show,     setShow]     = useState(false)
  const [accounts, setAccounts] = useState<Account[]>([])
  const [selected, setSelected] = useState('')
  const [valUser,  setValUser]  = useState('')
  const [error,    setError]    = useState('')
  const [open,     setOpen]     = useState(false)

  const isConnected = source === 'real'
  const isLoading   = source === 'loading'

  async function handleValidate() {
    if (!token.trim()) return
    setStep('validating')
    setError('')
    const result = await validateToken(token.trim())
    if (!result.valid) {
      setError(result.error || 'Token inválido')
      setStep('input')
      return
    }
    setAccounts(result.accounts)
    setValUser(result.userName)
    setStep('choose')
  }

  async function handleConnect() {
    if (!selected) return
    setStep('connecting')
    await onConnect(token.trim(), selected)
    setStep('idle')
    setToken('')
  }

  function handleDisconnect() {
    onDisconnect()
    setStep('idle')
    setToken('')
    setAccounts([])
    setSelected('')
    setError('')
  }

  // ─── Connected state ────────────────────────────────────────────────────────
  if (isConnected || isLoading) {
    return (
      <div className="card p-5">
        <div className="flex items-center gap-4">
          {/* Meta icon */}
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
            style={{ background: 'rgba(24,119,242,0.15)', color: '#1877F2', border: '1px solid rgba(24,119,242,0.2)' }}>
            ∞
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="font-semibold text-ink">Meta Ads</span>
              {isLoading
                ? <span className="badge-yellow"><RefreshCw size={10} className="animate-spin" /> Carregando...</span>
                : <span className="badge-green"><span className="status-active mr-1" />Conectado</span>
              }
            </div>
            {!isLoading && (
              <div className="text-xs mb-2" style={{ color: '#4B5563' }}>
                <span style={{ color: '#6B7280' }}>Usuário:</span> {userName} &nbsp;·&nbsp;
                <span style={{ color: '#6B7280' }}>Conta:</span> {accountName || currentAccount}
              </div>
            )}
            {!isLoading && (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 text-xs" style={{ color: '#16A34A' }}>
                  <Wifi size={12} /> Dados em tempo real
                </div>
                <span style={{ color: '#E6E8EC' }}>·</span>
                <button onClick={handleDisconnect} className="flex items-center gap-1 text-xs transition-colors"
                  style={{ color: '#6B7280' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#DC2626')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#6B7280')}>
                  <WifiOff size={11} /> Desconectar
                </button>
              </div>
            )}
          </div>
          {isLoading && <RefreshCw size={18} className="animate-spin flex-shrink-0" style={{ color: '#1E6BFF' }} />}
        </div>
      </div>
    )
  }

  // ─── Disconnected ─────────────────────────────────────────────────────────
  return (
    <div className="card p-5 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg flex-shrink-0"
          style={{ background: 'rgba(24,119,242,0.1)', color: '#1877F2', border: '1px solid rgba(24,119,242,0.15)' }}>
          ∞
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-ink">Meta Ads</span>
            <span className="badge" style={{ background:'rgba(90,96,128,0.12)', color:'#6B7280', border:'1px solid rgba(90,96,128,0.15)', fontSize:10 }}>Desconectado</span>
          </div>
          <p className="text-xs mt-0.5" style={{ color: '#6B7280' }}>Cole seu Access Token para buscar dados reais das suas campanhas</p>
        </div>
      </div>

      {/* Step: IDLE → show input */}
      {step === 'idle' && (
        <button className="btn-primary w-fit" onClick={() => setStep('input')}>
          Conectar com Meta Ads
        </button>
      )}

      {/* Step: INPUT token */}
      {(step === 'input' || step === 'validating') && (
        <div className="flex flex-col gap-3">
          <div>
            <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Access Token</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type={show ? 'text' : 'password'}
                  placeholder="EAAxxxxxxxxxxxxx..."
                  value={token}
                  onChange={e => { setToken(e.target.value); setError('') }}
                  onKeyDown={e => { if (e.key === 'Enter') handleValidate() }}
                  className="input-field pr-10 font-mono text-sm"
                  autoFocus
                />
                <button onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: '#6B7280' }}>
                  {show ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
              <button
                onClick={handleValidate}
                disabled={!token.trim() || step === 'validating'}
                className="btn-primary px-4 py-2 min-w-[100px] justify-center"
              >
                {step === 'validating'
                  ? <><RefreshCw size={13} className="animate-spin" /> Validando</>
                  : <><Check size={13} /> Validar</>
                }
              </button>
              <button onClick={() => { setStep('idle'); setToken(''); setError('') }} className="btn-ghost px-3">
                <X size={14} />
              </button>
            </div>

            {error && (
              <div className="flex items-center gap-2 mt-2 text-xs" style={{ color: '#DC2626' }}>
                <AlertCircle size={13} /> {error}
              </div>
            )}
          </div>

          <a href="https://developers.facebook.com/tools/explorer/" target="_blank" rel="noreferrer"
            className="flex items-center gap-1.5 text-xs w-fit transition-colors"
            style={{ color: '#6B7280' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#1877F2')}
            onMouseLeave={e => (e.currentTarget.style.color = '#6B7280')}>
            <ExternalLink size={11} />
            Como obter meu Access Token no Meta for Developers
          </a>
        </div>
      )}

      {/* Step: CHOOSE account */}
      {(step === 'choose' || step === 'connecting') && (
        <div className="flex flex-col gap-3">
          {/* Validation success */}
          <div className="flex items-center gap-2 text-xs py-2 px-3 rounded-xl"
            style={{ background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.15)' }}>
            <CheckCircle2 size={13} style={{ color: '#16A34A' }} />
            <span style={{ color: '#16A34A' }}>Token válido</span>
            <span style={{ color: '#6B7280' }}>·</span>
            <span style={{ color: '#4B5563' }}>{valUser}</span>
            <span style={{ color: '#6B7280' }}>·</span>
            <span style={{ color: '#4B5563' }}>{accounts.length} conta{accounts.length !== 1 ? 's' : ''} encontrada{accounts.length !== 1 ? 's' : ''}</span>
          </div>

          {/* Account selector */}
          <div>
            <label className="text-xs mb-1.5 block font-medium" style={{ color: '#4B5563' }}>Selecione a conta de anúncios</label>
            <div className="relative">
              <button
                onClick={() => setOpen(!open)}
                className="input-field flex items-center justify-between w-full text-left"
                style={{ cursor: 'pointer' }}
              >
                <span style={{ color: selected ? '#111827' : '#6B7280' }}>
                  {selected
                    ? accounts.find(a => a.id === selected)?.name || selected
                    : 'Escolha uma conta...'
                  }
                </span>
                <ChevronDown size={14} style={{ color: '#6B7280', flexShrink: 0 }} />
              </button>

              {open && (
                <div className="absolute top-full left-0 right-0 mt-1 card py-1 z-50 max-h-48 overflow-y-auto">
                  {accounts.map(a => {
                    const st = ACCOUNT_STATUS[a.status] || { label: String(a.status), cls: 'badge-yellow' }
                    return (
                      <button
                        key={a.id}
                        onClick={() => { setSelected(a.id); setOpen(false) }}
                        className="w-full flex items-center justify-between px-3 py-2.5 text-left transition-colors"
                        style={{ background: selected === a.id ? 'rgba(30,107,255,0.1)' : 'transparent' }}
                        onMouseEnter={e => { if (selected !== a.id) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.03)' }}
                        onMouseLeave={e => { if (selected !== a.id) (e.currentTarget as HTMLElement).style.background = 'transparent' }}
                      >
                        <div>
                          <div className="text-sm font-medium text-ink">{a.name}</div>
                          <div className="text-xs mt-0.5" style={{ color: '#6B7280' }}>{a.id} · {a.currency}</div>
                        </div>
                        <span className={st.cls}>{st.label}</span>
                      </button>
                    )
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleConnect}
              disabled={!selected || step === 'connecting'}
              className="btn-primary py-2 px-5"
            >
              {step === 'connecting'
                ? <><RefreshCw size={13} className="animate-spin" /> Conectando...</>
                : <><Wifi size={13} /> Conectar e Carregar Dados</>
              }
            </button>
            <button onClick={() => { setStep('input'); setSelected('') }} className="btn-ghost py-2 px-3 text-sm">
              Voltar
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
