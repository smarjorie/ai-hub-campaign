import type { NextApiRequest, NextApiResponse } from 'next'
import { supabase } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (!supabase) return res.status(200).json({ mode: 'mock', sales: [] })
  const { data, error } = await supabase.from('sales').select('*').order('created_at', { ascending: false }).limit(100)
  if (error) return res.status(500).json({ error: error.message })
  return res.status(200).json({ sales: data })
}
