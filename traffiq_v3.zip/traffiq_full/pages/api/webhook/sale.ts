import type { NextApiRequest, NextApiResponse } from 'next'
import { supabase } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const secret = process.env.WEBHOOK_SECRET
  if (secret && req.headers['x-webhook-secret'] !== secret) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  const { sale_id, value, campaign_id, adset_id, ad_id, platform = 'meta' } = req.body

  if (!sale_id)     return res.status(400).json({ error: 'Missing field: sale_id' })
  if (!value)       return res.status(400).json({ error: 'Missing field: value' })
  if (!campaign_id) return res.status(400).json({ error: 'Missing field: campaign_id' })
  if (!adset_id)    return res.status(400).json({ error: 'Missing field: adset_id' })
  if (!ad_id)       return res.status(400).json({ error: 'Missing field: ad_id' })

  if (!supabase) {
    return res.status(200).json({ mode: 'mock', received: { sale_id, value, campaign_id, adset_id, ad_id, platform } })
  }

  const { error } = await supabase.from('sales').insert({ sale_id, value, campaign_id, adset_id, ad_id, platform })

  if (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Duplicate sale_id' })
    return res.status(500).json({ error: error.message })
  }

  return res.status(201).json({ ok: true, sale_id })
}
