import type { NextApiRequest, NextApiResponse } from 'next'
import { runAgent, type ChatTurn } from '@/lib/agent'
import { serverOrigin } from '@/lib/serverOrigin'

// POST { messages: ChatTurn[], creds?: UserCreds }
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST.' })
  const { messages, creds } = req.body || {}
  const turns: ChatTurn[] = Array.isArray(messages)
    ? messages.filter((m: any) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim()).slice(-20)
    : []
  if (!turns.length || turns[turns.length - 1].role !== 'user') return res.status(400).json({ error: 'A conversa precisa terminar com uma mensagem do usuário.' })

  try {
    const result = await runAgent(turns, { origin: serverOrigin(req), creds })
    res.status(200).json(result)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
}

export const config = { maxDuration: 120 }
