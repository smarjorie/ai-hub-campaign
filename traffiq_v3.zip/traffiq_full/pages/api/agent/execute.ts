import type { NextApiRequest, NextApiResponse } from 'next'
import { WRITE_TOOLS } from '@/lib/mcp/tools'
import { serverOrigin } from '@/lib/serverOrigin'

// Executa UMA acao de escrita que o usuario confirmou na interface.
// POST { tool, args, creds }
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST.' })
  const { tool: name, args, creds } = req.body || {}
  const tool = WRITE_TOOLS().find(t => t.name === name)
  if (!tool) return res.status(400).json({ error: `Ação não permitida: ${name}` })
  try {
    const result = await tool.run(args || {}, { origin: serverOrigin(req), creds })
    res.status(200).json({ ok: true, result })
  } catch (e: any) {
    res.status(400).json({ ok: false, error: e.message })
  }
}
