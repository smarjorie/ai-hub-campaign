import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

async function fetchAllPages(url: string, params: Record<string, string>): Promise<any[]> {
  const results: any[] = []
  let nextUrl: string | null = url
  let nextParams: Record<string, string> | null = params
  while (nextUrl) {
    const q: string = nextParams ? nextUrl + '?' + new URLSearchParams(nextParams) : nextUrl
    const r = await fetch(q)
    const d: any = await r.json()
    if (d.error) throw new Error(d.error.message)
    results.push(...(d.data || []))
    nextUrl = d.paging?.next || null
    nextParams = null
  }
  return results
}

const FUNNEL_ACTIONS: Record<string, string[]> = {
  clicks:     ['link_click', 'landing_page_view', 'onsite_conversion.messaging_conversation_started_7d', 'onsite_conversion.total_messaging_connection'],
  page_views: ['landing_page_view', 'onsite_conversion.messaging_conversation_started_7d'],
  add_to_cart:['add_to_cart', 'omni_add_to_cart', 'offsite_conversion.fb_pixel_add_to_cart'],
  checkouts:  ['initiate_checkout', 'omni_initiated_checkout', 'offsite_conversion.fb_pixel_initiate_checkout', 'onsite_conversion.messaging_first_reply'],
  purchases:  ['purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase', 'website_purchase', 'onsite_conversion.messaging_conversation_started_7d'],
  leads:      ['lead', 'omni_lead', 'offsite_conversion.fb_pixel_lead', 'onsite_conversion.lead_grouped', 'onsite_conversion.messaging_conversation_started_7d', 'onsite_conversion.total_messaging_connection', 'onsite_conversion.messaging_first_reply'],
}

const WA_TYPES = new Set([
  'onsite_conversion.messaging_conversation_started_7d',
  'onsite_conversion.total_messaging_connection',
  'onsite_conversion.messaging_first_reply',
  'onsite_conversion.messaging_block',
  'click_to_whatsapp_all',
])

const ACTION_LABELS: Record<string, string> = {
  'link_click':                                          'Cliques no link',
  'landing_page_view':                                   'Visualizações de página',
  'add_to_cart':                                         'Add to cart',
  'omni_add_to_cart':                                    'Add to cart (omni)',
  'offsite_conversion.fb_pixel_add_to_cart':             'Add to cart (Pixel)',
  'initiate_checkout':                                   'Checkout iniciado',
  'omni_initiated_checkout':                             'Checkout iniciado (omni)',
  'offsite_conversion.fb_pixel_initiate_checkout':       'Checkout iniciado (Pixel)',
  'purchase':                                            'Compra',
  'omni_purchase':                                       'Compra (omni)',
  'offsite_conversion.fb_pixel_purchase':                'Compra (Pixel)',
  'website_purchase':                                    'Compra no site',
  'lead':                                                'Lead',
  'omni_lead':                                           'Lead (omni)',
  'offsite_conversion.fb_pixel_lead':                    'Lead (Pixel)',
  'onsite_conversion.lead_grouped':                      'Lead (on-site)',
  'onsite_conversion.messaging_conversation_started_7d': 'Conversa iniciada WA (7d)',
  'onsite_conversion.total_messaging_connection':        'Conexão de mensagem total',
  'onsite_conversion.messaging_first_reply':             'Primeira resposta WA',
  'onsite_conversion.messaging_block':                   'Bloqueio WA',
  'click_to_whatsapp_all':                               'Clique para WhatsApp (CTWA)',
}

// publisher_platform é um breakdown válido sozinho no level=account
const PLATFORM_LABELS: Record<string, string> = {
  'facebook':         'Facebook',
  'instagram':        'Instagram',
  'audience_network': 'Audience Network',
  'messenger':        'Messenger',
  'whatsapp':         'WhatsApp',
}

function sumAction(rows: any[], type: string): number {
  return rows.reduce((s, r) => {
    const f = (r.actions || []).find((a: any) => a.action_type === type)
    return s + parseInt(f?.value || '0', 10)
  }, 0)
}
function sumValue(rows: any[], type: string): number {
  return rows.reduce((s, r) => {
    const f = (r.action_values || []).find((a: any) => a.action_type === type)
    return s + parseFloat(f?.value || '0')
  }, 0)
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token não informado' })

  const { account_id, date_preset = 'last_30d', step = 'purchases' } = req.query as Record<string, string>
  if (!account_id) return res.status(400).json({ error: 'account_id obrigatório' })

  const acctId  = account_id.startsWith('act_') ? account_id : `act_${account_id}`
  const actions = FUNNEL_ACTIONS[step] || FUNNEL_ACTIONS.purchases

  const BASE_FIELDS = 'impressions,clicks,spend,cpm,ctr,actions,action_values'

  try {
    // 1) Totais sem breakdown
    const [totalsRaw] = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token, level: 'account', date_preset,
      fields: BASE_FIELDS, limit: '1',
    }).then(r => [r])

    // 2) Breakdown por publisher_platform (válido em account level)
    const platformRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token, level: 'account', date_preset,
      breakdowns: 'publisher_platform',
      fields: BASE_FIELDS, limit: '20',
    })

    // 3) Breakdown por impression_device (mobile/desktop/etc — válido em account level)
    const deviceRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token, level: 'account', date_preset,
      breakdowns: 'impression_device',
      fields: BASE_FIELDS, limit: '20',
    })

    // 4) Campanhas WhatsApp — level=ad para pegar criativos CTWA
    const waFields = 'campaign_id,campaign_name,adset_id,adset_name,ad_id,ad_name,spend,impressions,clicks,actions,action_values'
    // We'll fetch ad permalinks separately via /ads endpoint
    const waCampaignsRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token, level: 'ad', date_preset,
      fields: waFields, limit: '200',
      // filtra só quem tem ação de WA
    })

    // ── Action breakdown ──────────────────────────────────────────────────────
    const actionBreakdown = actions.map(type => ({
      type, label: ACTION_LABELS[type] || type,
      count: sumAction(totalsRaw, type),
      value: parseFloat(sumValue(totalsRaw, type).toFixed(2)),
      isWhatsApp: WA_TYPES.has(type),
    })).filter(a => a.count > 0)

    const stepTotal = actionBreakdown.reduce((s, a) => s + a.count, 0)

    // ── Platform breakdown ────────────────────────────────────────────────────
    const placements = platformRaw.map(row => {
      const label    = PLATFORM_LABELS[row.publisher_platform] || row.publisher_platform
      const isWA     = row.publisher_platform === 'whatsapp'
      const actCount = actions.reduce((s, type) => s + sumAction([row], type), 0)
      return {
        label,
        impressions: parseInt(row.impressions || '0', 10),
        clicks:      parseInt(row.clicks || '0', 10),
        spend:       parseFloat(parseFloat(row.spend || '0').toFixed(2)),
        actions:     actCount,
        ctr:         parseFloat(row.ctr || '0'),
        cpm:         parseFloat(row.cpm || '0'),
        isWhatsApp:  isWA,
      }
    }).sort((a, b) => b.impressions - a.impressions)

    // ── Device breakdown ──────────────────────────────────────────────────────
    const devices = deviceRaw.map(row => ({
      platform:    row.impression_device,
      impressions: parseInt(row.impressions || '0', 10),
      clicks:      parseInt(row.clicks || '0', 10),
      spend:       parseFloat(parseFloat(row.spend || '0').toFixed(2)),
    })).sort((a, b) => b.impressions - a.impressions)

    // ── WhatsApp campaigns ────────────────────────────────────────────────────
    const WA_ACTION_TYPES = [
      'onsite_conversion.messaging_conversation_started_7d',
      'onsite_conversion.total_messaging_connection',
      'onsite_conversion.messaging_first_reply',
      'click_to_whatsapp_all',
    ]

    // Fetch creative permalinks for WA ads — effective_object_story_id gives the post ID
    const adIds = waCampaignsRaw.map((r: any) => r.ad_id).filter(Boolean).slice(0, 50)
    const adPermalinkMap: Record<string, string> = {}
    const adThumbnailMap: Record<string, string> = {}

    if (adIds.length > 0) {
      try {
        // Batch request for ad creatives
        const adsRes = await fetch(
          `${BASE}/?ids=${adIds.join(',')}&fields=id,creative{effective_object_story_id,thumbnail_url,object_story_spec}&access_token=${token}`
        )
        const adsData = await adsRes.json()
        if (!adsData.error) {
          Object.entries(adsData).forEach(([adId, adObj]: [string, any]) => {
            const creative = adObj?.creative
            if (creative?.effective_object_story_id) {
              // Format: pageId_postId → https://www.facebook.com/permalink.php?story_fbid=postId&id=pageId
              const parts = creative.effective_object_story_id.split('_')
              if (parts.length === 2) {
                adPermalinkMap[adId] = `https://www.facebook.com/permalink.php?story_fbid=${parts[1]}&id=${parts[0]}`
              }
            }
            if (creative?.thumbnail_url) {
              adThumbnailMap[adId] = creative.thumbnail_url
            }
          })
        }
      } catch (_) { /* non-critical, continue without permalinks */ }
    }

    const waCampaigns = waCampaignsRaw
      .map(row => {
        const spend     = parseFloat(row.spend || '0')
        const waConvs   = WA_ACTION_TYPES.reduce((s, t) => s + sumAction([row], t), 0)
        const revenue   = WA_ACTION_TYPES.reduce((s, t) => s + sumValue([row], t), 0)
        const ctwa      = sumAction([row], 'click_to_whatsapp_all')
          || sumAction([row], 'onsite_conversion.messaging_conversation_started_7d')
        const firstReply= sumAction([row], 'onsite_conversion.messaging_first_reply')
        const cpl       = waConvs > 0 ? parseFloat((spend / waConvs).toFixed(2)) : 0
        return {
          campaign_id:   row.campaign_id,
          campaign_name: row.campaign_name,
          adset_name:    row.adset_name,
          ad_id:         row.ad_id,
          ad_name:       row.ad_name,
          spend,
          impressions:   parseInt(row.impressions || '0', 10),
          clicks:        parseInt(row.clicks || '0', 10),
          waConvs, ctwa, firstReply, cpl,
          revenue:       parseFloat(revenue.toFixed(2)),
          permalink:     adPermalinkMap[row.ad_id] || null,
          thumbnail:     adThumbnailMap[row.ad_id] || null,
        }
      })
      .filter(r => r.waConvs > 0)
      .sort((a, b) => b.waConvs - a.waConvs)
      .slice(0, 30)

    // ── WhatsApp summary ──────────────────────────────────────────────────────
    const waTotal      = sumAction(totalsRaw, 'onsite_conversion.messaging_conversation_started_7d')
      + sumAction(totalsRaw, 'onsite_conversion.total_messaging_connection')
    const ctwa         = sumAction(totalsRaw, 'click_to_whatsapp_all')
      || sumAction(totalsRaw, 'onsite_conversion.messaging_conversation_started_7d')
    const firstReply   = sumAction(totalsRaw, 'onsite_conversion.messaging_first_reply')
    const totalConn    = sumAction(totalsRaw, 'onsite_conversion.total_messaging_connection')

    res.status(200).json({
      step, stepTotal, actionBreakdown, placements, devices,
      whatsapp: {
        total: waTotal, ctwa, firstReply, totalConn,
        pctOfStep: stepTotal > 0 ? parseFloat(((waTotal / stepTotal) * 100).toFixed(1)) : 0,
        campaigns: waCampaigns,
      },
    })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
