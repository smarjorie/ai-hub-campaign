import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

// Campos padrão alinhados com a skill meta-ads-insights
const DEFAULT_FIELDS = [
  'campaign_id', 'campaign_name',
  'adset_id', 'adset_name',
  'ad_id', 'ad_name',
  'impressions', 'reach', 'clicks', 'ctr',
  'spend', 'cpm', 'cpp', 'frequency',
  'actions', 'action_values',
].join(',')

// Paginação automática — busca todas as páginas
async function fetchAllPages(url: string, params: Record<string, string>): Promise<any[]> {
  const results: any[] = []
  let nextUrl: string | null = url
  let nextParams: Record<string, string> | null = params

  while (nextUrl) {
    const query: string = nextParams
      ? nextUrl + '?' + new URLSearchParams(nextParams).toString()
      : nextUrl
    const r = await fetch(query)
    const data = await r.json()
    if (data.error) throw new Error(data.error.message)
    results.push(...(data.data || []))
    nextUrl = data.paging?.next || null
    nextParams = null // next URL já inclui todos os params
  }

  return results
}

// Calcula ROAS a partir de action_values (igual à skill)
function calcRoas(row: any): number {
  const spend = parseFloat(row.spend || '0')
  if (!spend) return 0
  const revenue = (row.action_values || [])
    .filter((a: any) => a.action_type === 'purchase' || a.action_type === 'omni_purchase')
    .reduce((sum: number, a: any) => sum + parseFloat(a.value || '0'), 0)
  return revenue > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0
}

// Recebe tipos em ordem de prioridade e usa o PRIMEIRO presente na linha.
// A Meta repete o mesmo evento em varios action_types (purchase, omni_purchase,
// offsite_conversion.fb_pixel_purchase), entao somar todos contaria em dobro.
function firstMatch(list: any[] | undefined, types: string[], parse: (v: string) => number): number {
  for (const t of types) {
    const hit = (list || []).find((a: any) => a.action_type === t)
    if (hit) return parse(hit.value || '0')
  }
  return 0
}

function extractAction(row: any, ...types: string[]): number {
  return firstMatch(row.actions, types, v => parseInt(v, 10))
}

function extractActionValue(row: any, ...types: string[]): number {
  return firstMatch(row.action_values, types, v => parseFloat(v))
}

// Normaliza uma linha da Insights API no formato que o dashboard consome
function normalizeInsight(row: any) {
  const spend       = parseFloat(row.spend || '0')
  const impressions = parseInt(row.impressions || '0', 10)
  const clicks      = parseInt(row.clicks || '0', 10)
  const reach       = parseInt(row.reach || '0', 10)
  const cpm         = parseFloat(row.cpm || '0')
  const ctr         = parseFloat(row.ctr || '0')
  const frequency   = parseFloat(row.frequency || '0')

  const purchases   = extractAction(row, 'purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase', 'website_purchase')
  const revenue     = extractActionValue(row, 'purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase', 'website_purchase')
  const addToCart   = extractAction(row, 'add_to_cart', 'omni_add_to_cart', 'offsite_conversion.fb_pixel_add_to_cart')
  const checkouts   = extractAction(row, 'initiate_checkout', 'omni_initiated_checkout', 'offsite_conversion.fb_pixel_initiate_checkout')
  const leads       = extractAction(row, 'lead') || extractAction(row, 'onsite_conversion.lead_grouped')
  const messages    = extractAction(row, 'onsite_conversion.messaging_conversation_started_7d')
                   || extractAction(row, 'onsite_conversion.total_messaging_connection')
  const pageViews   = extractAction(row, 'landing_page_view', 'link_click')
  const roas        = calcRoas(row)
  const profit      = parseFloat((revenue - spend).toFixed(2))
  const cpa         = {
    meta: purchases > 0 ? parseFloat((spend / purchases).toFixed(2)) : 0,
    db:   purchases > 0 ? parseFloat((spend / purchases).toFixed(2)) : 0,
  }

  return {
    spend, impressions, clicks, reach, cpm, ctr, frequency,
    salesMeta: purchases, salesDb: purchases,
    revenue: parseFloat(revenue.toFixed(2)),
    profit, roas, cpa,
    addToCart, checkouts, leads, messages, pageViews,
    // identifiers
    campaign_id:   row.campaign_id,
    campaign_name: row.campaign_name,
    adset_id:      row.adset_id,
    adset_name:    row.adset_name,
    ad_id:         row.ad_id,
    ad_name:       row.ad_name,
    date_start:    row.date_start,
    date_stop:     row.date_stop,
  }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token não informado' })

  const {
    account_id,
    level = 'campaign',              // account | campaign | adset | ad
    date_preset = 'last_30d',        // last_7d | last_30d | last_month | this_month
    time_increment,                  // 1 = day-by-day, para timeline
    fields = DEFAULT_FIELDS,
  } = req.query as Record<string, string>

  if (!account_id) return res.status(400).json({ error: 'Parâmetro account_id obrigatório' })

  const acctId = account_id.startsWith('act_') ? account_id : `act_${account_id}`

  const params: Record<string, string> = {
    access_token: token,
    level,
    date_preset,
    fields,
    limit: '200',
  }
  if (time_increment) params.time_increment = time_increment

  try {
    const raw = await fetchAllPages(`${BASE}/${acctId}/insights`, params)
    const normalized = raw.map(normalizeInsight)
    res.status(200).json({ data: normalized, meta: { level, date_preset, count: normalized.length } })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
