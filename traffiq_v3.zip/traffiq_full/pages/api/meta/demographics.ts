import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

async function fetchAllPages(url: string, params: Record<string, string>): Promise<any[]> {
  const results: any[] = []
  let nextUrl: string | null = url
  let nextParams: Record<string, string> | null = params
  while (nextUrl) {
    const query: string = nextParams ? nextUrl + '?' + new URLSearchParams(nextParams).toString() : nextUrl
    const r = await fetch(query)
    const data = await r.json()
    if (data.error) throw new Error(data.error.message)
    results.push(...(data.data || []))
    nextUrl = data.paging?.next || null
    nextParams = null
  }
  return results
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token não informado' })
  const { account_id, date_preset = 'last_30d' } = req.query as Record<string, string>
  if (!account_id) return res.status(400).json({ error: 'account_id obrigatório' })
  const acctId = account_id.startsWith('act_') ? account_id : `act_${account_id}`

  try {
    // Gênero
    const genderRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token,
      level: 'account',
      date_preset,
      breakdowns: 'gender',
      fields: 'reach,impressions,spend',
      limit: '10',
    })

    // Faixa etária
    const ageRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token,
      level: 'account',
      date_preset,
      breakdowns: 'age',
      fields: 'reach,impressions,spend',
      limit: '20',
    })

    // Regiões
    const regionRaw = await fetchAllPages(`${BASE}/${acctId}/insights`, {
      access_token: token,
      level: 'account',
      date_preset,
      breakdowns: 'region',
      fields: 'reach,impressions,spend',
      limit: '20',
    })

    // Calcula totais para % 
    const totalReachGender = genderRaw.reduce((s, r) => s + parseInt(r.reach || '0', 10), 0) || 1
    const totalReachAge    = ageRaw.reduce((s, r) => s + parseInt(r.reach || '0', 10), 0) || 1

    const gender = genderRaw.map(r => ({
      name: r.gender,
      value: parseFloat(((parseInt(r.reach || '0', 10) / totalReachGender) * 100).toFixed(1)),
      reach: parseInt(r.reach || '0', 10),
    }))

    const age = ageRaw
      .sort((a, b) => a.age?.localeCompare(b.age))
      .map(r => ({
        name: r.age,
        value: parseFloat(((parseInt(r.reach || '0', 10) / totalReachAge) * 100).toFixed(1)),
        reach: parseInt(r.reach || '0', 10),
      }))

    const regions = regionRaw
      .sort((a, b) => parseInt(b.reach || '0', 10) - parseInt(a.reach || '0', 10))
      .slice(0, 10)
      .map(r => ({
        region: r.region,
        reach: parseInt(r.reach || '0', 10),
        spend: parseFloat(r.spend || '0'),
        conversions: 0, // precisa cruzar com insights de compra
      }))

    res.status(200).json({ gender, age, regions })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
