import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

// Valida o token e retorna nome do usuário + permissões
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token não informado' })

  try {
    // 1) Dados do usuário
    const meRes = await fetch(`${BASE}/me?fields=id,name,email&access_token=${token}`)
    const me = await meRes.json()
    if (me.error) return res.status(400).json({ error: me.error.message, code: me.error.code })

    // 2) Permissões do token
    const permRes = await fetch(`${BASE}/me/permissions?access_token=${token}`)
    const permData = await permRes.json()
    const permissions = (permData.data || [])
      .filter((p: any) => p.status === 'granted')
      .map((p: any) => p.permission)

    // 3) Contas de anúncios disponíveis
    const acctRes = await fetch(`${BASE}/me/adaccounts?fields=id,name,account_status,currency&limit=25&access_token=${token}`)
    const acctData = await acctRes.json()
    const accounts = (acctData.data || []).map((a: any) => ({
      id: a.id,
      name: a.name,
      status: a.account_status, // 1=ACTIVE, 2=DISABLED, 3=UNSETTLED, 7=PENDING_RISK_REVIEW
      currency: a.currency,
    }))

    res.status(200).json({
      valid: true,
      user: { id: me.id, name: me.name, email: me.email },
      permissions,
      hasAdsManagement: permissions.includes('ads_management') || permissions.includes('ads_read'),
      accounts,
    })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
}
