import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token não informado' })

  try {
    const r = await fetch(
      `${BASE}/me/adaccounts?fields=id,name,account_id,account_status,currency,business{name}&limit=50&access_token=${token}`
    )
    const data = await r.json()
    if (data.error) return res.status(400).json({ error: data.error.message, code: data.error.code, type: data.error.type })
    res.status(200).json(data)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
}
