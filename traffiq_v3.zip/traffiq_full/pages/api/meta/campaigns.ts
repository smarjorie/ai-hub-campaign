import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

// Paginação com limite máximo de páginas para evitar "too much data"
async function fetchPages(
  url: string,
  params: Record<string, string>,
  maxPages = 10
): Promise<any[]> {
  const results: any[] = []
  let nextUrl: string | null = url
  let nextParams: Record<string, string> | null = params
  let page = 0

  while (nextUrl && page < maxPages) {
    const query: string = nextParams
      ? nextUrl + '?' + new URLSearchParams(nextParams).toString()
      : nextUrl
    const r = await fetch(query)
    const d: any = await r.json()
    if (d.error) throw new Error(d.error.message)
    results.push(...(d.data || []))
    nextUrl   = d.paging?.next || null
    nextParams = null
    page++
  }
  return results
}

function extractAction(row: any, ...types: string[]): number {
  return (row.actions || [])
    .filter((a: any) => types.includes(a.action_type))
    .reduce((s: number, a: any) => s + parseInt(a.value || '0', 10), 0)
}

function extractValue(row: any, ...types: string[]): number {
  return (row.action_values || [])
    .filter((a: any) => types.includes(a.action_type))
    .reduce((s: number, a: any) => s + parseFloat(a.value || '0'), 0)
}

function metricsFromInsight(row: any) {
  const spend       = parseFloat(row.spend || '0')
  const impressions = parseInt(row.impressions || '0', 10)
  const clicks      = parseInt(row.clicks || '0', 10)
  const reach       = parseInt(row.reach || '0', 10)
  const cpm         = parseFloat(row.cpm || '0')
  const ctr         = parseFloat(row.ctr || '0')
  const frequency   = parseFloat(row.frequency || '0')
  const purchases   = extractAction(row, 'purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase', 'website_purchase')
  const revenue     = extractValue(row,  'purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase', 'website_purchase')
  const addToCart   = extractAction(row, 'add_to_cart', 'omni_add_to_cart', 'offsite_conversion.fb_pixel_add_to_cart')
  const checkouts   = extractAction(row, 'initiate_checkout', 'omni_initiated_checkout', 'offsite_conversion.fb_pixel_initiate_checkout')
  const pageViews   = extractAction(row, 'landing_page_view')
  const roas        = spend > 0 && revenue > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0

  // WhatsApp action_types
  const waConvs = extractAction(row,
    'onsite_conversion.messaging_conversation_started_7d',
    'onsite_conversion.total_messaging_connection',
    'click_to_whatsapp_all'
  )
  const ctwa    = extractAction(row, 'click_to_whatsapp_all')
    || extractAction(row, 'onsite_conversion.messaging_conversation_started_7d')
  const cplWa   = waConvs > 0 ? parseFloat((spend / waConvs).toFixed(2)) : 0

  return {
    spend, impressions, clicks, reach, cpm, ctr, frequency,
    salesMeta: purchases, salesDb: purchases,
    revenue: parseFloat(revenue.toFixed(2)),
    profit: parseFloat((revenue - spend).toFixed(2)),
    roas,
    cpa: {
      meta: purchases > 0 ? parseFloat((spend / purchases).toFixed(2)) : 0,
      db:   purchases > 0 ? parseFloat((spend / purchases).toFixed(2)) : 0,
    },
    addToCart, checkouts, pageViews,
    waConvs, ctwa, cplWa,
  }
}

function sumMetrics(list: any[]) {
  const z = {
    spend: 0, impressions: 0, clicks: 0, reach: 0, cpm: 0, ctr: 0, frequency: 0,
    salesMeta: 0, salesDb: 0, revenue: 0, profit: 0, roas: 0,
    cpa: { meta: 0, db: 0 }, addToCart: 0, checkouts: 0, pageViews: 0,
    waConvs: 0, ctwa: 0, cplWa: 0,
  }
  list.forEach(m => {
    z.spend       += m.spend;      z.impressions += m.impressions
    z.clicks      += m.clicks;     z.reach       += m.reach
    z.salesMeta   += m.salesMeta;  z.salesDb     += m.salesDb
    z.revenue     += m.revenue;    z.profit      += m.profit
    z.addToCart   += m.addToCart;  z.checkouts   += m.checkouts
    z.pageViews   += m.pageViews
    z.waConvs     += (m.waConvs || 0); z.ctwa += (m.ctwa || 0)
  })
  z.cpm       = z.impressions > 0 ? parseFloat(((z.spend / z.impressions) * 1000).toFixed(2)) : 0
  z.ctr       = z.impressions > 0 ? parseFloat(((z.clicks / z.impressions) * 100).toFixed(4)) : 0
  z.frequency = z.reach > 0       ? parseFloat((z.impressions / z.reach).toFixed(2)) : 0
  z.roas      = z.spend > 0       ? parseFloat((z.revenue / z.spend).toFixed(2)) : 0
  z.cpa = {
    meta: z.salesMeta > 0 ? parseFloat((z.spend / z.salesMeta).toFixed(2)) : 0,
    db:   z.salesDb   > 0 ? parseFloat((z.spend / z.salesDb).toFixed(2))   : 0,
  }
  z.cplWa = z.waConvs > 0 ? parseFloat((z.spend / z.waConvs).toFixed(2)) : 0
  return z
}

function buildPostUrl(creative: any): string {
  if (!creative) return ''
  if (creative.instagram_permalink_url) return creative.instagram_permalink_url
  if (creative.effective_object_story_id) {
    const parts = creative.effective_object_story_id.split('_')
    if (parts.length === 2)
      return 'https://www.facebook.com/permalink.php?story_fbid=' + parts[1] + '&id=' + parts[0]
  }
  return creative.object_story_spec?.link_data?.link || ''
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token nao informado' })

  const { account_id, date_preset = 'last_30d' } = req.query as Record<string, string>
  if (!account_id) return res.status(400).json({ error: 'account_id obrigatorio' })

  const acctId = account_id.startsWith('act_') ? account_id : 'act_' + account_id

  try {
    // 1) Campanhas — limit 50, so ACTIVE
    const campaignsRaw = await fetchPages(
      BASE + '/' + acctId + '/campaigns',
      {
        access_token: token,
        fields: 'id,name,status,objective,daily_budget,lifetime_budget,budget_rebalance_flag',
        filtering: JSON.stringify([{ field: 'effective_status', operator: 'IN', value: ['ACTIVE', 'PAUSED'] }]),
        limit: '50',
      },
      5
    )

    // 2) Insights por ad (limit 100 por página, max 5 páginas = 500 ads)
    const insightsRaw = await fetchPages(
      BASE + '/' + acctId + '/insights',
      {
        access_token: token,
        level: 'ad',
        date_preset,
        fields: [
          'campaign_id', 'campaign_name', 'adset_id', 'adset_name', 'ad_id', 'ad_name',
          'impressions', 'reach', 'clicks', 'ctr', 'spend', 'cpm', 'frequency',
          'actions', 'action_values',
        ].join(','),
        limit: '100',
      },
      10  // max 1000 ads
    )

    // 3) Adsets — só ativos/pausados
    const adsetsRaw = await fetchPages(
      BASE + '/' + acctId + '/adsets',
      {
        access_token: token,
        fields: 'id,name,status,campaign_id,daily_budget,lifetime_budget,optimization_goal,destination_type',
        filtering: JSON.stringify([{ field: 'effective_status', operator: 'IN', value: ['ACTIVE', 'PAUSED'] }]),
        limit: '100',
      },
      5
    )

    // 4) Ads — só ativos/pausados, sem creative (buscamos separado por batch)
    const adsRaw = await fetchPages(
      BASE + '/' + acctId + '/ads',
      {
        access_token: token,
        fields: 'id,name,status,adset_id,campaign_id',
        filtering: JSON.stringify([{ field: 'effective_status', operator: 'IN', value: ['ACTIVE', 'PAUSED'] }]),
        limit: '100',
      },
      10
    )

    // 5) Batch de creatives — max 50 por request (Graph API batch limit)
    //    Só busca creatives dos ads que tiveram spend
    const adIdsWithSpend = new Set(insightsRaw.map((i: any) => i.ad_id).filter(Boolean))
    const adsWithSpend   = adsRaw.filter((a: any) => adIdsWithSpend.has(a.id))

    const creativeMap: Record<string, any> = {}
    const BATCH_SIZE = 50
    for (let i = 0; i < adsWithSpend.length; i += BATCH_SIZE) {
      const batch = adsWithSpend.slice(i, i + BATCH_SIZE)
      const ids   = batch.map((a: any) => a.id).join(',')
      try {
        const r = await fetch(
          BASE + '/?ids=' + ids +
          '&fields=id,creative{thumbnail_url,effective_object_story_id,instagram_permalink_url}' +
          '&access_token=' + token
        )
        const d: any = await r.json()
        if (!d.error) {
          Object.entries(d).forEach(([adId, obj]: [string, any]) => {
            if (obj?.creative) creativeMap[adId] = obj.creative
          })
        }
      } catch (_) { /* non-critical */ }
    }

    // Build lookup maps
    const adsByAdset: Record<string, any[]>    = {}
    const adsetsByCamp: Record<string, any[]>  = {}
    const insightsByAd: Record<string, any[]>  = {}

    adsRaw.forEach((a: any) => {
      if (!adsByAdset[a.adset_id]) adsByAdset[a.adset_id] = []
      adsByAdset[a.adset_id].push(a)
    })
    adsetsRaw.forEach((as: any) => {
      if (!adsetsByCamp[as.campaign_id]) adsetsByCamp[as.campaign_id] = []
      adsetsByCamp[as.campaign_id].push(as)
    })
    insightsRaw.forEach((i: any) => {
      if (!insightsByAd[i.ad_id]) insightsByAd[i.ad_id] = []
      insightsByAd[i.ad_id].push(i)
    })

    const EMPTY_METRICS = {
      spend: 0, impressions: 0, clicks: 0, reach: 0, cpm: 0, ctr: 0, frequency: 0,
      salesMeta: 0, salesDb: 0, revenue: 0, profit: 0, roas: 0,
      cpa: { meta: 0, db: 0 }, addToCart: 0, checkouts: 0, pageViews: 0,
    }

    // Assemble hierarchy
    const campaigns = campaignsRaw.map((camp: any) => {
      const budget = parseFloat(camp.daily_budget || camp.lifetime_budget || '0') / 100
      const isCBO  = camp.budget_rebalance_flag === true || !!camp.daily_budget

      const adSets = (adsetsByCamp[camp.id] || []).map((as: any) => {
        const asBudget      = parseFloat(as.daily_budget || as.lifetime_budget || '0') / 100
        const adsetDestType = (as.destination_type || '').toUpperCase()

        const ads = (adsByAdset[as.id] || []).map((ad: any) => {
          const rows    = insightsByAd[ad.id] || []
          const metrics = rows.length ? sumMetrics(rows.map(metricsFromInsight)) : { ...EMPTY_METRICS }
          const cr      = creativeMap[ad.id]
          // isCtwa: ONLY destination_type=WHATSAPP from Meta API (definitive signal)
          const adIsCtwa = adsetDestType === 'WHATSAPP'

          return {
            id:        ad.id,
            name:      ad.name,
            status:    ad.status,
            thumbnail: cr?.thumbnail_url || '',
            postUrl:   buildPostUrl(cr),
            isCtwa:    adIsCtwa,
            ...metrics,
          }
        })

        const asMetrics = ads.length ? sumMetrics(ads) : { ...EMPTY_METRICS }
        return {
          id: as.id, name: as.name, status: as.status,
          budget: asBudget, budgetType: 'ABO',
          optimizationGoal:  as.optimization_goal,
          destinationType:   as.destination_type || '',
          ads,
          ...asMetrics,
        }
      })

      const campMetrics = adSets.length ? sumMetrics(adSets) : { ...EMPTY_METRICS }
      return {
        id: camp.id, name: camp.name, status: camp.status,
        platform: 'meta',
        objective: camp.objective,
        budget, budgetType: isCBO ? 'CBO' : 'ABO',
        adSets,
        ...campMetrics,
      }
    })

    res.status(200).json({
      campaigns,
      meta: { date_preset, account_id: acctId, count: campaigns.length },
    })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
