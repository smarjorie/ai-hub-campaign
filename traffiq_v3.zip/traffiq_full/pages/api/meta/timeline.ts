import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://graph.facebook.com/v21.0'

async function fetchPages(url: string, params: Record<string, string>, maxPages = 5): Promise<any[]> {
  const results: any[] = []
  let nextUrl: string | null = url
  let nextParams: Record<string, string> | null = params
  let page = 0
  while (nextUrl && page < maxPages) {
    const query: string = nextParams ? nextUrl + '?' + new URLSearchParams(nextParams).toString() : nextUrl
    const r    = await fetch(query)
    const data = await r.json()
    if (data.error) throw new Error(data.error.message)
    results.push(...(data.data || []))
    nextUrl    = data.paging?.next || null
    nextParams = null
    page++
  }
  return results
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const token = (req.headers['x-meta-token'] as string) || process.env.META_ACCESS_TOKEN
  if (!token) return res.status(401).json({ error: 'Token nao informado' })

  const { account_id, date_preset = 'last_30d' } = req.query as Record<string, string>
  if (!account_id) return res.status(400).json({ error: 'account_id obrigatorio' })

  const acctId = account_id.startsWith('act_') ? account_id : 'act_' + account_id

  try {
    const params: Record<string, string> = {
      access_token:   token,
      level:          'account',
      date_preset,
      time_increment: '1',
      fields:         'date_start,impressions,reach,clicks,spend,cpm,actions,action_values',
      limit:          '90',
    }

    const raw = await fetchPages(BASE + '/' + acctId + '/insights', params)

    const data = raw.map((row: any) => {
      const spend       = parseFloat(row.spend || '0')
      const clicks      = parseInt(row.clicks || '0', 10)
      const impressions = parseInt(row.impressions || '0', 10)
      const cpm         = parseFloat(row.cpm || '0')

      const revenue = (row.action_values || [])
        .filter((a: any) => ['purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase'].includes(a.action_type))
        .reduce((s: number, a: any) => s + parseFloat(a.value || '0'), 0)

      const conversions = (row.actions || [])
        .filter((a: any) => ['purchase', 'omni_purchase', 'offsite_conversion.fb_pixel_purchase'].includes(a.action_type))
        .reduce((s: number, a: any) => s + parseInt(a.value || '0', 10), 0)

      const roas = spend > 0 && revenue > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0

      const d     = new Date(row.date_start)
      const label = String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0')

      return {
        label, date: row.date_start,
        spend: parseFloat(spend.toFixed(2)),
        revenue: parseFloat(revenue.toFixed(2)),
        roas, clicks, impressions, cpm,
        conversions,
      }
    })

    res.status(200).json({ data })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
