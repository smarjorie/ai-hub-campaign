// pages/api/mcp.ts
// Servidor MCP do Traffiq (transporte Streamable HTTP, sem estado, respostas JSON).
// Qualquer cliente MCP remoto (Claude, ChatGPT, Cursor, Gemini CLI...) conecta em:
//   https://SEU-PROJETO.vercel.app/api/mcp
// Autenticacao: header "Authorization: Bearer <TRAFFIQ_MCP_KEY>" ou ?key=<TRAFFIQ_MCP_KEY>
// (a forma via URL existe porque alguns clientes so aceitam URL, sem headers).

import type { NextApiRequest, NextApiResponse } from 'next'
import { timingSafeEqual } from 'crypto'
import { enabledTools } from '@/lib/mcp/tools'
import { serverOrigin } from '@/lib/serverOrigin'

const SUPPORTED_VERSIONS = ['2025-06-18', '2025-03-26', '2024-11-05']
const SERVER_INFO = { name: 'traffiq', title: 'Traffiq', version: '1.0.0' }

const INSTRUCTIONS =
  'Ferramentas do Traffiq para Meta Ads e Google Ads. Comece por meta_get_campaigns ou google_get_campaigns ' +
  'no nível de campanha e só desça para adset/ad quando necessário. Valores monetários estão na moeda da conta. ' +
  'Ferramentas que alteram a conta (meta_set_*) exigem confirmação explícita do usuário antes de serem chamadas.'

function authorized(req: NextApiRequest): boolean {
  const expected = process.env.TRAFFIQ_MCP_KEY
  if (!expected) return false
  const header = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  const provided = header || (typeof req.query.key === 'string' ? req.query.key : '')
  const a = Buffer.from(provided)
  const b = Buffer.from(expected)
  return a.length === b.length && timingSafeEqual(a, b)
}


type RpcMsg = { jsonrpc: '2.0'; id?: string | number | null; method?: string; params?: any }

const ok = (id: RpcMsg['id'], result: any) => ({ jsonrpc: '2.0', id, result })
const fail = (id: RpcMsg['id'], code: number, message: string) => ({ jsonrpc: '2.0', id: id ?? null, error: { code, message } })

async function handle(msg: RpcMsg, req: NextApiRequest) {
  const { id, method, params } = msg

  switch (method) {
    case 'initialize': {
      const asked = params?.protocolVersion
      return ok(id, {
        protocolVersion: SUPPORTED_VERSIONS.includes(asked) ? asked : SUPPORTED_VERSIONS[0],
        capabilities: { tools: { listChanged: false } },
        serverInfo: SERVER_INFO,
        instructions: INSTRUCTIONS,
      })
    }

    case 'ping':
      return ok(id, {})

    case 'tools/list':
      return ok(id, {
        tools: enabledTools().map(t => ({
          name: t.name,
          title: t.title,
          description: t.description,
          inputSchema: t.inputSchema,
          annotations: {
            title: t.title,
            readOnlyHint: !t.write,
            destructiveHint: !!t.write,
            idempotentHint: true,
            openWorldHint: true,
          },
        })),
      })

    case 'tools/call': {
      const tool = enabledTools().find(t => t.name === params?.name)
      if (!tool) return fail(id, -32602, `Ferramenta desconhecida: ${params?.name}`)
      try {
        const result = await tool.run(params?.arguments || {}, { origin: serverOrigin(req) })
        return ok(id, { content: [{ type: 'text', text: JSON.stringify(result) }], isError: false })
      } catch (e: any) {
        // erro de ferramenta volta como resultado, para a IA ler e se corrigir
        return ok(id, { content: [{ type: 'text', text: `Erro: ${e.message}` }], isError: true })
      }
    }

    // capacidades que este servidor nao oferece: listas vazias em vez de erro
    case 'resources/list':
      return ok(id, { resources: [] })
    case 'prompts/list':
      return ok(id, { prompts: [] })

    default:
      return fail(id, -32601, `Método não suportado: ${method}`)
  }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, Mcp-Session-Id, Mcp-Protocol-Version')
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, DELETE, OPTIONS')
  if (req.method === 'OPTIONS') return res.status(204).end()

  // sem stream SSE nem sessao: GET e DELETE nao se aplicam
  if (req.method !== 'POST') return res.status(405).setHeader('Allow', 'POST').json(fail(null, -32000, 'Use POST.'))

  if (!process.env.TRAFFIQ_MCP_KEY) return res.status(503).json(fail(null, -32000, 'TRAFFIQ_MCP_KEY não configurada no servidor.'))
  if (!authorized(req)) return res.status(401).json(fail(null, -32001, 'Não autorizado.'))

  const body = req.body
  if (!body || typeof body !== 'object') return res.status(400).json(fail(null, -32700, 'JSON inválido.'))

  const batch: RpcMsg[] = Array.isArray(body) ? body : [body]
  const requests = batch.filter(m => m && m.id !== undefined && m.id !== null)

  // so notificacoes (ex.: notifications/initialized): aceita sem corpo
  if (!requests.length) return res.status(202).end()

  const responses = await Promise.all(requests.map(m => handle(m, req)))
  return res.status(200).json(Array.isArray(body) ? responses : responses[0])
}

export const config = { maxDuration: 60 }
