import type { NextApiRequest, NextApiResponse } from 'next'

// Google Ads API v17 — validação de credenciais
// Requer: developer_token + customer_id (login_customer_id opcional para MCCs)
const BASE = 'https://googleads.googleapis.com/v17'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const devToken  = (req.headers['x-google-dev-token'] as string) || process.env.GOOGLE_DEVELOPER_TOKEN
  const custId    = (req.headers['x-google-customer-id'] as string) || process.env.GOOGLE_CUSTOMER_ID
  const oauthToken= (req.headers['x-google-oauth-token'] as string) || process.env.GOOGLE_OAUTH_TOKEN

  if (!devToken)   return res.status(401).json({ error: 'Developer Token não informado' })
  if (!custId)     return res.status(401).json({ error: 'Customer ID não informado' })
  if (!oauthToken) return res.status(401).json({ error: 'OAuth Token não informado' })

  const cleanId = custId.replace(/-/g, '')

  try {
    // Busca info da conta via Google Ads Query Language (GAQL)
    const r = await fetch(`${BASE}/customers/${cleanId}/googleAds:search`, {
      method: 'POST',
      headers: {
        'Authorization':         `Bearer ${oauthToken}`,
        'developer-token':       devToken,
        'Content-Type':          'application/json',
        'login-customer-id':     cleanId,
      },
      body: JSON.stringify({
        query: `SELECT customer.id, customer.descriptive_name, customer.currency_code, customer.time_zone FROM customer LIMIT 1`
      }),
    })
    const data = await r.json()

    if (data.error || (data[0]?.error)) {
      const msg = data.error?.message || data[0]?.error?.message || 'Credenciais inválidas'
      return res.status(400).json({ error: msg })
    }

    const customer = data.results?.[0]?.customer
    return res.status(200).json({
      valid: true,
      customer: {
        id:       customer?.id,
        name:     customer?.descriptiveName,
        currency: customer?.currencyCode,
        timezone: customer?.timeZone,
      }
    })
  } catch (e: any) {
    return res.status(500).json({ error: e.message })
  }
}
