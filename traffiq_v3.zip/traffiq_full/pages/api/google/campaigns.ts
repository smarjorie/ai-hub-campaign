import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://googleads.googleapis.com/v17'

async function gaqlSearch(customerId: string, devToken: string, oauthToken: string, query: string) {
  const r = await fetch(`${BASE}/customers/${customerId}/googleAds:search`, {
    method: 'POST',
    headers: {
      'Authorization':   `Bearer ${oauthToken}`,
      'developer-token': devToken,
      'Content-Type':    'application/json',
      'login-customer-id': customerId,
    },
    body: JSON.stringify({ query }),
  })
  const data = await r.json()
  if (data.error) throw new Error(data.error.message)
  return data.results || []
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const devToken   = (req.headers['x-google-dev-token'] as string)   || process.env.GOOGLE_DEVELOPER_TOKEN
  const custId     = (req.headers['x-google-customer-id'] as string) || process.env.GOOGLE_CUSTOMER_ID
  const oauthToken = (req.headers['x-google-oauth-token'] as string) || process.env.GOOGLE_OAUTH_TOKEN

  if (!devToken || !custId || !oauthToken)
    return res.status(401).json({ error: 'Credenciais Google incompletas' })

  const cleanId   = custId.replace(/-/g, '')
  const { date_range = 'LAST_30_DAYS' } = req.query as Record<string, string>

  try {
    // Campanhas com métricas — GAQL
    const campRows = await gaqlSearch(cleanId, devToken, oauthToken, `
      SELECT
        campaign.id, campaign.name, campaign.status,
        campaign.advertising_channel_type,
        campaign_budget.amount_micros,
        metrics.impressions, metrics.clicks, metrics.cost_micros,
        metrics.conversions, metrics.conversions_value,
        metrics.ctr, metrics.average_cpm, metrics.average_cpc
      FROM campaign
      WHERE segments.date DURING ${date_range}
        AND campaign.status != 'REMOVED'
      ORDER BY metrics.cost_micros DESC
      LIMIT 50
    `)

    const campaigns = campRows.map((row: any) => {
      const m        = row.metrics || {}
      const camp     = row.campaign || {}
      const budget   = row.campaignBudget || {}
      const spend    = parseFloat(m.costMicros || '0') / 1_000_000
      const revenue  = parseFloat(m.conversionsValue || '0')
      const purchases= parseFloat(m.conversions || '0')
      const roas     = spend > 0 && revenue > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0
      const clicks   = parseInt(m.clicks || '0', 10)
      const impressions = parseInt(m.impressions || '0', 10)

      return {
        id:          camp.id,
        name:        camp.name,
        status:      camp.status,
        platform:    'google',
        objective:   camp.advertisingChannelType,
        budget:      parseFloat(budget.amountMicros || '0') / 1_000_000,
        budgetType:  'CBO',
        adSets:      [],   // detalhamento de ad groups disponível mas omitido p/ brevidade
        spend,
        revenue:     parseFloat(revenue.toFixed(2)),
        profit:      parseFloat((revenue - spend).toFixed(2)),
        roas,
        impressions,
        clicks,
        reach:       impressions,
        salesMeta:   Math.round(purchases),
        salesDb:     Math.round(purchases),
        cpm:         parseFloat(m.averageCpm || '0') / 1_000,
        ctr:         parseFloat(m.ctr || '0') * 100,
        frequency:   0,
        cpa:         { meta: purchases > 0 ? parseFloat((spend / purchases).toFixed(2)) : 0, db: 0 },
        addToCart:   0, checkouts: 0, pageViews: 0,
      }
    })

    res.status(200).json({ campaigns, meta: { date_range, count: campaigns.length } })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
