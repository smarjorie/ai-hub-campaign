import type { NextApiRequest, NextApiResponse } from 'next'

const BASE = 'https://googleads.googleapis.com/v17'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const devToken   = (req.headers['x-google-dev-token'] as string)   || process.env.GOOGLE_DEVELOPER_TOKEN
  const custId     = (req.headers['x-google-customer-id'] as string) || process.env.GOOGLE_CUSTOMER_ID
  const oauthToken = (req.headers['x-google-oauth-token'] as string) || process.env.GOOGLE_OAUTH_TOKEN

  if (!devToken || !custId || !oauthToken)
    return res.status(401).json({ error: 'Credenciais Google incompletas' })

  const cleanId   = custId.replace(/-/g, '')
  const { date_range = 'LAST_30_DAYS' } = req.query as Record<string, string>

  try {
    const r = await fetch(`${BASE}/customers/${cleanId}/googleAds:search`, {
      method: 'POST',
      headers: {
        'Authorization':   `Bearer ${oauthToken}`,
        'developer-token': devToken,
        'Content-Type':    'application/json',
      },
      body: JSON.stringify({
        query: `
          SELECT segments.date,
            metrics.impressions, metrics.clicks, metrics.cost_micros,
            metrics.conversions, metrics.conversions_value
          FROM customer
          WHERE segments.date DURING ${date_range}
          ORDER BY segments.date ASC
        `
      }),
    })
    const data = await r.json()
    if (data.error) throw new Error(data.error.message)

    const rows = (data.results || []).map((row: any) => {
      const spend   = parseFloat(row.metrics?.costMicros || '0') / 1_000_000
      const revenue = parseFloat(row.metrics?.conversionsValue || '0')
      const clicks  = parseInt(row.metrics?.clicks || '0', 10)
      const impressions = parseInt(row.metrics?.impressions || '0', 10)
      const conversions = parseFloat(row.metrics?.conversions || '0')
      const roas    = spend > 0 && revenue > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0
      const d       = new Date(row.segments?.date || '')
      const label   = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`
      return { label, date: row.segments?.date, spend: parseFloat(spend.toFixed(2)), revenue: parseFloat(revenue.toFixed(2)), roas, clicks, impressions, conversions: Math.round(conversions) }
    })

    res.status(200).json({ data: rows })
  } catch (e: any) {
    res.status(400).json({ error: e.message })
  }
}
