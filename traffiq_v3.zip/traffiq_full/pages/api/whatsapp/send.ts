import type { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST')
    return res.status(405).json({ error: 'Method not allowed' })

  const { to, message, bsp_token, bsp_endpoint, phone_number_id } = req.body

  if (!to)           return res.status(400).json({ error: 'Número de destino obrigatório' })
  if (!message)      return res.status(400).json({ error: 'Mensagem obrigatória' })
  if (!bsp_token)    return res.status(400).json({ error: 'Token do BSP não informado' })
  if (!bsp_endpoint) return res.status(400).json({ error: 'Endpoint do BSP não informado' })

  const cleanTo = to.replace(/\D/g, '')

  // ── Meta Cloud API ────────────────────────────────────────────────────────
  if (bsp_endpoint.includes('graph.facebook.com') || bsp_endpoint.includes('meta')) {
    const pid = phone_number_id || bsp_endpoint.match(/\/(\d{10,})\//)?.[1]
    if (!pid) return res.status(400).json({ error: 'phone_number_id não encontrado' })
    try {
      const r = await fetch(`https://graph.facebook.com/v21.0/${pid}/messages`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${bsp_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: cleanTo,
          type: 'text',
          text: { body: message, preview_url: false },
        }),
      })
      const data = await r.json()
      if (!r.ok || data.error)
        return res.status(400).json({ error: data.error?.message || 'Erro Meta Cloud API' })
      return res.status(200).json({ ok: true, message_id: data.messages?.[0]?.id, provider: 'meta_cloud' })
    } catch (e: any) { return res.status(500).json({ error: e.message }) }
  }

  // ── Zenvia ────────────────────────────────────────────────────────────────
  if (bsp_endpoint.includes('zenvia')) {
    try {
      const r = await fetch('https://api.zenvia.com/v2/channels/whatsapp/messages', {
        method: 'POST',
        headers: { 'X-API-TOKEN': bsp_token, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: phone_number_id || '',
          to: cleanTo,
          contents: [{ type: 'text', text: message }],
        }),
      })
      const data = await r.json()
      if (!r.ok) return res.status(400).json({ error: data.message || 'Erro Zenvia' })
      return res.status(200).json({ ok: true, message_id: data.id, provider: 'zenvia' })
    } catch (e: any) { return res.status(500).json({ error: e.message }) }
  }

  // ── Twilio ────────────────────────────────────────────────────────────────
  if (bsp_endpoint.includes('twilio')) {
    const [accountSid, authToken] = bsp_token.split(':')
    if (!accountSid || !authToken)
      return res.status(400).json({ error: 'Twilio: informe token como "AccountSID:AuthToken"' })
    try {
      const r = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            To: `whatsapp:+${cleanTo}`,
            From: `whatsapp:+${phone_number_id || ''}`,
            Body: message,
          }).toString(),
        }
      )
      const data = await r.json()
      if (!r.ok) return res.status(400).json({ error: data.message || 'Erro Twilio' })
      return res.status(200).json({ ok: true, message_id: data.sid, provider: 'twilio' })
    } catch (e: any) { return res.status(500).json({ error: e.message }) }
  }

  // ── Endpoint genérico ─────────────────────────────────────────────────────
  try {
    const r = await fetch(bsp_endpoint, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${bsp_token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: cleanTo, message, type: 'text' }),
    })
    const data = await r.json()
    if (!r.ok) return res.status(400).json({ error: data.message || data.error || `HTTP ${r.status}` })
    return res.status(200).json({ ok: true, message_id: data.id || data.message_id, provider: 'custom' })
  } catch (e: any) { return res.status(500).json({ error: e.message }) }
}
