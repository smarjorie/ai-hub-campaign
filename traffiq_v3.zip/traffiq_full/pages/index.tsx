import { useState, useMemo, useEffect } from 'react'
import Head from 'next/head'
import NavRail from '@/components/shell/NavRail'
import { locate, type ViewKey } from '@/components/shell/nav'
import AssistantHome from '@/components/assistant/AssistantHome'
import Automations from '@/components/automations/Automations'
import IntegrationsHub from '@/components/integrations/IntegrationsHub'
import MetricCard from '@/components/MetricCard'
import FunnelChart from '@/components/FunnelChart'
import TimelineChart from '@/components/TimelineChart'
import InsightsPanel from '@/components/InsightsPanel'
import MetaConnectFlow from '@/components/MetaConnectFlow'
import ReportDispatcher from '@/components/ReportDispatcher'
import type { DashMode } from '@/components/ModeSwitch'
import BspDashboard from '@/components/BspDashboard'
import GoogleConnectFlow from '@/components/GoogleConnectFlow'
import MetaMcpCard from '@/components/MetaMcpCard'
import AccountSwitcher from '@/components/AccountSwitcher'
import IntegrationRequired from '@/components/IntegrationRequired'
import CreativeRanking from '@/components/CreativeRanking'
import CampaignManager from '@/components/CampaignManager'
import AnalyticaPerformance from '@/components/AnalyticaPerformance'
import HybridView from '@/components/HybridView'
import { useMetaData } from '@/lib/useMetaData'
import { fmt } from '@/lib/format'
import { genHourlySales } from '@/lib/mockData'
import {
  DollarSign, ShoppingCart, Eye, Filter,
  RefreshCw, Calendar, ChevronDown, Download, ChevronRight,
  Wifi, AlertCircle, Database,
} from 'lucide-react'

type Page = 'assistant' | 'overview' | 'creatives' | 'analytics' | 'campaigns' | 'insights' | 'report' | 'integrations' | 'automations'

const PERIOD_MAP: Record<string, string> = {
  'Hoje':            'today',
  'Ontem':           'yesterday',
  'Últimos 7 dias':  'last_7d',
  'Últimos 30 dias': 'last_30d',
  'Este mes':        'this_month',
  'Mes anterior':    'last_month',
}
const PERIOD_OPTIONS = Object.keys(PERIOD_MAP)

function PageHeader({ title, sub, children }: {
  title: string; sub: string; children?: React.ReactNode
}) {
  return (
    <div className="flex items-start justify-between mb-5 flex-wrap gap-3">
      <div>
        <h1 className="text-[28px] font-semibold tracking-[-0.02em] text-ink">{title}</h1>
        <p className="mt-1 text-[15px] text-muted-2">{sub}</p>
      </div>
      {children}
    </div>
  )
}

function SourceBadge({ source }: { source: string }) {
  if (source === 'real')
    return <div className="flex items-center gap-1.5 text-xs badge-green"><Wifi size={11} /> Dados reais</div>
  if (source === 'loading')
    return <div className="flex items-center gap-1.5 text-xs badge-yellow"><RefreshCw size={11} className="animate-spin" /> Carregando...</div>
  if (source === 'error')
    return <div className="flex items-center gap-1.5 text-xs badge-red"><AlertCircle size={11} /> Erro</div>
  return (
    <div className="flex items-center gap-1.5 text-xs"
      style={{ color: '#6B7280', background: 'rgba(90,96,128,0.1)', padding: '2px 8px', borderRadius: 6, border: '1px solid rgba(90,96,128,0.15)' }}>
      <Database size={11} /> Demo
    </div>
  )
}

export default function Dashboard() {
  const [view,       setView]       = useState<ViewKey>('assistant')
  const [railOpen,   setRailOpen]   = useState(false)
  const mode: DashMode = view === 'bsp' ? 'bsp' : view === 'hybrid' ? 'hybrid' : 'ads'
  const page = view as Page
  const setPage = (p: Page) => setView(p as ViewKey)

  useEffect(() => {
    try { setRailOpen(localStorage.getItem('traffiq_rail_expanded') === 'true') } catch { /* ignore */ }
  }, [])
  const toggleRail = () => setRailOpen(v => { try { localStorage.setItem('traffiq_rail_expanded', String(!v)) } catch { /* ignore */ } return !v })
  const [period,     setPeriod]     = useState('Últimos 30 dias')
  const [showPeriod, setShowPeriod] = useState(false)

  const {
    connections, globalSource, errors,
    campaigns, timeline, funnel, demographics, geoData, summary,
    connectMeta, disconnectMeta, validateMetaToken, switchMetaAccount,
    connectGoogle, disconnectGoogle, validateGoogleCreds,
    setMetaMcp, reload,
  } = useMetaData(PERIOD_MAP[period])

  const meta   = connections.meta
  const google = connections.google

  const hourly = useMemo(() => genHourlySales(), [])

  const spendSpark  = useMemo(() => timeline.slice(-10).map((d: any) => d.spend),  [timeline])
  const clicksSpark = useMemo(() => timeline.slice(-10).map((d: any) => d.clicks), [timeline])
  const cpmSpark    = useMemo(() => timeline.slice(-10).map((d: any) => d.cpm || 0), [timeline])

  const platformTotals = useMemo(() => {
    const m: Record<string, { spend: number; revenue: number; roas: number }> = {}
    campaigns.forEach((c: any) => {
      const p = c.platform || 'meta'
      if (p === 'google' && google.status !== 'real') return
      if (p === 'tiktok') return
      if (!m[p]) m[p] = { spend: 0, revenue: 0, roas: 0 }
      m[p].spend   += c.spend
      m[p].revenue += c.revenue
    })
    Object.keys(m).forEach(k => {
      m[k].roas = m[k].spend > 0 ? parseFloat((m[k].revenue / m[k].spend).toFixed(2)) : 0
    })
    return m
  }, [campaigns, meta.status, google.status])

  const isMetaReal = meta.status === 'real'
  const anyReal    = isMetaReal || google.status === 'real'

  const goIntegrations = () => setPage('integrations')
  const goCreatives    = () => setPage('creatives')
  const crumb          = locate(view)
  const showDataBar    = !['assistant', 'automations', 'integrations'].includes(view)
  const handleSwitch   = (id: string) => switchMetaAccount(id)

  return (
    <>
      <Head>
        <title>Traffiq</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div className="flex min-h-screen bg-bg">
        <NavRail current={view} onNavigate={setView} expanded={railOpen} onToggle={toggleRail} />

        <main className="flex min-w-0 flex-1 flex-col transition-[margin] duration-200" style={{ marginLeft: railOpen ? 232 : 68 }}>

          {/* Topo: breadcrumb a esquerda, contexto de dados e acoes a direita */}
          <header
            className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-border bg-white/90 px-6 backdrop-blur"
            suppressHydrationWarning
          >
            <nav aria-label="Você está em" className="flex min-w-0 items-center gap-1.5 text-[14px]">
              {crumb.group !== crumb.label && (
                <>
                  <span className="text-muted">{crumb.group}</span>
                  <ChevronRight size={14} className="text-muted" aria-hidden />
                </>
              )}
              <span className="truncate font-medium text-ink">{crumb.label}</span>
            </nav>

            {showDataBar && (
              <div className="flex flex-wrap items-center justify-end gap-2">
                {meta.status !== 'mock' && mode !== 'bsp' && (
                  <AccountSwitcher
                    accountId={meta.accountId}
                    accountName={meta.accountName || ''}
                    userName={meta.userName}
                    accounts={meta.accounts || []}
                    status={meta.status}
                    onSwitch={handleSwitch}
                  />
                )}

                <div className="relative">
                  <button
                    className="btn-secondary flex items-center gap-1.5 py-1.5 text-[13px]"
                    onClick={() => setShowPeriod(!showPeriod)}
                    aria-expanded={showPeriod}
                  >
                    <Calendar size={13} />
                    {period}
                    <ChevronDown size={13} />
                  </button>
                  {showPeriod && (
                    <div className="card absolute right-0 top-full z-50 mt-1 w-48 py-1 shadow-flyout">
                      {PERIOD_OPTIONS.map(p => (
                        <button
                          key={p}
                          className={`w-full px-3 py-2 text-left text-[14px] transition-colors ${p === period ? 'bg-[#F0F1F4] font-medium text-ink' : 'text-muted-2 hover:bg-[#F7F8FA]'}`}
                          onClick={() => { setPeriod(p); setShowPeriod(false) }}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {mode === 'ads' && Object.entries(platformTotals).map(([plat, data]) => (
                  <div key={plat} className={`badge-${plat === 'meta' ? 'meta' : plat === 'google' ? 'google' : 'tiktok'} hidden lg:flex`}>
                    {plat === 'meta' ? 'Meta' : plat === 'google' ? 'Google' : 'TikTok'} {fmt.roas(data.roas)}
                  </div>
                ))}

                <SourceBadge source={mode === 'bsp' ? 'mock' : globalSource} />

                {anyReal && mode === 'ads' && (
                  <button onClick={reload} className="btn-ghost flex items-center gap-1.5 px-3 py-1.5 text-[13px]">
                    <RefreshCw size={13} /> Atualizar
                  </button>
                )}
                <button className="btn-secondary flex items-center gap-1.5 px-3 py-1.5 text-[13px]">
                  <Download size={13} /> Exportar
                </button>
              </div>
            )}
          </header>

          {/* Error banner */}
          {errors.meta && mode === 'ads' && (
            <div
              className="mx-5 mt-4 flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm flex-shrink-0"
              style={{ background: 'rgba(220,38,38,0.08)', border: '1px solid rgba(220,38,38,0.2)', color: '#DC2626' }}
            >
              <AlertCircle size={14} />
              <span><strong>Meta:</strong> {errors.meta}</span>
            </div>
          )}

          {/* Content */}
          <div className="flex-1 px-6 py-8 lg:px-10">

            {/* ASSISTENTE */}
            {view === 'assistant' && (
              <AssistantHome
                userName={meta.userName}
                metaConnected={isMetaReal}
                googleConnected={google.status === 'real'}
                onGoIntegrations={goIntegrations}
                onDataChanged={reload}
              />
            )}

            {/* AUTOMACOES */}
            {view === 'automations' && (
              <Automations metaConnected={isMetaReal} googleConnected={google.status === 'real'} />
            )}

            {/* BSP MODE */}
            {mode === 'bsp' && <BspDashboard />}

            {/* HYBRID MODE */}
            {mode === 'hybrid' && (
              <HybridView
                campaigns={campaigns}
                summary={summary}
                timeline={timeline}
                metaStatus={meta.status}
                onGoIntegrations={goIntegrations}
                onGoCreatives={goCreatives}
              />
            )}

            {/* ADS MODE */}
            {mode === 'ads' && view !== 'assistant' && view !== 'automations' && (
              <>
                {/* OVERVIEW */}
                {page === 'overview' && (
                  <div className="flex flex-col gap-5">
                    <PageHeader title="Visão geral" sub={`Consolidado - ${period}`} />

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <MetricCard
                        label="Investido"
                        value={fmt.brlK(summary.spend)}
                        change={-8.2}
                        icon={DollarSign}
                        color="#1E6BFF"
                        sparkline={spendSpark}
                        badge={anyReal ? 'Ao vivo' : undefined}
                        badgeColor="badge-green"
                      />
                      <MetricCard
                        label="Compras"
                        value={fmt.num(summary.salesDb)}
                        change={18.7}
                        icon={ShoppingCart}
                        color="#8B5CF6"
                      />
                      <MetricCard
                        label="Cliques"
                        value={fmt.numK(summary.clicks)}
                        change={-2.3}
                        icon={Eye}
                        color="#D97706"
                        sparkline={clicksSpark}
                      />
                      <MetricCard
                        label="CPM Medio"
                        value={fmt.brl(summary.cpm)}
                        change={-5.4}
                        icon={Filter}
                        color="#DC2626"
                        sparkline={cpmSpark}
                      />
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
                      <div className="xl:col-span-2 card p-5">
                        <div className="flex items-center justify-between mb-4">
                          <div className="section-title">Linha do tempo</div>
                          <span className="badge-blue">{period}</span>
                        </div>
                        <TimelineChart data={timeline} />
                      </div>
                      <div className="card p-5">
                        <div className="section-title mb-4">Funil de tráfego</div>
                        <FunnelChart
                          data={funnel}
                          onSelect={() => setPage('analytics')}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* CRIATIVOS */}
                {page === 'creatives' && (
                  <div>
                    <PageHeader
                      title="Ranking de criativos"
                      sub="Ordenados por conversas WA, ROAS e performance"
                    >
                      <SourceBadge source={meta.status} />
                    </PageHeader>
                    <CreativeRanking
                      campaigns={campaigns}
                      isReal={isMetaReal}
                      metaToken={meta.token}
                      accountId={meta.accountId}
                      onGoIntegrations={goIntegrations}
                    />
                  </div>
                )}

                {/* ANALYTICS */}
                {page === 'analytics' && (
                  <div>
                    <PageHeader title="Performance analítica" sub="Funil, origens, horários, alcance e público">
                      <SourceBadge source={meta.status} />
                    </PageHeader>
                    <AnalyticaPerformance
                      funnel={funnel}
                      geoData={geoData}
                      demographics={demographics}
                      summary={summary}
                      isReal={isMetaReal}
                      metaToken={meta.token}
                      accountId={meta.accountId}
                      period={period}
                      onGoIntegrations={goIntegrations}
                    />
                  </div>
                )}

                {/* CAMPAIGNS */}
                {page === 'campaigns' && (
                  <div>
                    <PageHeader
                      title="Gerenciador de campanhas"
                      sub="Campanhas, conjuntos de anúncios e anúncios"
                    >
                      <SourceBadge source={meta.status} />
                    </PageHeader>
                    <CampaignManager campaigns={campaigns} />
                  </div>
                )}

                {/* INSIGHTS */}
                {page === 'insights' && (
                  <div>
                    <PageHeader title="Insights e otimização" sub="Recomendações baseadas nos seus dados">
                      <div className="badge-cyan">IA Ativa</div>
                    </PageHeader>
                    {!anyReal && (
                      <div className="mb-5">
                        <IntegrationRequired
                          platform="meta"
                          feature="insights baseados nos seus dados reais"
                          onGoToIntegrations={goIntegrations}
                        />
                      </div>
                    )}
                    <InsightsPanel />
                  </div>
                )}

                {/* REPORT */}
                {page === 'report' && (
                  <div>
                    <PageHeader
                      title="Enviar relatório"
                      sub="Gere e dispare um overview das campanhas direto no WhatsApp do cliente"
                    >
                      <div className="badge-green flex items-center gap-1.5">
                        <span className="status-active" /> WhatsApp
                      </div>
                    </PageHeader>
                    <ReportDispatcher
                      campaigns={campaigns}
                      summary={summary}
                      period={period}
                      accountName={meta.accountName || meta.accountId}
                    />
                  </div>
                )}

                {/* INTEGRATIONS */}
                {page === 'integrations' && (
                  <IntegrationsHub
                    meta={{ status: meta.status, accountName: meta.accountName, accountId: meta.accountId, userName: meta.userName, mcpEnabled: meta.mcpEnabled }}
                    google={{ status: google.status, customerName: google.customerName }}
                    metaFlow={<>
                      <MetaConnectFlow
                        token={meta.token}
                        accountId={meta.accountId}
                        accountName={meta.accountName || ''}
                        source={meta.status}
                        userName={meta.userName}
                        accounts={meta.accounts || []}
                        onConnect={connectMeta}
                        onDisconnect={disconnectMeta}
                        onSwitch={handleSwitch}
                        validateToken={validateMetaToken}
                      />
                      <MetaMcpCard enabled={meta.mcpEnabled} onToggle={setMetaMcp} />
                    </>}
                    googleFlow={
                      <GoogleConnectFlow
                        status={google.status}
                        customerName={google.customerName}
                        onConnect={connectGoogle}
                        onDisconnect={disconnectGoogle}
                        validateCreds={validateGoogleCreds}
                      />
                    }
                  />
                )}
              </>
            )}
          </div>
        </main>
      </div>
    </>
  )
}
